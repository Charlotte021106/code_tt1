const mongoose = require('mongoose');

const AuditLogSchema = new mongoose.Schema({
  user: String,
  action: String,
  target: String,
  ip: String,
  location: String,
  status: { type: String, enum: ['成功', '失败'] }
}, { timestamps: true });

module.exports = mongoose.model('AuditLog', AuditLogSchema);