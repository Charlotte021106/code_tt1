const mongoose = require('mongoose');
const { logAction } = require('./routes/audit');

const TransactionSchema = new mongoose.Schema({
  account_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Account' },
  date: String,
  type: { type: String, enum: ['收入', '支出'] },
  amount: String,
  counterparty: String,
  description: String
}, { timestamps: true });
await logAction({
  user: 'admin@company.com',
  action: '添加银行账户',
  target: '运营备用金账户',
  ip: '192.168.1.100',
  location: '北京',
  status: '成功'
});

module.exports = mongoose.model('Transaction', TransactionSchema);