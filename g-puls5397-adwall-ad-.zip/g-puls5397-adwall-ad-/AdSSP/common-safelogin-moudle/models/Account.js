const express = require('express');
const router = express.Router();
const Account = require('../models/Account');
const { encrypt, decrypt } = require('../utils/crypto');
const authMiddleware = require('../middlewares/authMiddleware');
const { logAction } = require('./audit');

// 添加账户
router.post('/', authMiddleware(['admin']), async (req, res) => {
  try {
    const encrypted = encrypt(req.body.account_number);
    const account = new Account({ 
      ...req.body, 
      account_number: encrypted,
      createdBy: req.user.userId
    });
    
    await account.save();

    // 审计日志
    await logAction({
      user: req.user.userId,
      action: 'ACCOUNT_CREATE',
      target: `account:${account._id}`,
      ip: req.ip,
      details: `创建账户: ${req.body.account_name}`
    });

    res.status(201).json({
      ...account.toObject(),
      account_number: '****' // 不返回加密数据
    });
  } catch (err) {
    // 审计日志（失败）
    await logAction({
      user: req.user?.userId,
      action: 'ACCOUNT_CREATE',
      target: 'new_account',
      ip: req.ip,
      status: 'FAILURE',
      error: err.message
    });
    
    res.status(500).json({ error: '创建账户失败' });
  }
});

// 获取所有账户（脱敏）
router.get('/', authMiddleware(), async (req, res) => {
  try {
    const accounts = await Account.find({ owner: req.user.userId });
    
    const masked = accounts.map(acc => {
      // 解密原始卡号
      const rawNum = decrypt(acc.account_number);
      
      return {
        ...acc.toObject(),
        account_number: '*'.repeat(rawNum.length - 4) + rawNum.slice(-4)
      };
    });

    // 审计日志
    await logAction({
      user: req.user.userId,
      action: 'ACCOUNTS_VIEW',
      target: 'all',
      ip: req.ip,
      details: `查看账户列表 (${accounts.length}个账户)`
    });

    res.json(masked);
  } catch (err) {
    await logAction({
      user: req.user?.userId,
      action: 'ACCOUNTS_VIEW',
      target: 'all',
      ip: req.ip,
      status: 'FAILURE',
      error: err.message
    });
    
    res.status(500).json({ error: '获取账户失败' });
  }
});

// 获取单个账户详情
router.get('/:id', authMiddleware(), async (req, res) => {
  try {
    const account = await Account.findOne({
      _id: req.params.id,
      owner: req.user.userId
    });
    
    if (!account) {
      return res.status(404).json({ error: '账户未找到' });
    }
    
    // 解密原始卡号
    const rawNum = decrypt(account.account_number);
    
    const maskedAccount = {
      ...account.toObject(),
      account_number: '*'.repeat(rawNum.length - 4) + rawNum.slice(-4)
    };

    // 审计日志
    await logAction({
      user: req.user.userId,
      action: 'ACCOUNT_VIEW',
      target: `account:${account._id}`,
      ip: req.ip,
      details: `查看账户: ${account.account_name}`
    });

    res.json(maskedAccount);
  } catch (err) {
    await logAction({
      user: req.user?.userId,
      action: 'ACCOUNT_VIEW',
      target: `account:${req.params.id}`,
      ip: req.ip,
      status: 'FAILURE',
      error: err.message
    });
    
    res.status(500).json({ error: '获取账户详情失败' });
  }
});

module.exports = router;