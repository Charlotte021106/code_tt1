const mongoose = require('mongoose');
const bcrypt = require('bcrypt');

const userSchema = new mongoose.Schema({
  // 认证信息
  username: { 
    type: String, 
    unique: true,
    sparse: true // 允许微信用户没有username
  },
  password: { 
    type: String,
    select: false // 查询时不返回密码
  },
  wechatOpenId: {
    type: String,
    unique: true,
    sparse: true
  },
  
  // 用户信息
  displayName: { 
    type: String, 
    required: true 
  },
  avatar: { 
    type: String,
    default: '' 
  },
  
  // 权限控制
  role: { 
    type: String, 
    enum: ['user', 'admin', 'auditor'], 
    default: 'user' 
  },
  
  // 元数据
  authType: {
    type: String,
    enum: ['local', 'wechat'],
    default: 'local'
  },
  createdAt: { 
    type: Date, 
    default: Date.now 
  },
  lastLogin: { 
    type: Date 
  }
});

// 密码加密钩子
userSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  
  try {
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
    next();
  } catch (err) {
    next(err);
  }
});

// 密码验证方法
userSchema.methods.comparePassword = async function(candidatePassword) {
  return bcrypt.compare(candidatePassword, this.password);
};

module.exports = mongoose.model('User', userSchema);