const express = require('express');
const router = express.Router();
const Account = require('../models/Account');
const { encrypt, decrypt } = require('../utils/crypto');

// 添加账户
router.post('/', async (req, res) => {
  const encrypted = encrypt(req.body.account_number);
  const account = new Account({ ...req.body, account_number: encrypted });
  await account.save();
  res.status(201).json(account);
});

// 获取所有账户（脱敏）
router.get('/', async (req, res) => {
  const accounts = await Account.find();
  const masked = accounts.map(acc => ({
    ...acc.toObject(),
    account_number: decrypt(acc.account_number).slice(-4).padStart(acc.account_number.length, '*')
  }));
  res.json(masked);
});

module.exports = router;