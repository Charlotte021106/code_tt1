const express = require('express');
const router = express.Router();
const Transaction = require('../models/Transaction');


// 获取某个账户的交易记录
router.get('/:accountId', async (req, res) => {
  try {
    const transactions = await Transaction.find({ account_id: req.params.accountId });
    res.json(transactions);
  } catch (err) {
    res.status(500).json({ error: '获取交易记录失败' });
  }
});

module.exports = router;