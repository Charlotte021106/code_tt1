const express = require('express');
const router = express.Router();
const AuditLog = require('../models/AuditLog');
const geoip = require('geoip-lite');
const { encrypt } = require('../utils/crypto');

// 添加审计日志
const logAction = async ({ 
  user, 
  action, 
  target, 
  ip, 
  status = 'SUCCESS', 
  error, 
  details 
}) => {
  try {
    let location = '未知';
    
    // 通过IP获取地理位置
    if (ip && !['::1', '127.0.0.1'].includes(ip)) {
      const geo = geoip.lookup(ip);
      if (geo) {
        location = `${geo.city || '未知城市'}, ${geo.country}`;
      }
    }
    
    await AuditLog.create({ 
      user, 
      action, 
      target, 
      ip, 
      location,
      status,
      error: error || null,
      details: details || null,
      timestamp: new Date()
    });
  } catch (logErr) {
    console.error('审计日志记录失败:', logErr);
  }
};

// 获取审计日志列表
router.get('/', async (req, res) => {
  try {
    const { action, userId, status, startDate, endDate } = req.query;
    const filter = {};
    
    if (action) filter.action = new RegExp(action, 'i');
    if (userId) filter.user = userId;
    if (status) filter.status = status;
    
    if (startDate || endDate) {
      filter.timestamp = {};
      if (startDate) filter.timestamp.$gte = new Date(startDate);
      if (endDate) filter.timestamp.$lte = new Date(endDate);
    }
    
    const logs = await AuditLog.find(filter)
      .sort({ timestamp: -1 })
      .limit(100)
      .populate('user', 'displayName');
      
    res.json(logs);
  } catch (err) {
    res.status(500).json({ error: '获取审计日志失败' });
  }
});

// 导出日志（加密导出）
router.get('/export', async (req, res) => {
  try {
    const logs = await AuditLog.find().sort({ timestamp: -1 }).limit(500);
    const exportData = {
      version: '1.2',
      system: '财务管理系统',
      exportDate: new Date().toISOString(),
      logs
    };
    
    // 加密导出
    const encrypted = encrypt(JSON.stringify(exportData));
    
    res.setHeader('Content-Disposition', 'attachment; filename=audit_logs.enc');
    res.setHeader('Content-Type', 'application/octet-stream');
    res.send(Buffer.from(encrypted));
  } catch (err) {
    res.status(500).json({ error: '导出失败' });
  }
});

module.exports = { router, logAction };