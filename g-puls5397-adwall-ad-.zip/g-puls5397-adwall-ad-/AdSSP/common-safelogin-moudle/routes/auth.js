const express = require('express');
const router = express.Router();
const axios = require('axios');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { logAction } = require('./audit');
const config = require('../config');
const authMiddleware = require('../middlewares/authMiddleware');

// 生成微信登录URL
router.get('/wechat', (req, res) => {
  const authUrl = `https://open.weixin.qq.com/connect/qrconnect?appid=${config.WECHAT_APP_ID}&redirect_uri=${encodeURIComponent(config.WECHAT_CALLBACK_URL)}&response_type=code&scope=snsapi_login&state=STATE#wechat_redirect`;
  res.json({ authUrl });
});

// 微信登录回调
router.get('/wechat/callback', async (req, res) => {
  try {
    const { code } = req.query;
    
    if (!code) {
      return res.status(400).json({ error: '缺少授权码' });
    }

    // 1. 使用code获取access_token
    const tokenResponse = await axios.get(
      `https://api.weixin.qq.com/sns/oauth2/access_token?appid=${config.WECHAT_APP_ID}&secret=${config.WECHAT_APP_SECRET}&code=${code}&grant_type=authorization_code`
    );

    const { access_token, openid } = tokenResponse.data;
    
    // 2. 获取用户信息
    const userInfoResponse = await axios.get(
      `https://api.weixin.qq.com/sns/userinfo?access_token=${access_token}&openid=${openid}`
    );
    
    const wechatUser = userInfoResponse.data;
    
    // 3. 查找或创建用户
    let user = await User.findOne({ wechatOpenId: openid });
    
    if (!user) {
      // 新用户注册
      user = new User({
        username: `wx_${openid.slice(0, 8)}`,
        wechatOpenId: openid,
        displayName: wechatUser.nickname || `微信用户_${openid.slice(0, 4)}`,
        avatar: wechatUser.headimgurl || '',
        role: 'user'
      });
      
      await user.save();
      
      // 审计日志 - 新用户注册
      await logAction({
        action: 'USER_REGISTER',
        target: `user:${user._id}`,
        ip: req.ip,
        status: 'SUCCESS',
        details: `微信注册: ${wechatUser.nickname}`
      });
    } else {
      // 更新用户信息
      user.displayName = wechatUser.nickname || user.displayName;
      user.avatar = wechatUser.headimgurl || user.avatar;
      await user.save();
    }
    
    // 4. 生成JWT
    const token = jwt.sign(
      { userId: user._id, role: user.role },
      config.JWT_SECRET,
      { expiresIn: '7d' }
    );
    
    // 5. 设置会话
    req.session.user = {
      id: user._id,
      role: user.role,
      displayName: user.displayName
    };
    
    // 审计日志 - 登录成功
    await logAction({
      user: user._id,
      action: 'USER_LOGIN',
      target: `user:${user._id}`,
      ip: req.ip,
      status: 'SUCCESS',
      details: '微信登录'
    });
    
    // 6. 重定向到前端页面
    res.redirect(`${config.CLIENT_URL}/login-success?token=${token}`);
    
  } catch (err) {
    // 审计日志 - 登录失败
    await logAction({
      action: 'USER_LOGIN',
      target: 'unknown',
      ip: req.ip,
      status: 'FAILURE',
      error: err.message
    });
    
    res.redirect(`${config.CLIENT_URL}/login-error?message=${encodeURIComponent(err.message)}`);
  }
});

// 获取当前用户信息
router.get('/me', authMiddleware(), async (req, res) => {
  try {
    const user = await User.findById(req.user.userId).select('-password');
    if (!user) {
      return res.status(404).json({ error: '用户不存在' });
    }
    
    res.json(user);
  } catch (err) {
    res.status(500).json({ error: '获取用户信息失败' });
  }
});

// 管理员手动创建用户
router.post('/create', authMiddleware(['admin']), async (req, res) => {
  try {
    const { username, password, role, displayName } = req.body;
    
    // 创建用户逻辑
    const user = new User({
      username,
      password,
      role: role || 'user',
      displayName: displayName || username,
      authType: 'local'
    });
    
    await user.save();
    
    // 审计日志
    await logAction({
      user: req.user.userId,
      action: 'USER_CREATE',
      target: `user:${user._id}`,
      ip: req.ip,
      status: 'SUCCESS',
      details: `管理员创建用户: ${username}`
    });
    
    res.status(201).json(user);
  } catch (err) {
    await logAction({
      user: req.user.userId,
      action: 'USER_CREATE',
      target: 'new_user',
      ip: req.ip,
      status: 'FAILURE',
      error: err.message
    });
    
    res.status(500).json({ error: '创建用户失败' });
  }
});

module.exports = router;