const express = require('express');
const session = require('express-session');
const app = express();
const cors = require('cors');
const authRoutes = require('./routes/auth');
const accountRoutes = require('./routes/accounts');
const auditRoutes = require('./routes/audit').router;
const transactionRoutes = require('./routes/transactions');
const authMiddleware = require('./middlewares/authMiddleware');
const config = require('./config');

// 中间件
app.use(cors({
  origin: config.CLIENT_URL,
  credentials: true
}));
app.use(express.json());
app.use(session({
  secret: config.SESSION_SECRET,
  resave: false,
  saveUninitialized: true,
  cookie: { secure: process.env.NODE_ENV === 'production' }
}));

// 路由设置
app.use('/api/auth', authRoutes);
app.use('/api/accounts', authMiddleware(), accountRoutes);
app.use('/api/audit', authMiddleware(['admin', 'auditor']), auditRoutes);
app.use('/api/transactions', authMiddleware(), transactionRoutes);

// 健康检查端点
app.get('/health', (req, res) => {
  res.json({
    status: 'UP',
    timestamp: new Date(),
    services: {
      database: 'CONNECTED',
      encryption: 'ACTIVE',
      wechat: 'AVAILABLE'
    }
  });
});

// 错误处理
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: '服务器内部错误' });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`服务器运行在端口 ${PORT}`);
  console.log(`微信登录地址: ${config.CLIENT_URL}/api/auth/wechat`);
});