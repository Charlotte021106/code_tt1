const crypto = require('crypto');
const algorithm = 'aes-256-cbc';

// 确保密钥是32字节
const getEncryptionKey = () => {
  const key = process.env.ENCRYPTION_KEY || 'default-32-byte-secret-key-here!';
  return crypto.createHash('sha256').update(key).digest('base64').substr(0, 32);
};

exports.encrypt = (text) => {
  try {
    const iv = crypto.randomBytes(16);
    const cipher = crypto.createCipheriv(algorithm, getEncryptionKey(), iv);
    
    let encrypted = cipher.update(text, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    
    return `${iv.toString('hex')}:${encrypted}`;
  } catch (err) {
    console.error('加密失败:', err);
    throw new Error('数据加密失败');
  }
};

exports.decrypt = (text) => {
  try {
    const [ivHex, encryptedHex] = text.split(':');
    if (!ivHex || !encryptedHex) {
      throw new Error('无效的加密文本格式');
    }
    
    const iv = Buffer.from(ivHex, 'hex');
    const decipher = crypto.createDecipheriv(algorithm, getEncryptionKey(), iv);
    
    let decrypted = decipher.update(encryptedHex, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    
    return decrypted;
  } catch (err) {
    console.error('解密失败:', err);
    throw new Error('数据解密失败');
  }
};

// 简单哈希函数（用于审计日志ID等）
exports.simpleHash = (text) => {
  return crypto.createHash('sha256').update(text).digest('hex');
};