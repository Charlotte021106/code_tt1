require('dotenv').config();

module.exports = {
  // 微信配置
  WECHAT_APP_ID: process.env.WECHAT_APP_ID,
  WECHAT_APP_SECRET: process.env.WECHAT_APP_SECRET,
  WECHAT_CALLBACK_URL: process.env.WECHAT_CALLBACK_URL || 
    `${process.env.BASE_URL}/api/auth/wechat/callback`,
  
  // 认证配置
  JWT_SECRET: process.env.JWT_SECRET || '123456741',
  SESSION_SECRET: process.env.SESSION_SECRET || '123456741',
  
  // 加密配置
  ENCRYPTION_KEY: process.env.ENCRYPTION_KEY || '32_byte_strong_encryption_key_!',
  
  // 系统配置
  CLIENT_URL: process.env.CLIENT_URL || 'http://localhost:3000',
  BASE_URL: process.env.BASE_URL || 'http://localhost:5000'
};