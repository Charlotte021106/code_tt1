const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

const { router: auditRouter } = require('./routes/audit');
app.use('/api/audit', auditRouter);

// 连接数据库
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/bank');

// 路由
app.use('/api/accounts', require('./routes/accounts'));
app.use('/api/transactions', require('./routes/transactions'));
app.use('/api/audit', require('./routes/audit'));
//app.use('/api/export', require('./routes/export'));

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));