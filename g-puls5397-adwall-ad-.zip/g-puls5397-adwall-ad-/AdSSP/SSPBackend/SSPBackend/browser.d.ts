declare const saslprep: (input: string, opts?: {
    allowUnassigned?: boolean;
} | undefined) => string;
export = saslprep;
//# sourceMappingURL=browser.d.ts.map