const mongoose = require('mongoose');
const { logAction } = require('./routes/audit');

const AccountSchema = new mongoose.Schema({
  account_name: String,
  bank_name: String,
  account_number: String, // AES 加密后
  branch_name: String,
  account_type: { type: String, enum: ['corporate', 'personal', 'foreign', 'basic'] },
  status: { type: String, enum: ['active', 'inactive'], default: 'active' },
  is_default: { type: Boolean, default: false },
  encrypted: { type: Boolean, default: true }
}, { timestamps: true });
await logAction({
  user: 'admin@company.com',
  action: '添加银行账户',
  target: '运营备用金账户',
  ip: '192.168.1.100',
  location: '北京',
  status: '成功'
});

module.exports = mongoose.model('Account', AccountSchema);