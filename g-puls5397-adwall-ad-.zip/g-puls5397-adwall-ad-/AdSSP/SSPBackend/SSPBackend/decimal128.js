/*!
 * ignore
 */

'use strict';

module.exports = require('bson').Decimal128;
