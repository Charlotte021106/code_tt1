'use strict';

const BulkWriteResult = require('mongodb/lib/bulk/common').BulkWriteResult;

module.exports = BulkWriteResult;
