
/*!
 * Module dependencies.
 */

'use strict';

const Binary = require('bson').Binary;

/*!
 * Module exports.
 */

module.exports = exports = Binary;
