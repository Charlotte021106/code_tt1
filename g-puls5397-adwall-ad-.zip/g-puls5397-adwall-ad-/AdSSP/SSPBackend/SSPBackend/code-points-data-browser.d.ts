declare const data: Buffer<ArrayBuffer>;
export default data;
//# sourceMappingURL=code-points-data-browser.d.ts.map