declare const _default: Buffer<ArrayBufferLike>;
export default _default;
//# sourceMappingURL=code-points-data.d.ts.map