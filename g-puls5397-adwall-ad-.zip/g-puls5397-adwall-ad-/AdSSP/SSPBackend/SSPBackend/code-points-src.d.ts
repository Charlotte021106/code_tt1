export declare const unassigned_code_points: Set<number>;
export declare const commonly_mapped_to_nothing: Set<number>;
export declare const non_ASCII_space_characters: Set<number>;
export declare const prohibited_characters: Set<number>;
export declare const bidirectional_r_al: Set<number>;
export declare const bidirectional_l: Set<number>;
//# sourceMappingURL=code-points-src.d.ts.map