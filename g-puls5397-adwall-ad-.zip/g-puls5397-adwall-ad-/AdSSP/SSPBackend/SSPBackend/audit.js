const express = require('express');
const router = express.Router();
const AuditLog = require('../models/AuditLog');

// 添加审计日志（内部调用）
const logAction = async ({ user, action, target, ip, location, status }) => {
  await AuditLog.create({ user, action, target, ip, location, status });
};

// 获取审计日志列表（支持筛选）
router.get('/', async (req, res) => {
  try {
    const { action, startDate, endDate } = req.query;
    const filter = {};

    if (action) filter.action = new RegExp(action, 'i');
    if (startDate || endDate) {
      filter.createdAt = {};
      if (startDate) filter.createdAt.$gte = new Date(startDate);
      if (endDate) filter.createdAt.$lte = new Date(endDate);
    }

    const logs = await AuditLog.find(filter).sort({ createdAt: -1 });
    res.json(logs);
  } catch (err) {
    res.status(500).json({ error: '获取审计日志失败' });
  }
});

// 导出日志为 JSON（加密导出）
router.get('/export', async (req, res) => {
  try {
    const logs = await AuditLog.find().sort({ createdAt: -1 });
    const exportData = {
      version: '1.0',
      timestamp: new Date().toISOString(),
      logs
    };
    res.setHeader('Content-Disposition', 'attachment; filename=audit_logs.json');
    res.json(exportData);
  } catch (err) {
    res.status(500).json({ error: '导出失败' });
  }
});

module.exports = { router, logAction };