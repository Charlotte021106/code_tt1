# -*- coding: utf-8 -*-
"""
@Time ： 2024/7/8 23:09
@Auth ： 九问
@File ：celery_main.py
@IDE ：PyCharm
@Email : 2750826557@qq.com
"""
import os
from celery import Celery

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'SSPBackend.settings')

app = Celery('SSPBackend')

app.config_from_object("celery_tasks.celery_config")  # 引入celery配置信息，任务队列

app.autodiscover_tasks(['celery_tasks.fdfs'])
app.autodiscover_tasks(['celery_tasks.billing'])
