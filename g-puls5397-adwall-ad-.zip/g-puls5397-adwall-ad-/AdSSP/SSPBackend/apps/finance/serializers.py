from rest_framework import serializers
from .models import BankAccount, TaxInfo, SettlementPeriod, Revenue, Invoice, Payment


class BankAccountSerializer(serializers.ModelSerializer):
    """银行账户序列化器"""
    class Meta:
        model = BankAccount
        fields = '__all__'
        read_only_fields = ('media', 'created_at', 'updated_at')


class TaxInfoSerializer(serializers.ModelSerializer):
    """税务信息序列化器"""
    class Meta:
        model = TaxInfo
        fields = '__all__'
        read_only_fields = ('media', 'created_at', 'updated_at')


class SettlementPeriodSerializer(serializers.ModelSerializer):
    """结算周期序列化器"""
    class Meta:
        model = SettlementPeriod
        fields = '__all__'
        read_only_fields = ('media', 'created_at', 'updated_at')


class RevenueSerializer(serializers.ModelSerializer):
    """收入记录序列化器"""
    media_name = serializers.CharField(source='media.name', read_only=True)
    placement_name = serializers.CharField(source='placement.name', read_only=True)
    
    class Meta:
        model = Revenue
        fields = (
            'id', 'media', 'media_name', 'placement', 'placement_name', 'date', 
            'impressions', 'clicks', 'revenue_amount', 'currency', 'ecpm', 
            'status', 'settlement_id', 'created_at', 'updated_at'
        )
        read_only_fields = ('created_at', 'updated_at')


class InvoiceSerializer(serializers.ModelSerializer):
    """发票序列化器"""
    media_name = serializers.CharField(source='media.name', read_only=True)
    
    class Meta:
        model = Invoice
        fields = (
            'id', 'media', 'media_name', 'invoice_number', 'issue_date', 'due_date',
            'start_date', 'end_date', 'amount', 'tax_amount', 'total_amount',
            'currency', 'status', 'notes', 'created_at', 'updated_at'
        )
        read_only_fields = ('invoice_number', 'created_at', 'updated_at')


class PaymentSerializer(serializers.ModelSerializer):
    """支付记录序列化器"""
    media_name = serializers.CharField(source='media.name', read_only=True)
    bank_account_info = serializers.SerializerMethodField()
    invoice_number = serializers.CharField(source='invoice.invoice_number', read_only=True)
    
    class Meta:
        model = Payment
        fields = (
            'id', 'media', 'media_name', 'invoice', 'invoice_number',
            'payment_number', 'bank_account', 'bank_account_info',
            'amount', 'currency', 'payment_date', 'transaction_id',
            'payment_method', 'status', 'notes', 'created_at', 'updated_at'
        )
        read_only_fields = ('payment_number', 'created_at', 'updated_at')
    
    def get_bank_account_info(self, obj):
        if obj.bank_account:
            return f"{obj.bank_account.bank_name} - {obj.bank_account.account_number}"
        return None


class RevenueSummarySerializer(serializers.Serializer):
    """收入汇总序列化器"""
    start_date = serializers.DateField()
    end_date = serializers.DateField()
    total_impressions = serializers.IntegerField()
    total_clicks = serializers.IntegerField()
    total_revenue = serializers.DecimalField(max_digits=12, decimal_places=4)
    average_ecpm = serializers.DecimalField(max_digits=10, decimal_places=4)
    currency = serializers.CharField()


class InvoiceRequestSerializer(serializers.Serializer):
    """发票申请序列化器"""
    start_date = serializers.DateField(required=True)
    end_date = serializers.DateField(required=True)
    notes = serializers.CharField(required=False, allow_blank=True)
    
    def validate(self, data):
        """验证日期范围"""
        if data['start_date'] > data['end_date']:
            raise serializers.ValidationError({"end_date": "结束日期必须大于开始日期"})
        return data 