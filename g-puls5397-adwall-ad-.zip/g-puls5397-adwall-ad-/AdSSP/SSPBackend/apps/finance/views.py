from django.db.models import Sum, Avg
from django.utils import timezone
from django.db import transaction
from rest_framework import viewsets, status, permissions, mixins
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.exceptions import ValidationError
from datetime import datetime, timedelta
import uuid

from .models import BankAccount, TaxInfo, SettlementPeriod, Revenue, Invoice, Payment
from .serializers import (
    BankAccountSerializer, TaxInfoSerializer, SettlementPeriodSerializer,
    RevenueSerializer, InvoiceSerializer, PaymentSerializer,
    RevenueSummarySerializer, InvoiceRequestSerializer
)
from utils.filters import MyPageNumberPagination


class BankAccountViewSet(viewsets.ModelViewSet):
    """银行账户管理视图集"""
    serializer_class = BankAccountSerializer
    pagination_class = MyPageNumberPagination
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        """获取当前媒体主的银行账户"""
        return BankAccount.objects.filter(media__owner=self.request.user).order_by('-is_default', '-created_at')

    def perform_create(self, serializer):
        """创建时自动关联当前媒体主"""
        media = self.request.user.owned_media.first()
        if not media:
            raise ValidationError({"detail": "用户没有关联的媒体"})
        serializer.save(media=media)

        # 如果设置为默认账户，则取消其他账户的默认状态
        if serializer.validated_data.get('is_default', False):
            BankAccount.objects.filter(media=media).exclude(id=serializer.instance.id).update(is_default=False)

    def perform_update(self, serializer):
        """更新时处理默认账户逻辑"""
        # 如果设置为默认账户，则取消其他账户的默认状态
        if serializer.validated_data.get('is_default', False):
            media = serializer.instance.media
            BankAccount.objects.filter(media=media).exclude(id=serializer.instance.id).update(is_default=False)
        serializer.save()

    @action(detail=False, methods=['get'])
    def default(self, request):
        """获取默认银行账户"""
        try:
            # 获取当前媒体主
            media = request.user.owned_media.first()
            if not media:
                return Response({"detail": "用户没有关联的媒体"}, status=status.HTTP_400_BAD_REQUEST)
                
            default_account = BankAccount.objects.get(media=media, is_default=True)
            serializer = self.get_serializer(default_account)
            return Response(serializer.data)
        except BankAccount.DoesNotExist:
            return Response({"detail": "未设置默认银行账户"}, status=status.HTTP_404_NOT_FOUND)


class TaxInfoViewSet(mixins.RetrieveModelMixin,
                     mixins.UpdateModelMixin,
                     viewsets.GenericViewSet):
    """税务信息视图集 - 只支持查看和更新"""
    serializer_class = TaxInfoSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_object(self):
        """获取当前媒体主的税务信息"""
        media = self.request.user.owned_media.first()
        if not media:
            raise ValidationError({"detail": "用户没有关联的媒体"})
        # 获取或创建税务信息
        tax_info, created = TaxInfo.objects.get_or_create(
            media=media,
            defaults={
                'company_name': media.name,
                'tax_id': '',
                'address': '',
                'contact_name': '',
                'contact_phone': '',
                'tax_rate': 0
            }
        )
        return tax_info


class SettlementPeriodViewSet(mixins.RetrieveModelMixin,
                              mixins.UpdateModelMixin,
                              viewsets.GenericViewSet):
    """结算周期视图集 - 只支持查看和更新"""
    serializer_class = SettlementPeriodSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_object(self):
        """获取当前媒体主的结算周期设置"""
        media = self.request.user.owned_media.first()
        if not media:
            raise ValidationError({"detail": "用户没有关联的媒体"})
        # 获取或创建结算周期设置
        period, created = SettlementPeriod.objects.get_or_create(
            media=media,
            defaults={
                'period_type': 'monthly',
                'payment_day': 15,
                'minimum_payment': 0
            }
        )
        return period


class RevenueViewSet(mixins.ListModelMixin,
                     mixins.RetrieveModelMixin,
                     viewsets.GenericViewSet):
    """收入记录视图集 - 只支持查看"""
    serializer_class = RevenueSerializer
    pagination_class = MyPageNumberPagination
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        """获取当前媒体主的收入记录，支持多种筛选"""
        queryset = Revenue.objects.filter(media__owner=self.request.user)

        # 日期范围筛选
        start_date = self.request.query_params.get('start_date')
        end_date = self.request.query_params.get('end_date')
        if start_date:
            queryset = queryset.filter(date__gte=start_date)
        if end_date:
            queryset = queryset.filter(date__lte=end_date)

        # 状态筛选
        status_param = self.request.query_params.get('status')
        if status_param:
            queryset = queryset.filter(status=status_param)

        # 广告位筛选
        placement_id = self.request.query_params.get('placement_id')
        if placement_id:
            queryset = queryset.filter(placement_id=placement_id)

        return queryset.order_by('-date')

    @action(detail=False, methods=['get'])
    def summary(self, request):
        """获取收入汇总数据"""
        # 获取日期范围参数
        today = timezone.now().date()
        start_date = request.query_params.get('start_date', (today - timedelta(days=30)).isoformat())
        end_date = request.query_params.get('end_date', today.isoformat())

        # 按货币分组汇总
        revenues = Revenue.objects.filter(
            media__owner=request.user,
            date__gte=start_date,
            date__lte=end_date
        )

        # 如果没有数据，返回空结果
        if not revenues.exists():
            empty_summary = {
                'start_date': start_date,
                'end_date': end_date,
                'total_impressions': 0,
                'total_clicks': 0,
                'total_revenue': 0,
                'average_ecpm': 0,
                'currency': 'CNY'
            }
            serializer = RevenueSummarySerializer(empty_summary)
            return Response(serializer.data)

        # 默认使用CNY作为汇总货币
        currency = request.query_params.get('currency', 'CNY')
        currency_revenues = revenues.filter(currency=currency)

        # 计算汇总数据
        summary = currency_revenues.aggregate(
            total_impressions=Sum('impressions'),
            total_clicks=Sum('clicks'),
            total_revenue=Sum('revenue_amount'),
            average_ecpm=Avg('ecpm')
        )

        # 构建响应数据
        summary_data = {
            'start_date': start_date,
            'end_date': end_date,
            'total_impressions': summary['total_impressions'] or 0,
            'total_clicks': summary['total_clicks'] or 0,
            'total_revenue': summary['total_revenue'] or 0,
            'average_ecpm': summary['average_ecpm'] or 0,
            'currency': currency
        }

        serializer = RevenueSummarySerializer(summary_data)
        return Response(serializer.data)


class InvoiceViewSet(mixins.ListModelMixin,
                     mixins.RetrieveModelMixin,
                     mixins.CreateModelMixin,
                     viewsets.GenericViewSet):
    """发票管理视图集"""
    serializer_class = InvoiceSerializer
    pagination_class = MyPageNumberPagination
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        """获取当前媒体主的发票记录"""
        queryset = Invoice.objects.filter(media__owner=self.request.user)

        # 状态筛选
        status_param = self.request.query_params.get('status')
        if status_param:
            queryset = queryset.filter(status=status_param)

        # 日期范围筛选
        start_date = self.request.query_params.get('start_date')
        end_date = self.request.query_params.get('end_date')
        if start_date:
            queryset = queryset.filter(issue_date__gte=start_date)
        if end_date:
            queryset = queryset.filter(issue_date__lte=end_date)

        return queryset.order_by('-issue_date')

    def create(self, request, *args, **kwargs):
        """创建发票申请"""
        # 使用专用的发票申请序列化器
        serializer = InvoiceRequestSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        # 获取验证后的数据
        start_date = serializer.validated_data['start_date']
        end_date = serializer.validated_data['end_date']
        notes = serializer.validated_data.get('notes', '')

        # 获取当前媒体主
        media = request.user.owned_media.first()
        if not media:
            return Response(
                {"detail": "用户没有关联的媒体"},
                status=status.HTTP_400_BAD_REQUEST
            )

        # 检查是否已有该日期范围的发票
        existing_invoice = Invoice.objects.filter(
            media=media,
            start_date=start_date,
            end_date=end_date
        ).exists()

        if existing_invoice:
            return Response(
                {"detail": "相同日期范围的发票已存在"},
                status=status.HTTP_400_BAD_REQUEST
            )

        # 获取该日期范围的收入记录
        revenues = Revenue.objects.filter(
            media=media,
            date__gte=start_date,
            date__lte=end_date,
            status='pending'  # 只处理待结算的收入
        )

        if not revenues.exists():
            return Response(
                {"detail": "所选日期范围内没有待结算的收入"},
                status=status.HTTP_400_BAD_REQUEST
            )

        # 计算总金额
        summary = revenues.aggregate(
            total_amount=Sum('revenue_amount')
        )
        total_amount = summary['total_amount']

        # 获取税务信息
        try:
            tax_info = TaxInfo.objects.get(media=media)
            tax_rate = tax_info.tax_rate
        except TaxInfo.DoesNotExist:
            tax_rate = 0

        # 计算税额
        tax_amount = total_amount * (tax_rate / 100)

        # 生成发票编号
        invoice_number = f"INV-{media.id}-{datetime.now().strftime('%Y%m%d')}-{uuid.uuid4().hex[:6].upper()}"

        # 创建发票
        with transaction.atomic():
            invoice = Invoice.objects.create(
                media=media,
                invoice_number=invoice_number,
                issue_date=timezone.now().date(),
                due_date=timezone.now().date() + timedelta(days=30),  # 默认30天后到期
                start_date=start_date,
                end_date=end_date,
                amount=total_amount,
                tax_amount=tax_amount,
                total_amount=total_amount + tax_amount,
                currency='CNY',  # 默认使用CNY
                status='draft',
                notes=notes
            )

            # 更新收入记录状态
            revenues.update(status='processing', settlement_id=invoice_number)

        # 返回创建的发票信息
        invoice_serializer = InvoiceSerializer(invoice)
        return Response(invoice_serializer.data, status=status.HTTP_201_CREATED)


class PaymentViewSet(mixins.ListModelMixin,
                     mixins.RetrieveModelMixin,
                     viewsets.GenericViewSet):
    """支付记录视图集 - 只支持查看"""
    serializer_class = PaymentSerializer
    pagination_class = MyPageNumberPagination
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        """获取当前媒体主的支付记录"""
        queryset = Payment.objects.filter(media__owner=self.request.user)

        # 状态筛选
        status_param = self.request.query_params.get('status')
        if status_param:
            queryset = queryset.filter(status=status_param)

        # 日期范围筛选
        start_date = self.request.query_params.get('start_date')
        end_date = self.request.query_params.get('end_date')
        if start_date:
            queryset = queryset.filter(payment_date__gte=start_date)
        if end_date:
            queryset = queryset.filter(payment_date__lte=end_date)

        return queryset.order_by('-payment_date')
