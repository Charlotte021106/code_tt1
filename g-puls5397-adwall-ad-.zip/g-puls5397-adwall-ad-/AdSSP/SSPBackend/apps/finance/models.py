from django.db import models
from django.utils.translation import gettext_lazy as _
from placement.models import AdPlacement
from media.models import Media


class BankAccount(models.Model):
    """媒体主银行账户信息"""
    media = models.ForeignKey(Media, on_delete=models.CASCADE, related_name='bank_accounts', verbose_name=_('媒体主'))
    account_name = models.CharField(max_length=100, verbose_name=_('账户名称'))
    bank_name = models.CharField(max_length=100, verbose_name=_('银行名称'))
    account_number = models.CharField(max_length=50, verbose_name=_('账号'))
    branch_name = models.CharField(max_length=100, blank=True, null=True, verbose_name=_('支行名称'))
    swift_code = models.CharField(max_length=20, blank=True, null=True, verbose_name=_('Swift代码'))
    is_default = models.BooleanField(default=False, verbose_name=_('是否默认账户'))
    created_at = models.DateTimeField(auto_now_add=True, verbose_name=_('创建时间'))
    updated_at = models.DateTimeField(auto_now=True, verbose_name=_('更新时间'))

    class Meta:
        verbose_name = _('银行账户')
        verbose_name_plural = _('银行账户')
        ordering = ['-is_default', '-created_at']

    def __str__(self):
        return f"{self.media.name} - {self.account_name}"


class TaxInfo(models.Model):
    """税务信息"""
    media = models.OneToOneField(Media, on_delete=models.CASCADE, related_name='tax_info', verbose_name=_('媒体主'))
    company_name = models.CharField(max_length=200, verbose_name=_('公司名称'))
    tax_id = models.CharField(max_length=50, verbose_name=_('税号'))
    address = models.TextField(verbose_name=_('注册地址'))
    contact_name = models.CharField(max_length=100, verbose_name=_('联系人'))
    contact_phone = models.CharField(max_length=20, verbose_name=_('联系电话'))
    tax_rate = models.DecimalField(max_digits=5, decimal_places=2, default=0, verbose_name=_('税率(%)'))
    created_at = models.DateTimeField(auto_now_add=True, verbose_name=_('创建时间'))
    updated_at = models.DateTimeField(auto_now=True, verbose_name=_('更新时间'))

    class Meta:
        verbose_name = _('税务信息')
        verbose_name_plural = _('税务信息')

    def __str__(self):
        return f"{self.company_name} - {self.tax_id}"


class SettlementPeriod(models.Model):
    """结算周期设置"""
    PERIOD_CHOICES = (
        ('weekly', _('每周')),
        ('biweekly', _('双周')),
        ('monthly', _('每月')),
        ('quarterly', _('每季度')),
    )
    
    media = models.OneToOneField(Media, on_delete=models.CASCADE, related_name='settlement_period', verbose_name=_('媒体主'))
    period_type = models.CharField(max_length=20, choices=PERIOD_CHOICES, default='monthly', verbose_name=_('结算周期类型'))
    payment_day = models.PositiveSmallIntegerField(default=15, verbose_name=_('付款日(天)'))
    minimum_payment = models.DecimalField(max_digits=10, decimal_places=2, default=0, verbose_name=_('最低付款金额'))
    created_at = models.DateTimeField(auto_now_add=True, verbose_name=_('创建时间'))
    updated_at = models.DateTimeField(auto_now=True, verbose_name=_('更新时间'))

    class Meta:
        verbose_name = _('结算周期')
        verbose_name_plural = _('结算周期')

    def __str__(self):
        return f"{self.media.name} - {self.get_period_type_display()}"


class Revenue(models.Model):
    """收入记录"""
    STATUS_CHOICES = (
        ('pending', _('待结算')),
        ('processing', _('结算中')),
        ('completed', _('已结算')),
        ('failed', _('失败')),
    )
    
    media = models.ForeignKey(Media, on_delete=models.CASCADE, related_name='revenues', verbose_name=_('媒体主'))
    placement = models.ForeignKey(AdPlacement, on_delete=models.SET_NULL, null=True, related_name='revenues', verbose_name=_('广告位'))
    date = models.DateField(verbose_name=_('收入日期'))
    impressions = models.PositiveIntegerField(default=0, verbose_name=_('展示次数'))
    clicks = models.PositiveIntegerField(default=0, verbose_name=_('点击次数'))
    revenue_amount = models.DecimalField(max_digits=12, decimal_places=4, verbose_name=_('收入金额'))
    currency = models.CharField(max_length=3, default='CNY', verbose_name=_('货币'))
    ecpm = models.DecimalField(max_digits=10, decimal_places=4, verbose_name=_('eCPM'))
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending', verbose_name=_('状态'))
    settlement_id = models.CharField(max_length=50, blank=True, null=True, verbose_name=_('结算ID'))
    created_at = models.DateTimeField(auto_now_add=True, verbose_name=_('创建时间'))
    updated_at = models.DateTimeField(auto_now=True, verbose_name=_('更新时间'))

    class Meta:
        verbose_name = _('收入记录')
        verbose_name_plural = _('收入记录')
        ordering = ['-date']
        indexes = [
            models.Index(fields=['media', 'date']),
            models.Index(fields=['placement', 'date']),
            models.Index(fields=['status']),
        ]

    def __str__(self):
        return f"{self.media.name} - {self.date} - {self.revenue_amount} {self.currency}"


class Invoice(models.Model):
    """发票管理"""
    STATUS_CHOICES = (
        ('draft', _('草稿')),
        ('pending', _('待处理')),
        ('issued', _('已开具')),
        ('paid', _('已支付')),
        ('cancelled', _('已取消')),
    )
    
    media = models.ForeignKey(Media, on_delete=models.CASCADE, related_name='invoices', verbose_name=_('媒体主'))
    invoice_number = models.CharField(max_length=50, unique=True, verbose_name=_('发票编号'))
    issue_date = models.DateField(verbose_name=_('开具日期'))
    due_date = models.DateField(verbose_name=_('截止日期'))
    start_date = models.DateField(verbose_name=_('结算开始日期'))
    end_date = models.DateField(verbose_name=_('结算结束日期'))
    amount = models.DecimalField(max_digits=12, decimal_places=2, verbose_name=_('金额'))
    tax_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0, verbose_name=_('税额'))
    total_amount = models.DecimalField(max_digits=12, decimal_places=2, verbose_name=_('总金额'))
    currency = models.CharField(max_length=3, default='CNY', verbose_name=_('货币'))
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='draft', verbose_name=_('状态'))
    notes = models.TextField(blank=True, null=True, verbose_name=_('备注'))
    created_at = models.DateTimeField(auto_now_add=True, verbose_name=_('创建时间'))
    updated_at = models.DateTimeField(auto_now=True, verbose_name=_('更新时间'))

    class Meta:
        verbose_name = _('发票')
        verbose_name_plural = _('发票')
        ordering = ['-issue_date']

    def __str__(self):
        return f"{self.invoice_number} - {self.media.name} - {self.total_amount} {self.currency}"


class Payment(models.Model):
    """支付记录"""
    STATUS_CHOICES = (
        ('pending', _('待付款')),
        ('processing', _('处理中')),
        ('completed', _('已完成')),
        ('failed', _('失败')),
        ('cancelled', _('已取消')),
    )
    
    media = models.ForeignKey(Media, on_delete=models.CASCADE, related_name='payments', verbose_name=_('媒体主'))
    invoice = models.ForeignKey(Invoice, on_delete=models.SET_NULL, null=True, blank=True, related_name='payments', verbose_name=_('发票'))
    payment_number = models.CharField(max_length=50, unique=True, verbose_name=_('付款编号'))
    bank_account = models.ForeignKey(BankAccount, on_delete=models.SET_NULL, null=True, related_name='payments', verbose_name=_('收款账户'))
    amount = models.DecimalField(max_digits=12, decimal_places=2, verbose_name=_('金额'))
    currency = models.CharField(max_length=3, default='CNY', verbose_name=_('货币'))
    payment_date = models.DateField(verbose_name=_('付款日期'))
    transaction_id = models.CharField(max_length=100, blank=True, null=True, verbose_name=_('交易ID'))
    payment_method = models.CharField(max_length=50, verbose_name=_('支付方式'))
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending', verbose_name=_('状态'))
    notes = models.TextField(blank=True, null=True, verbose_name=_('备注'))
    created_at = models.DateTimeField(auto_now_add=True, verbose_name=_('创建时间'))
    updated_at = models.DateTimeField(auto_now=True, verbose_name=_('更新时间'))

    class Meta:
        verbose_name = _('支付记录')
        verbose_name_plural = _('支付记录')
        ordering = ['-payment_date']

    def __str__(self):
        return f"{self.payment_number} - {self.media.name} - {self.amount} {self.currency}"
