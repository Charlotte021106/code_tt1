from django.core.management.base import BaseCommand, CommandError
from django.utils import timezone
from django.db import transaction
from datetime import timedelta, datetime
from decimal import Decimal
import random
import logging
import uuid

from finance.models import (
    BankAccount, Revenue, Invoice, Payment, TaxInfo, SettlementPeriod
)
from media.models import Media

logger = logging.getLogger(__name__)


class Command(BaseCommand):
    """
    为财务应用生成测试数据
    
    参数:
    --media_id: 要生成数据的媒体ID，不提供则为所有活跃媒体生成数据
    --days: 生成多少天的数据，默认30天
    --clear: 清除指定日期范围内的现有数据后再生成
    --start_date: 数据开始日期，格式YYYY-MM-DD，默认为30天前
    --trend_type: 数据趋势类型，可选值：
        random: 随机波动（默认）
        increasing: 递增趋势 - 数据逐渐增长
        decreasing: 递减趋势 - 数据逐渐下降
        stable: 稳定趋势 - 小幅波动
    """

    help = '为财务应用生成测试数据'

    def add_arguments(self, parser):
        parser.add_argument(
            '--media_id',
            help='媒体ID，不提供则为所有媒体生成数据',
        )
        parser.add_argument(
            '--days',
            type=int,
            default=30,
            help='生成多少天的数据，默认30天',
        )
        parser.add_argument(
            '--clear',
            action='store_true',
            help='清除现有数据后再生成',
        )
        parser.add_argument(
            '--start_date',
            help='开始日期，格式YYYY-MM-DD，默认为30天前',
        )
        parser.add_argument(
            '--trend_type',
            choices=['random', 'increasing', 'decreasing', 'stable'],
            default='random',
            help='数据趋势类型：随机、递增、递减或稳定'
        )

    def handle(self, *args, **options):
        media_id = options.get('media_id')
        days = options.get('days')
        clear = options.get('clear')
        trend_type = options.get('trend_type')
        start_date_str = options.get('start_date')

        # 确定开始日期
        if start_date_str:
            try:
                start_date = timezone.datetime.strptime(start_date_str, '%Y-%m-%d').date()
            except ValueError:
                raise CommandError(f'无效的日期格式: {start_date_str}，请使用YYYY-MM-DD格式')
        else:
            start_date = timezone.now().date() - timedelta(days=days - 1)

        end_date = start_date + timedelta(days=days - 1)

        # 查找媒体
        try:
            if media_id:
                medias = Media.objects.filter(id=media_id)
                if not medias.exists():
                    raise CommandError(f'媒体 {media_id} 不存在')
            else:
                medias = Media.objects.filter(status='active')

            if not medias:
                self.stdout.write(self.style.WARNING('没有找到可用的媒体，请先创建媒体'))
                return

            # 显示生成信息
            self.stdout.write(self.style.SUCCESS(f'准备生成从 {start_date} 到 {end_date} 的{days}天财务数据'))
            self.stdout.write(self.style.SUCCESS(f'数据趋势类型: {trend_type}'))

            total_created = 0

            for media in medias:
                if clear:
                    # 清除现有数据
                    Revenue.objects.filter(media=media).delete()
                    Invoice.objects.filter(media=media).delete()
                    Payment.objects.filter(media=media).delete()
                    self.stdout.write(self.style.WARNING(f'已清除媒体 {media.name} 的现有数据'))

                # 创建或更新税务信息
                tax_info, _ = TaxInfo.objects.get_or_create(
                    media=media,
                    defaults={
                        'company_name': f"{media.name}科技有限公司",
                        'tax_id': f"91110000{random.randint(10000000, 99999999)}",
                        'address': '北京市朝阳区xxx街xxx号',
                        'contact_name': '张三',
                        'contact_phone': f"1{random.randint(3,9)}{random.randint(100000000, 999999999)}",
                        'tax_rate': random.choice([0, 3, 6, 9, 13])
                    }
                )

                # 创建或更新结算周期
                settlement_period, _ = SettlementPeriod.objects.get_or_create(
                    media=media,
                    defaults={
                        'period_type': random.choice(['weekly', 'biweekly', 'monthly', 'quarterly']),
                        'payment_day': random.randint(1, 28),
                        'minimum_payment': random.choice([0, 1000, 5000, 10000])
                    }
                )

                # 创建银行账户
                bank_accounts = []
                for i in range(random.randint(1, 3)):
                    account = BankAccount.objects.create(
                        media=media,
                        account_name=f"{media.name}公司账户{i+1}",
                        bank_name=random.choice(['工商银行', '建设银行', '农业银行', '中国银行']),
                        account_number=f"{random.randint(1000000000000000000, 9999999999999999999)}",
                        branch_name=f"{random.choice(['北京', '上海', '广州', '深圳'])}分行",
                        is_default=(i == 0)
                    )
                    bank_accounts.append(account)

                # 生成收入数据
                revenue_data = self._generate_revenue_data(media, start_date, end_date, trend_type)
                total_created += len(revenue_data)

                # 生成发票和支付数据
                self._generate_invoice_and_payment_data(media, revenue_data, bank_accounts)

                self.stdout.write(self.style.SUCCESS(
                    f'已为媒体 {media.name} 生成 {len(revenue_data)} 条财务数据记录'))

            self.stdout.write(self.style.SUCCESS(f'总共生成 {total_created} 条财务数据记录'))

        except Exception as e:
            self.stdout.write(self.style.ERROR(f'生成测试数据失败: {str(e)}'))
            raise

    def _generate_revenue_data(self, media, start_date, end_date, trend_type):
        """生成收入数据"""
        revenue_data = []
        current_date = start_date
        day_index = 0
        total_days = (end_date - start_date).days + 1

        # 基础值
        base_revenue = random.uniform(100.0, 1000.0)
        base_impressions = random.randint(10000, 100000)
        base_clicks = random.randint(100, 1000)

        while current_date <= end_date:
            # 计算趋势因子
            if trend_type == 'increasing':
                trend_factor = 1.0 + (day_index / total_days)
            elif trend_type == 'decreasing':
                trend_factor = 1.0 - (0.5 * day_index / total_days)
            elif trend_type == 'stable':
                trend_factor = random.uniform(0.95, 1.05)
            else:  # random
                trend_factor = random.uniform(0.7, 1.3)

            # 生成数据
            impressions = max(1, int(base_impressions * trend_factor))
            clicks = max(1, int(base_clicks * trend_factor))
            revenue = max(Decimal('0.1'), Decimal(str(round(base_revenue * trend_factor, 2))))
            ecpm = (revenue / Decimal(impressions)) * Decimal('1000') if impressions > 0 else Decimal('0')

            # 创建收入记录
            revenue_obj = Revenue.objects.create(
                media=media,
                date=current_date,
                impressions=impressions,
                clicks=clicks,
                revenue_amount=revenue,
                currency='CNY',
                ecpm=ecpm,
                status=random.choice(['pending', 'processing', 'completed'])
            )
            revenue_data.append(revenue_obj)

            current_date += timedelta(days=1)
            day_index += 1

        return revenue_data

    def _generate_invoice_and_payment_data(self, media, revenue_data, bank_accounts):
        """生成发票和支付数据"""
        # 按月份分组收入数据
        revenue_by_month = {}
        for revenue in revenue_data:
            month_key = revenue.date.replace(day=1)
            if month_key not in revenue_by_month:
                revenue_by_month[month_key] = []
            revenue_by_month[month_key].append(revenue)

        # 为每个月生成发票
        for month_start, month_revenues in revenue_by_month.items():
            # 计算月收入总额
            total_amount = sum(r.revenue_amount for r in month_revenues)
            if total_amount <= 0:
                continue

            # 获取税务信息
            tax_info = TaxInfo.objects.get(media=media)
            tax_rate = Decimal(str(tax_info.tax_rate))
            tax_amount = total_amount * (tax_rate / Decimal('100'))

            # 创建发票
            invoice = Invoice.objects.create(
                media=media,
                invoice_number=f"INV-{media.id}-{month_start.strftime('%Y%m%d')}-{uuid.uuid4().hex[:6].upper()}",
                issue_date=month_start + timedelta(days=random.randint(1, 5)),
                due_date=month_start + timedelta(days=random.randint(25, 35)),
                start_date=month_start,
                end_date=month_start + timedelta(days=30),
                amount=total_amount,
                tax_amount=tax_amount,
                total_amount=total_amount + tax_amount,
                currency='CNY',
                status=random.choice(['draft', 'pending', 'issued', 'paid']),
                notes=f"{month_start.strftime('%Y年%m月')}广告收入"
            )

            # 如果发票状态为已支付，创建支付记录
            if invoice.status == 'paid':
                payment = Payment.objects.create(
                    media=media,
                    invoice=invoice,
                    payment_number=f"PAY-{invoice.invoice_number}",
                    bank_account=random.choice(bank_accounts),
                    amount=invoice.total_amount,
                    currency='CNY',
                    payment_date=invoice.issue_date + timedelta(days=random.randint(1, 10)),
                    payment_method=random.choice(['银行转账', '支付宝', '微信支付']),
                    status='completed',
                    notes=f"支付{invoice.invoice_number}发票"
                )

            # 更新收入记录状态
            for revenue in month_revenues:
                revenue.status = 'completed'
                revenue.settlement_id = invoice.invoice_number
                revenue.save() 