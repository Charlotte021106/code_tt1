from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (
    BankAccountViewSet, TaxInfoViewSet, SettlementPeriodViewSet,
    RevenueViewSet, InvoiceViewSet, PaymentViewSet
)


router = DefaultRouter()
router.register(r'bank-accounts', BankAccountViewSet, basename='bank-account')
router.register(r'tax-info', TaxInfoViewSet, basename='tax-info')
router.register(r'settlement-period', SettlementPeriodViewSet, basename='settlement-period')
router.register(r'revenues', RevenueViewSet, basename='revenue')
router.register(r'invoices', InvoiceViewSet, basename='invoice')
router.register(r'payments', PaymentViewSet, basename='payment')

app_name = 'finance'
urlpatterns = [
    path('', include(router.urls)),
] 