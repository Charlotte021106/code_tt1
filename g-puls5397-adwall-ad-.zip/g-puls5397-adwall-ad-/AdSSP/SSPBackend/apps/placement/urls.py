from rest_framework.routers import DefaultRouter
from .views import *

urlpatterns = [
]
router = DefaultRouter()
router.register(r'types', PlacementTypeViewSet, basename='placement-type')
router.register('configs', PlacementConfigViewSet, basename='placement-config')
router.register('targeting', PlacementTargetingViewSet, basename='placement-targeting')
router.register('performance', PlacementPerformanceViewSet, basename='placement-performance')
router.register('optimization', PlacementOptimizationViewSet, basename='placement-optimization')
router.register('', AdPlacementViewSet, basename='placement')
'''
这里的 ''（空字符串）作为 URL 前缀，表示这个路由会匹配所有未被其他路由匹配的路径。
务必放最后！！
当 URL 路径是 /placement/ 时，会匹配到这个路由
当 URL 路径是 /placement/123/ 时，也会匹配到这个路由
当 URL 路径是 /placement/123/update/ 时，同样会匹配到这个路由
'''

urlpatterns += router.urls
