from django.core.management.base import BaseCommand, CommandError
from django.utils import timezone
from datetime import timedelta
import random
import logging

from placement.models import (
    AdPlacement, PlacementPerformance, PlacementOptimization
)

logger = logging.getLogger(__name__)


class Command(BaseCommand):
    """
    --placement_id: 要生成数据的广告位ID，不提供则为所有活跃广告位生成数据
    --days: 生成多少天的数据，默认30天
    --clear: 清除指定日期范围内的现有数据后再生成
    --start_date: 数据开始日期，格式YYYY-MM-DD，默认为30天前
    --trend_type: 数据趋势类型，可选值：
    random: 随机波动（默认）
    increasing: 递增趋势 - 数据逐渐增长
    decreasing: 递减趋势 - 数据逐渐下降
    stable: 稳定趋势 - 小幅波动
    """

    help = '为现有广告位生成性能测试数据'

    def add_arguments(self, parser):
        parser.add_argument(
            '--placement_id',
            help='广告位ID，不提供则为所有广告位生成数据',
        )
        parser.add_argument(
            '--days',
            type=int,
            default=30,
            help='生成多少天的数据，默认30天',
        )
        parser.add_argument(
            '--clear',
            action='store_true',
            help='清除现有数据后再生成',
        )
        parser.add_argument(
            '--start_date',
            help='开始日期，格式YYYY-MM-DD，默认为30天前',
        )
        parser.add_argument(
            '--trend_type',
            choices=['random', 'increasing', 'decreasing', 'stable'],
            default='random',
            help='数据趋势类型：随机、递增、递减或稳定'
        )

    def handle(self, *args, **options):
        placement_id = options.get('placement_id')
        days = options.get('days')
        clear = options.get('clear')
        trend_type = options.get('trend_type')
        start_date_str = options.get('start_date')

        # 确定开始日期
        if start_date_str:
            try:
                start_date = timezone.datetime.strptime(start_date_str, '%Y-%m-%d').date()
            except ValueError:
                raise CommandError(f'无效的日期格式: {start_date_str}，请使用YYYY-MM-DD格式')
        else:
            start_date = timezone.now().date() - timedelta(days=days - 1)

        end_date = start_date + timedelta(days=days - 1)

        # 查找广告位
        try:
            if placement_id:
                placements = AdPlacement.objects.filter(placement_id=placement_id)
                if not placements.exists():
                    raise CommandError(f'广告位 {placement_id} 不存在')
            else:
                placements = AdPlacement.objects.filter(status='active')

            if not placements:
                self.stdout.write(self.style.WARNING('没有找到可用的广告位，请先创建广告位'))
                return

            # 显示生成信息
            self.stdout.write(self.style.SUCCESS(f'准备生成从 {start_date} 到 {end_date} 的{days}天性能数据'))
            self.stdout.write(self.style.SUCCESS(f'数据趋势类型: {trend_type}'))

            total_created = 0

            for placement in placements:
                if clear:
                    # 清除现有数据
                    deleted_count = PlacementPerformance.objects.filter(placement=placement).delete()[0]
                    self.stdout.write(
                        self.style.WARNING(f'已清除广告位 {placement.name} 的 {deleted_count} 条现有数据'))

                # 检查现有数据
                existing_dates = set(PlacementPerformance.objects.filter(
                    placement=placement,
                    date__gte=start_date,
                    date__lte=end_date
                ).values_list('date', flat=True))

                performance_data = []
                current_date = start_date

                # 根据趋势类型确定基础数据和变化率
                base_values = self._get_base_values(trend_type)

                created_count = 0
                day_index = 0

                while current_date <= end_date:
                    # 跳过已有数据的日期（除非要清除）
                    if current_date in existing_dates and not clear:
                        current_date += timedelta(days=1)
                        day_index += 1
                        continue

                    # 生成当天数据
                    day_data = self._generate_day_data(base_values, day_index, days, trend_type, current_date)

                    # 创建性能数据记录
                    performance = PlacementPerformance.objects.create(
                        placement=placement,
                        date=current_date,
                        **day_data
                    )

                    performance_data.append(performance)
                    created_count += 1
                    current_date += timedelta(days=1)
                    day_index += 1

                # 生成优化建议
                self._generate_optimization_suggestions(placement)

                self.stdout.write(self.style.SUCCESS(
                    f'已为广告位 {placement.name} ({placement.placement_id}) 生成 {created_count} 天测试数据'))
                total_created += created_count

            self.stdout.write(self.style.SUCCESS(f'总共生成 {total_created} 条性能数据记录'))

        except Exception as e:
            self.stdout.write(self.style.ERROR(f'生成测试数据失败: {str(e)}'))
            raise

    def _get_base_values(self, trend_type):
        """获取基础值"""
        return {
            'impressions': random.randint(1000, 5000),
            'clicks': random.randint(50, 200),
            'revenue': random.uniform(10.0, 50.0),
            'viewability': random.uniform(60.0, 95.0),
            'bounce_rate': random.uniform(10.0, 40.0),
            'avg_view_time': random.uniform(5.0, 30.0),
            'fill_rate': random.uniform(70.0, 95.0),
        }

    def _generate_day_data(self, base_values, day_index, total_days, trend_type, current_date):
        """生成单日数据"""
        # 基本随机变化因子
        daily_factor = random.uniform(0.8, 1.2)

        # 工作日和周末因子 (工作日流量更高)
        weekday_factor = 1.0 + (0.2 if current_date.weekday() < 5 else -0.2)

        # 根据趋势类型计算趋势因子
        if trend_type == 'increasing':
            # 递增：从基础值逐渐提高到基础值的2倍
            trend_factor = 1.0 + (day_index / total_days)
        elif trend_type == 'decreasing':
            # 递减：从基础值逐渐降低到基础值的一半
            trend_factor = 1.0 - (0.5 * day_index / total_days)
        elif trend_type == 'stable':
            # 稳定：小范围波动
            trend_factor = random.uniform(0.95, 1.05)
        else:  # random
            # 随机：较大范围波动
            trend_factor = random.uniform(0.7, 1.3)

        # 计算最终因子
        final_factor = daily_factor * weekday_factor * trend_factor

        # 生成数据
        impressions = max(1, int(base_values['impressions'] * final_factor))
        clicks = max(1, int(base_values['clicks'] * final_factor))
        revenue = max(0.1, round(base_values['revenue'] * final_factor, 2))

        # 这些指标有最大值限制，不能无限增长
        viewability = max(10.0, min(100.0, base_values['viewability'] * random.uniform(0.9, 1.1)))
        bounce_rate = max(5.0, min(90.0, base_values['bounce_rate'] * random.uniform(0.9, 1.1)))
        avg_view_time = max(1.0, base_values['avg_view_time'] * random.uniform(0.9, 1.1))
        fill_rate = max(10.0, min(100.0, base_values['fill_rate'] * random.uniform(0.9, 1.1)))

        # 计算CTR、CPM和CPC
        ctr = (clicks / impressions) * 100 if impressions > 0 else 0
        cpm = (revenue / impressions) * 1000 if impressions > 0 else 0
        cpc = revenue / clicks if clicks > 0 else 0

        return {
            'impressions': impressions,
            'clicks': clicks,
            'revenue': revenue,
            'ctr': ctr,
            'viewability': viewability,
            'bounce_rate': bounce_rate,
            'avg_view_time': avg_view_time,
            'cpm': cpm,
            'cpc': cpc,
            'fill_rate': fill_rate
        }

    def _generate_optimization_suggestions(self, placement):
        """生成测试优化建议"""
        # 如果该广告位已有优化建议，不再重复创建
        if PlacementOptimization.objects.filter(placement=placement).exists():
            return

        # 创建测试优化建议
        suggestions = [
            {
                'issue_type': 'low_ctr',
                'description': '广告位点击率低于行业平均水平',
                'suggestion': '建议调整广告位置、改进创意或优化目标人群',
                'status': 'pending'
            },
            {
                'issue_type': 'low_viewability',
                'description': '广告位可见率较低，用户可能看不到广告',
                'suggestion': '将广告位移至页面更醒目位置或调整页面布局',
                'status': 'processing'
            },
            {
                'issue_type': 'revenue_optimization',
                'description': '广告位收益低于其他位置',
                'suggestion': '考虑调整广告位价格或切换广告形式以提高收益',
                'status': 'completed'
            },
            {
                'issue_type': 'high_bounce',
                'description': '广告位跳出率高于平均水平',
                'suggestion': '优化落地页体验或调整广告定向精准度',
                'status': 'pending'
            }
        ]

        for suggestion in suggestions:
            PlacementOptimization.objects.create(
                placement=placement,
                **suggestion
            )

        self.stdout.write(self.style.SUCCESS(f'已为广告位 {placement.name} 创建 {len(suggestions)} 条优化建议'))
