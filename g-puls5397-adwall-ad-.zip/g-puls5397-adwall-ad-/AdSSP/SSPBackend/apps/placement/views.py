from rest_framework import viewsets, filters
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django.db.models import Count, Sum, Avg
from utils.filters import MyPageNumberPagination
from .models import (
    AdPlacement, PlacementType, PlacementConfig, PlacementOptimization, PlacementPerformance, PlacementTargeting
)
from .serializers import (
    AdPlacementSerializer, PlacementTypeSerializer, PlacementConfigSerializer, PlacementConnectionSerializer,
    PlacementDetailSerializer, PlacementOptimizationSerializer, PlacementPerformanceSerializer,
    PlacementTargetingSerializer
)
from django.utils import timezone
from datetime import timedelta


class PlacementTypeViewSet(viewsets.ModelViewSet):
    """广告位类型视图集
    提供广告位类型的增删改查功能。

    ## 请求示例
    - **GET** /placement/types/ - 获取所有广告位类型
    - **POST** /placement/types/ - 创建新的广告位类型
    - **GET** /placement/types/{id}/ - 获取指定广告位类型
    - **PUT** /placement/types/{id}/ - 更新指定广告位类型
    - **DELETE** /placement/types/{id}/ - 删除指定广告位类型
    """
    queryset = PlacementType.objects.all()
    serializer_class = PlacementTypeSerializer
    permission_classes = [IsAuthenticated]


class PlacementConfigViewSet(viewsets.ModelViewSet):
    """广告位配置视图集
    提供广告位配置的增删改查功能。

    ## 请求示例
    - **GET** /placement/configs/ - 获取所有广告位配置
    - **POST** /placement/configs/ - 创建新的广告位配置
    - **GET** /placement/configs/{id}/ - 获取指定广告位配置
    - **PUT** /placement/configs/{id}/ - 更新指定广告位配置
    - **DELETE** /placement/configs/{id}/ - 删除指定广告位配置
    """
    queryset = PlacementConfig.objects.all()
    serializer_class = PlacementConfigSerializer
    permission_classes = [IsAuthenticated]


class AdPlacementViewSet(viewsets.ModelViewSet):
    """广告位视图集
    提供广告位的增删改查功能。

    ## 请求示例
    - **GET** /placement/ - 获取所有广告位
    - **POST** /placement/ - 创建新的广告位
    - **GET** /placement/{id}/ - 获取指定广告位
    - **PUT** /placement/{id}/ - 更新指定广告位
    - **DELETE** /placement/{id}/ - 删除指定广告位

    ## 自定义操作
    - **POST** /placement/{id}/change_status/ - 修改广告位状态
    - **POST** /placement/{id}/toggle_active/ - 切换广告位激活状态
    - **GET** /placement/{id}/targeting/ - 获取广告位定向设置
    - **GET** /placement/{id}/connections/ - 获取广告位关联
    - **GET** /placement/{id}/performance/ - 获取广告位性能数据
    - **GET** /placement/{id}/suggestions/ - 获取广告位优化建议
    - **GET** /placement/{id}/detail/ - 获取广告位详细信息
    - **POST** /placement/batch_change_status/ - 批量修改广告位状态
    - **POST** /placement/batch_toggle_active/ - 批量切换广告位激活状态
    """
    queryset = AdPlacement.objects.all()
    serializer_class = AdPlacementSerializer
    permission_classes = [IsAuthenticated]
    pagination_class = MyPageNumberPagination
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['name', 'placement_id', 'description']
    ordering_fields = ['created_at', 'updated_at', 'name']

    def get_serializer_class(self):
        if self.action in ['retrieve', 'list']:
            # 对于详情和列表，返回包含详细信息的序列化器
            return PlacementDetailSerializer
        return AdPlacementSerializer

    def get_queryset(self):
        queryset = AdPlacement.objects.all()

        # 按类型筛选（使用类型代码）
        placement_type = self.request.query_params.get('type')
        if placement_type:
            queryset = queryset.filter(type__code=placement_type)

        # 按状态筛选
        status = self.request.query_params.get('status')
        if status:
            queryset = queryset.filter(status=status)

        # 按是否激活筛选（基于status字段）
        is_active = self.request.query_params.get('is_active')
        if is_active is not None:
            is_active = is_active.lower() == 'true'
            if is_active:
                queryset = queryset.filter(status='active')
            else:
                queryset = queryset.exclude(status='active')

        return queryset

    @action(detail=True, methods=['post'])
    def toggle_active(self, request, pk=None):
        """切换广告位激活状态"""
        placement = self.get_object()

        # 状态流转逻辑
        if placement.status == 'draft':
            placement.status = 'active'
        elif placement.status == 'active':
            placement.status = 'disabled'
        else:
            placement.status = 'active'
        placement.save()
        return Response({
            'status': 'success',
            'message': f'广告位状态已切换为：{placement.get_status_display()}',
            'current_status': placement.status
        })

    @action(detail=True, methods=['get'])
    def connections(self, request, pk=None):
        placement = self.get_object()
        connection = placement.connection  # 直接通过related_name获取
        if connection:
            serializer = PlacementConnectionSerializer(connection)
            return Response(serializer.data)
        else:
            return Response({'detail': '未找到关联信息'}, status=404)

    @action(detail=False, methods=['get'])
    def stats(self, request):
        """获取广告位统计数据"""
        # 类型分布统计
        type_stats = (
            AdPlacement.objects.values('type__name')
            .annotate(count=Count('id'))
            .order_by('-count')
        )

        # 状态分布统计（带中文显示）
        status_choices = dict(AdPlacement.STATUS_CHOICES)
        status_stats = (
            AdPlacement.objects.values('status')
            .annotate(count=Count('id'))
            .order_by('-count')
        )
        status_stats = [{
            'status_display': status_choices[item['status']],
            'status_value': item['status'],
            'count': item['count']
        } for item in status_stats]

        # 激活状态统计
        active_count = AdPlacement.objects.filter(status='active').count()
        inactive_count = AdPlacement.objects.exclude(status='active').count()

        return Response({
            'type_stats': list(type_stats),
            'status_stats': status_stats,
            'active_stats': {
                '激活': active_count,
                '非激活': inactive_count
            },
            'total': AdPlacement.objects.count()
        })


class PlacementTargetingViewSet(viewsets.ModelViewSet):
    """广告位定向设置视图集"""
    queryset = PlacementTargeting.objects.all()
    serializer_class = PlacementTargetingSerializer
    permission_classes = [IsAuthenticated]
    pagination_class = MyPageNumberPagination

    def get_queryset(self):
        queryset = PlacementTargeting.objects.all()
        placement_id = self.request.query_params.get('placement')
        if placement_id:
            queryset = queryset.filter(placement_id=placement_id)
        return queryset

    def retrieve(self, request, *args, **kwargs):
        """重写获取单个对象的方法"""
        try:
            # 从 URL 中获取 placement_id
            placement_id = kwargs.get('pk')
            # 查找对应的定向设置
            instance = PlacementTargeting.objects.get(placement_id=placement_id)
            serializer = self.get_serializer(instance)
            return Response(serializer.data)
        except PlacementTargeting.DoesNotExist:
            return Response({'detail': 'No PlacementTargeting matches the given query.'}, status=404)

    def create(self, request, *args, **kwargs):
        """重写创建方法"""
        placement_id = request.data.get('placement')
        if not placement_id:
            return Response({'detail': 'placement field is required.'}, status=400)

        # 检查是否已存在
        if PlacementTargeting.objects.filter(placement_id=placement_id).exists():
            return Response({'detail': 'PlacementTargeting already exists for this placement.'}, status=400)

        return super().create(request, *args, **kwargs)

    def update(self, request, *args, **kwargs):
        """重写更新方法"""
        try:
            placement_id = kwargs.get('pk')
            instance = PlacementTargeting.objects.get(placement_id=placement_id)
            serializer = self.get_serializer(instance, data=request.data, partial=kwargs.get('partial', False))
            serializer.is_valid(raise_exception=True)
            self.perform_update(serializer)
            return Response(serializer.data)
        except PlacementTargeting.DoesNotExist:
            return Response({'detail': 'No PlacementTargeting matches the given query.'}, status=404)


class PlacementPerformanceViewSet(viewsets.ModelViewSet):
    """广告位性能数据视图集"""
    queryset = PlacementPerformance.objects.all()
    serializer_class = PlacementPerformanceSerializer
    permission_classes = [IsAuthenticated]
    pagination_class = MyPageNumberPagination

    def get_queryset(self):
        queryset = PlacementPerformance.objects.all()
        placement_id = self.request.query_params.get('placement')
        start_date = self.request.query_params.get('start_date')
        end_date = self.request.query_params.get('end_date')

        if placement_id:
            queryset = queryset.filter(placement_id=placement_id)
        if start_date:
            queryset = queryset.filter(date__gte=start_date)
        if end_date:
            queryset = queryset.filter(date__lte=end_date)
        return queryset

    @action(detail=False, methods=['get'])
    def summary(self, request):
        """获取性能数据汇总"""
        placement_id = request.query_params.get('placement')
        start_date = request.query_params.get('start_date')
        end_date = request.query_params.get('end_date')

        queryset = self.get_queryset()

        # 计算汇总数据
        summary = queryset.aggregate(
            total_impressions=Sum('impressions'),
            total_clicks=Sum('clicks'),
            total_revenue=Sum('revenue'),
            avg_ctr=Avg('ctr'),
            avg_viewability=Avg('viewability'),
            avg_bounce_rate=Avg('bounce_rate'),
            avg_view_time=Avg('avg_view_time'),
            avg_cpm=Avg('cpm'),
            avg_cpc=Avg('cpc'),
            avg_fill_rate=Avg('fill_rate')
        )

        # 计算趋势数据（按日期分组）
        trend_data = queryset.values('date').annotate(
            impressions=Sum('impressions'),
            clicks=Sum('clicks'),
            revenue=Sum('revenue'),
            ctr=Avg('ctr'),
            viewability=Avg('viewability'),
            bounce_rate=Avg('bounce_rate'),
            avg_view_time=Avg('avg_view_time'),
            cpm=Avg('cpm'),
            cpc=Avg('cpc'),
            fill_rate=Avg('fill_rate')
        ).order_by('date')

        return Response({
            'summary': summary,
            'trend': trend_data
        })

    @action(detail=False, methods=['get'])
    def daily_stats(self, request):
        """获取每日统计数据"""
        placement_id = request.query_params.get('placement')
        days = int(request.query_params.get('days', 7))  # 默认最近7天

        end_date = timezone.now().date()
        start_date = end_date - timedelta(days=days - 1)

        queryset = self.get_queryset().filter(
            date__gte=start_date,
            date__lte=end_date
        )

        if placement_id:
            queryset = queryset.filter(placement_id=placement_id)

        daily_stats = queryset.values('date').annotate(
            impressions=Sum('impressions'),
            clicks=Sum('clicks'),
            revenue=Sum('revenue'),
            ctr=Avg('ctr'),
            viewability=Avg('viewability'),
            bounce_rate=Avg('bounce_rate'),
            avg_view_time=Avg('avg_view_time'),
            cpm=Avg('cpm'),
            cpc=Avg('cpc'),
            fill_rate=Avg('fill_rate')
        ).order_by('date')

        return Response(daily_stats)


class PlacementOptimizationViewSet(viewsets.ModelViewSet):
    """广告位优化建议视图集"""
    queryset = PlacementOptimization.objects.all()
    serializer_class = PlacementOptimizationSerializer
    permission_classes = [IsAuthenticated]
    pagination_class = MyPageNumberPagination

    def get_queryset(self):
        queryset = PlacementOptimization.objects.all()
        placement_id = self.request.query_params.get('placement')
        status = self.request.query_params.get('status')
        issue_type = self.request.query_params.get('issue_type')

        if placement_id:
            queryset = queryset.filter(placement_id=placement_id)
        if status:
            queryset = queryset.filter(status=status)
        if issue_type:
            queryset = queryset.filter(issue_type=issue_type)
        return queryset

    @action(detail=False, methods=['get'])
    def stats(self, request):
        """获取优化建议统计数据"""
        # 总数统计
        total_count = PlacementOptimization.objects.count()
        pending_count = PlacementOptimization.objects.filter(status='pending').count()

        # 问题类型分布统计
        issue_choices = dict(PlacementOptimization._meta.get_field('issue_type').choices)
        issue_stats = (
            PlacementOptimization.objects.values('issue_type')
            .annotate(count=Count('id'))
            .order_by('-count')
        )
        issue_stats = [{
            'issue_type_display': issue_choices[item['issue_type']],
            'issue_type': item['issue_type'],
            'count': item['count']
        } for item in issue_stats]

        # 状态分布统计
        status_choices = dict(PlacementOptimization.STATUS_CHOICES)
        status_stats = (
            PlacementOptimization.objects.values('status')
            .annotate(count=Count('id'))
            .order_by('-count')
        )
        status_stats = [{
            'status_display': status_choices[item['status']],
            'status': item['status'],
            'count': item['count']
        } for item in status_stats]

        return Response({
            'total': total_count,
            'pending': pending_count,
            'issue_types': issue_stats,
            'status': status_stats
        })

    @action(detail=True, methods=['post'])
    def update_status(self, request, pk=None):
        """更新优化建议状态"""
        suggestion = self.get_object()
        status = request.data.get('status')

        if not status:
            return Response({'detail': '状态参数不能为空'}, status=400)

        if status not in dict(PlacementOptimization.STATUS_CHOICES):
            return Response({'detail': '无效的状态值'}, status=400)

        suggestion.status = status
        suggestion.save()

        serializer = self.get_serializer(suggestion)
        return Response(serializer.data)

    @action(detail=False, methods=['get'])
    def auto_generate(self, request):
        """自动生成优化建议"""
        placement_id = request.query_params.get('placement_id')

        if not placement_id:
            return Response({'detail': '必须指定广告位ID'}, status=400)

        try:
            placement = AdPlacement.objects.get(id=placement_id)
        except AdPlacement.DoesNotExist:
            return Response({'detail': '广告位不存在'}, status=404)

        # 调用广告位的生成优化建议方法
        suggestions_count = placement.generate_optimization_suggestions()

        return Response({
            'detail': f'已为 {placement.name} 生成 {suggestions_count} 条优化建议',
            'count': suggestions_count
        })

    @action(detail=False, methods=['get'])
    def recent(self, request):
        """获取最近的优化建议"""
        days = int(request.query_params.get('days', 7))  # 默认最近7天
        limit = int(request.query_params.get('limit', 5))  # 默认5条

        # 获取最近创建的建议
        recent_date = timezone.now() - timedelta(days=days)
        queryset = PlacementOptimization.objects.filter(
            created_at__gte=recent_date
        ).order_by('-created_at')[:limit]

        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)
