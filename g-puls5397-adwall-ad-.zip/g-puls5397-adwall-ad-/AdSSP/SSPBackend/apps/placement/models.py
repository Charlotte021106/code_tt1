from django.db import models
from django.conf import settings
from django.db.models import Avg
from django.utils import timezone
from datetime import timedelta


class PlacementType(models.Model):
    """广告位类型"""
    name = models.CharField(max_length=50, unique=True, verbose_name='类型名称')
    code = models.CharField(max_length=50, unique=True, verbose_name='类型代码')
    description = models.TextField(blank=True, null=True, verbose_name='类型描述')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    updated_at = models.DateTimeField(auto_now=True, verbose_name='更新时间')

    class Meta:
        verbose_name = '广告位类型'
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.name


class PlacementConfig(models.Model):
    """广告位配置"""
    FORMAT_CHOICES = (
        ('image', '图片'),
        ('video', '视频'),
    )
    format = models.CharField(max_length=20, choices=FORMAT_CHOICES, verbose_name='广告格式')
    width = models.IntegerField(verbose_name='宽度')
    height = models.IntegerField(verbose_name='高度')
    min_duration = models.IntegerField(default=0, verbose_name='最小展示时长(秒)')
    max_duration = models.IntegerField(default=0, verbose_name='最大展示时长(秒)')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    updated_at = models.DateTimeField(auto_now=True, verbose_name='更新时间')

    class Meta:
        verbose_name = '广告位配置'
        verbose_name_plural = verbose_name
        ordering = ['id']

    def __str__(self):
        return f"{self.get_format_display()}"  # 移除 size 显示


class AdPlacement(models.Model):
    """广告位"""
    STATUS_CHOICES = (
        ('draft', '草稿'),
        ('active', '激活'),
        ('disabled', '停用'),
    )
    name = models.CharField(max_length=100, verbose_name='广告位名称')
    placement_id = models.CharField(max_length=50, unique=True, verbose_name='广告位ID')
    type = models.ForeignKey(PlacementType, on_delete=models.PROTECT, verbose_name='广告位类型')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='draft', verbose_name='状态')
    config = models.ForeignKey(PlacementConfig, on_delete=models.PROTECT, verbose_name='广告位配置')
    description = models.TextField(blank=True, null=True, verbose_name='广告位描述')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    updated_at = models.DateTimeField(auto_now=True, verbose_name='更新时间')
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True,
                                   verbose_name='创建者')

    class Meta:
        verbose_name = '广告位'
        verbose_name_plural = verbose_name
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.name} ({self.placement_id})"

    def generate_optimization_suggestions(self):
        """生成优化建议
        
        根据广告位性能数据分析并生成优化建议
        
        Returns:
            int: 生成的建议数量
        """
        # 获取过去30天的性能数据
        end_date = timezone.now().date()
        start_date = end_date - timedelta(days=30)
        
        performances = self.performances.filter(date__gte=start_date, date__lte=end_date)
        
        if not performances.exists():
            return 0  # 没有性能数据则不生成建议
            
        # 计算性能指标平均值
        performance_metrics = performances.aggregate(
            avg_ctr=Avg('ctr'),
            avg_viewability=Avg('viewability'),
            avg_bounce_rate=Avg('bounce_rate'),
            avg_fill_rate=Avg('fill_rate')
        )
        
        # 定义阈值
        ctr_threshold = 0.5  # 点击率低阈值（百分比）
        viewability_threshold = 50  # 可见率低阈值（百分比）
        bounce_rate_threshold = 70  # 跳出率高阈值（百分比）
        fill_rate_threshold = 70  # 填充率低阈值（百分比）
        
        suggestions_count = 0
        
        # 检查点击率
        if performance_metrics['avg_ctr'] and performance_metrics['avg_ctr'] < ctr_threshold:
            # 创建低点击率优化建议
            self.optimizations.create(
                issue_type='low_ctr',
                description=f'点击率过低，当前平均值为 {performance_metrics["avg_ctr"]:.2f}%，低于标准值 {ctr_threshold}%',
                suggestion='建议优化创意内容，增加广告吸引力，或调整广告位置以提高用户注意力',
                status='pending'
            )
            suggestions_count += 1
            
        # 检查可见率
        if performance_metrics['avg_viewability'] and performance_metrics['avg_viewability'] < viewability_threshold:
            # 创建低可见率优化建议
            self.optimizations.create(
                issue_type='low_viewability',
                description=f'可见率过低，当前平均值为 {performance_metrics["avg_viewability"]:.2f}%，低于标准值 {viewability_threshold}%',
                suggestion='建议调整广告位位置，确保广告在用户首屏或易于看到的区域；优化页面加载速度',
                status='pending'
            )
            suggestions_count += 1
            
        # 检查跳出率
        if performance_metrics['avg_bounce_rate'] and performance_metrics['avg_bounce_rate'] > bounce_rate_threshold:
            # 创建高跳出率优化建议
            self.optimizations.create(
                issue_type='high_bounce',
                description=f'跳出率过高，当前平均值为 {performance_metrics["avg_bounce_rate"]:.2f}%，高于标准值 {bounce_rate_threshold}%',
                suggestion='建议提高落地页质量，确保广告与落地页内容相关性，优化用户体验减少跳出',
                status='pending'
            )
            suggestions_count += 1
            
        # 检查填充率
        if performance_metrics['avg_fill_rate'] and performance_metrics['avg_fill_rate'] < fill_rate_threshold:
            # 创建填充率优化建议
            self.optimizations.create(
                issue_type='revenue_optimization',
                description=f'填充率过低，当前平均值为 {performance_metrics["avg_fill_rate"]:.2f}%，低于标准值 {fill_rate_threshold}%',
                suggestion='建议增加需求方接入，检查预算设置和定向策略，确保广告请求能够得到响应',
                status='pending'
            )
            suggestions_count += 1
            
        return suggestions_count


class PlacementConnection(models.Model):
    """广告位和媒体/频道/站点关联"""
    placement = models.OneToOneField('AdPlacement', on_delete=models.CASCADE, related_name='connection',
                                     verbose_name='广告位', unique=True)
    media = models.ForeignKey('media.Media', on_delete=models.CASCADE, verbose_name='媒体',
                              null=True, default=None)
    channel = models.ForeignKey('media.Channel', on_delete=models.CASCADE, blank=True, null=True, verbose_name='频道')
    site = models.ForeignKey('media.Site', on_delete=models.CASCADE, blank=True, null=True, verbose_name='站点')
    page_url = models.CharField(max_length=255, blank=True, null=True, verbose_name='页面URL')
    position = models.CharField(max_length=100, blank=True, null=True, verbose_name='页面位置描述')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')

    class Meta:
        verbose_name = '广告位关联'
        verbose_name_plural = verbose_name
        ordering = ['-created_at']

    def clean(self):
        """验证channel和site必须关联到同一个media"""
        from django.core.exceptions import ValidationError

        if self.channel and self.media and self.channel.media != self.media:
            raise ValidationError({'channel': '频道必须属于选择的媒体'})

        if self.site and self.media and self.site.media != self.media:
            raise ValidationError({'site': '站点必须属于选择的媒体'})

        if not self.media and self.channel:
            self.media = self.channel.media
        elif not self.media and self.site:
            self.media = self.site.media

    def save(self, *args, **kwargs):
        self.clean()
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.placement.name} - {self.media.name}" + (f" - {self.channel.name}" if self.channel else "") + (
            f" - {self.site.name}" if self.site else "")


class PlacementTargeting(models.Model):
    """广告位定向设置"""
    placement = models.OneToOneField(AdPlacement, on_delete=models.CASCADE, related_name='targeting')
    # 基础定向
    device_types = models.JSONField(default=list, verbose_name='设备类型', help_text='["mobile", "tablet", "pc"]')
    os_types = models.JSONField(default=list, verbose_name='操作系统', help_text='["ios", "android", "windows"]')
    # 地域定向
    regions = models.JSONField(default=list, verbose_name='地域', help_text='["北京", "上海"]')
    # 时段定向
    time_ranges = models.JSONField(default=list, verbose_name='时段', help_text='[{"start": "09:00", "end": "18:00"}]')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = '广告位定向'
        verbose_name_plural = verbose_name


class PlacementPerformance(models.Model):
    """广告位性能数据"""
    placement = models.ForeignKey(AdPlacement, on_delete=models.CASCADE, related_name='performances')
    date = models.DateField(verbose_name='统计日期')
    # 基础指标
    impressions = models.IntegerField(default=0, verbose_name='展示量')
    clicks = models.IntegerField(default=0, verbose_name='点击量')
    revenue = models.DecimalField(max_digits=10, decimal_places=2, default=0, verbose_name='收入')
    # 质量指标
    ctr = models.FloatField(default=0, verbose_name='点击率')
    viewability = models.FloatField(default=0, verbose_name='可见率')
    bounce_rate = models.FloatField(default=0, verbose_name='跳出率')
    avg_view_time = models.FloatField(default=0, verbose_name='平均观看时长(秒)')
    # 收益指标
    cpm = models.DecimalField(max_digits=10, decimal_places=2, default=0, verbose_name='CPM')
    cpc = models.DecimalField(max_digits=10, decimal_places=2, default=0, verbose_name='CPC')
    fill_rate = models.FloatField(default=0, verbose_name='填充率')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = '广告位性能'
        verbose_name_plural = verbose_name
        unique_together = ('placement', 'date')
        indexes = [
            models.Index(fields=['date']),
            models.Index(fields=['placement', 'date']),
        ]

    def save(self, *args, **kwargs):
        # 自动计算CTR
        if self.impressions > 0:
            self.ctr = (self.clicks / self.impressions) * 100
        
        # 自动计算CPM
        if self.impressions > 0:
            self.cpm = (self.revenue / self.impressions) * 1000
        
        # 自动计算CPC
        if self.clicks > 0:
            self.cpc = self.revenue / self.clicks
            
        super().save(*args, **kwargs)


class PlacementOptimization(models.Model):
    """广告位优化建议"""
    STATUS_CHOICES = (
        ('pending', '待处理'),
        ('processing', '处理中'),
        ('completed', '已完成'),
        ('ignored', '已忽略')
    )

    placement = models.ForeignKey(AdPlacement, on_delete=models.CASCADE, related_name='optimizations')
    issue_type = models.CharField(max_length=50, verbose_name='问题类型',
                                  choices=[
                                      ('low_ctr', '点击率低'),
                                      ('low_viewability', '可见率低'),
                                      ('high_bounce', '跳出率高'),
                                      ('revenue_optimization', '收益优化')
                                  ])
    description = models.TextField(verbose_name='问题描述')
    suggestion = models.TextField(verbose_name='优化建议')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending', verbose_name='状态')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = '广告位优化'
        verbose_name_plural = verbose_name
        ordering = ['-created_at']
