from django.utils import timezone
from rest_framework import serializers
from rest_framework.exceptions import ValidationError

from media.serializers import MediaSerializer, SiteSerializer, ChannelSerializer
from .models import (
    AdPlacement, PlacementType, PlacementConfig, PlacementConnection, PlacementPerformance, PlacementOptimization,
    PlacementTargeting
)
from media.models import Media, Channel, Site


class PlacementTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = PlacementType
        fields = ['id', 'name', 'code', 'description', 'created_at', 'updated_at']
        extra_kwargs = {
            'id': {'read_only': True},
            'created_at': {'read_only': True},
            'updated_at': {'read_only': True},
            'name': {'required': True},
            'code': {'required': True}
        }

    def validate(self, attrs):
        # 获取实例（如果是更新操作）
        instance = getattr(self, 'instance', None)

        # 验证 name 和 code 是否已存在
        name = attrs.get('name')
        code = attrs.get('code')

        # 检查名称是否已存在（排除当前实例）
        if name:
            qs = PlacementType.objects.filter(name=name)
            if instance:
                qs = qs.exclude(pk=instance.pk)
            if qs.exists():
                raise serializers.ValidationError({'name': '该类型名称已存在'})

        # 检查代码是否已存在（排除当前实例）
        if code:
            qs = PlacementType.objects.filter(code=code)
            if instance:
                qs = qs.exclude(pk=instance.pk)
            if qs.exists():
                raise serializers.ValidationError({'code': '该类型代码已存在'})

        return attrs


class PlacementConfigSerializer(serializers.ModelSerializer):
    class Meta:
        model = PlacementConfig
        fields = '__all__'


class PlacementConnectionSerializer(serializers.ModelSerializer):
    """广告位关联序列化器"""
    media = MediaSerializer(read_only=True)
    channel = ChannelSerializer(read_only=True)
    site = SiteSerializer(read_only=True)

    class Meta:
        model = PlacementConnection
        fields = [
            'id', 'placement', 'media', 'channel', 'site',
            'page_url', 'position', 'created_at'
        ]
        read_only_fields = ['created_at']


class AdPlacementSerializer(serializers.ModelSerializer):
    config = PlacementConfigSerializer(write_only=True)
    type = PlacementTypeSerializer(read_only=True)
    config_details = PlacementConfigSerializer(source='config', read_only=True)
    connection = PlacementConnectionSerializer(read_only=True)

    media_id = serializers.PrimaryKeyRelatedField(
        queryset=Media.objects.all(),
        write_only=True,
        source='connection.media',
        required=False,
        allow_null=True
    )
    channel_id = serializers.PrimaryKeyRelatedField(
        queryset=Channel.objects.all(),
        write_only=True,
        source='connection.channel',
        required=False,
        allow_null=True
    )
    site_id = serializers.PrimaryKeyRelatedField(
        queryset=Site.objects.all(),
        write_only=True,
        source='connection.site',
        required=False,
        allow_null=True
    )
    type_id = serializers.PrimaryKeyRelatedField(
        queryset=PlacementType.objects.all(),
        write_only=True,
        source='type'
    )
    page_url = serializers.CharField(
        write_only=True,
        required=False,
        allow_blank=True,
        source='connection.page_url'
    )
    position = serializers.CharField(
        write_only=True,
        required=False,
        allow_blank=True,
        source='connection.position'
    )

    class Meta:
        model = AdPlacement
        fields = '__all__'
        read_only_fields = ('placement_id', 'created_at', 'updated_at', 'status', 'created_by')

    def create(self, validated_data):
        # 生成placement_id
        timestamp = timezone.now().strftime('%Y%m%d%H%M%S')
        count = AdPlacement.objects.count() + 1
        placement_id = f"PL{timestamp}{count:04d}"

        # 处理广告位配置
        config_data = validated_data.pop('config')
        config_serializer = PlacementConfigSerializer(data=config_data)
        config_serializer.is_valid(raise_exception=True)
        config = config_serializer.save()

        # 获取广告位类型实例
        type_instance = validated_data.pop('type')

        # 提取关联数据
        connection_data = validated_data.pop('connection', {})

        # 创建广告位实例
        ad_placement = AdPlacement.objects.create(
            placement_id=placement_id,
            config=config,
            type=type_instance,
            status='draft',
            created_by=self.context['request'].user,
            **validated_data
        )

        # 处理广告位关联
        if connection_data:
            connection = PlacementConnection(
                placement=ad_placement,
                **connection_data
            )
            try:
                connection.full_clean()
                connection.save()
            except ValidationError as e:
                raise serializers.ValidationError(e.message_dict)

        return ad_placement

    def validate(self, attrs):
        # 验证配置数据
        config_data = attrs.get('config', {})
        if config_data:
            min_dur = config_data.get('min_duration', 0)
            max_dur = config_data.get('max_duration', 0)
            if min_dur > max_dur:
                raise ValidationError({"config": "最小展示时长不能大于最大展示时长"})

        # 验证关联关系 - 检查原始传入的ID字段
        media_id = self.initial_data.get('media_id')
        channel_id = self.initial_data.get('channel_id')
        site_id = self.initial_data.get('site_id')

        if not any([media_id, channel_id, site_id]):
            raise ValidationError("必须提供至少一个媒体、频道或站点的ID")

        return attrs

    def update(self, instance, validated_data):
        # 更新配置 - 这部分没问题
        config_data = validated_data.pop('config', None)
        if config_data:
            config_serializer = PlacementConfigSerializer(
                instance.config,
                data=config_data,
                partial=True
            )
            config_serializer.is_valid(raise_exception=True)
            config_serializer.save()

        connection_data = validated_data.pop('connection', None)
        if connection_data:
            try:
                connection = PlacementConnection.objects.get(placement=instance)
                for field, value in connection_data.items():
                    if value is not None:
                        setattr(connection, field, value)
                connection.save()
            except PlacementConnection.DoesNotExist:
                # 如果不存在关联，则创建新的
                connection_data['placement'] = instance
                PlacementConnection.objects.create(**connection_data)

        # 更新广告位
        return super().update(instance, validated_data)


class PlacementDetailSerializer(serializers.ModelSerializer):
    """广告位详情序列化器，包含关联信息"""
    type = PlacementTypeSerializer(read_only=True)
    config = PlacementConfigSerializer(read_only=True)
    connection = PlacementConnectionSerializer(read_only=True)

    class Meta:
        model = AdPlacement
        fields = '__all__'
        read_only_fields = ('placement_id', 'created_at', 'updated_at')

class PlacementTargetingSerializer(serializers.ModelSerializer):
    class Meta:
        model = PlacementTargeting
        fields = ['id', 'placement', 'device_types', 'os_types', 'regions', 'time_ranges', 'created_at', 'updated_at']
        read_only_fields = ['created_at', 'updated_at']

    def validate_device_types(self, value):
        valid_devices = ['mobile', 'tablet', 'pc']
        if not all(device in valid_devices for device in value):
            raise serializers.ValidationError(f"设备类型必须是以下之一: {', '.join(valid_devices)}")
        return value

    def validate_os_types(self, value):
        valid_os = ['ios', 'android', 'windows']
        if not all(os in valid_os for os in value):
            raise serializers.ValidationError(f"操作系统类型必须是以下之一: {', '.join(valid_os)}")
        return value


class PlacementPerformanceSerializer(serializers.ModelSerializer):
    class Meta:
        model = PlacementPerformance
        fields = [
            'id', 'placement', 'date', 
            'impressions', 'clicks', 'revenue',
            'ctr', 'viewability', 'bounce_rate', 'avg_view_time',
            'cpm', 'cpc', 'fill_rate',
            'created_at'
        ]
        read_only_fields = ['created_at', 'ctr', 'cpm', 'cpc']


class PlacementOptimizationSerializer(serializers.ModelSerializer):
    placement_name = serializers.SerializerMethodField()
    placement_id_code = serializers.SerializerMethodField()
    status_display = serializers.SerializerMethodField()
    issue_type_display = serializers.SerializerMethodField()
    
    class Meta:
        model = PlacementOptimization
        fields = [
            'id', 'placement', 'placement_name', 'placement_id_code',
            'issue_type', 'issue_type_display', 'description', 'suggestion', 
            'status', 'status_display', 'created_at', 'updated_at'
        ]
        read_only_fields = ['created_at', 'updated_at', 'placement_name', 'placement_id_code', 
                           'status_display', 'issue_type_display']
    
    def get_placement_name(self, obj):
        return obj.placement.name if obj.placement else None
        
    def get_placement_id_code(self, obj):
        return obj.placement.placement_id if obj.placement else None
        
    def get_status_display(self, obj):
        return obj.get_status_display()
        
    def get_issue_type_display(self, obj):
        return obj.get_issue_type_display()

