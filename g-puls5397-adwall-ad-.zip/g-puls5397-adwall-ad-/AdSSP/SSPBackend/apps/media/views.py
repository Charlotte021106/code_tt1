from datetime import timedelta

from django.db.models import Count, Avg
from django.utils import timezone
from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.response import Response
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import SearchFilter, OrderingFilter


from utils.filters import MyPageNumberPagination
from .models import Media, Channel, Site
from .serializers import MediaSerializer, ChannelSerializer, SiteSerializer


class MediaViewSet(viewsets.ModelViewSet):
    """
    媒体管理视图集
    """
    queryset = Media.objects.all()
    serializer_class = MediaSerializer
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_fields = ['type', 'status', 'owner']
    search_fields = ['name', 'code']
    ordering_fields = ['created_at', 'updated_at']
    pagination_class = MyPageNumberPagination

    def get_queryset(self):
        queryset = Media.objects.all()
        name = self.request.query_params.get('name', None)
        code = self.request.query_params.get('code', None)
        type = self.request.query_params.get('type', None)
        status = self.request.query_params.get('status', None)
        owner = self.request.query_params.get('owner', None)

        if name:
            queryset = queryset.filter(name__icontains=name)
        if code:
            queryset = queryset.filter(code__icontains=code)
        if type:
            queryset = queryset.filter(type=type)
        if status:
            queryset = queryset.filter(status=status)
        if owner:
            queryset = queryset.filter(owner=owner)

        # 如果用户不是管理员，只能看到自己的媒体
        if not self.request.user.is_staff:
            queryset = queryset.filter(owner=self.request.user)

        return queryset

    def perform_create(self, serializer):
        """创建媒体时，自动设置owner为当前用户"""
        serializer.save(owner=self.request.user)

    @action(detail=True, methods=['post'])
    def toggle_status(self, request, pk=None):
        """切换媒体状态"""
        media = self.get_object()
        if media.status == 'active':
            media.status = 'inactive'
        elif media.status == 'inactive':
            media.status = 'active'
        media.save()
        return Response({'status': media.status})

    @action(detail=False, methods=['get'])
    def stats(self, request):
        """获取媒体统计数据"""
        queryset = self.get_queryset()  # 使用get_queryset确保权限过滤

        # 基础统计
        stats = {
            'total': queryset.count(),
            'by_status': dict(queryset.values_list('status').annotate(count=Count('id'))),
            'by_type': dict(queryset.values_list('type').annotate(count=Count('id')))
        }

        # 频道相关统计
        stats['channels'] = {
            'total': Channel.objects.filter(media__in=queryset).count(),
            'by_content_type': dict(Channel.objects.filter(media__in=queryset)
                                    .values_list('content_type')
                                    .annotate(count=Count('id'))),
            'avg_per_media': queryset.annotate(channel_count=Count('channels'))
                             .aggregate(avg=Avg('channel_count'))['avg'] or 0
        }

        # 站点相关统计
        stats['sites'] = {
            'total': Site.objects.filter(media__in=queryset).count(),
            'with_domain': Site.objects.filter(media__in=queryset)
            .exclude(domain__isnull=True)
            .exclude(domain='').count(),
            'avg_per_media': queryset.annotate(site_count=Count('sites'))
                             .aggregate(avg=Avg('site_count'))['avg'] or 0
        }

        # 媒体活跃度统计（按更新时间）
        last_week = timezone.now() - timedelta(days=7)
        stats['activity'] = {
            'updated_last_week': queryset.filter(updated_at__gte=last_week).count(),
            'new_last_week': queryset.filter(created_at__gte=last_week).count()
        }

        return Response(stats)

    @action(detail=True, methods=['get'])
    def channel_stats(self, request, pk=None):
        """获取单个媒体的频道统计"""
        media = self.get_object()
        channels = media.channels.all()

        return Response({
            'total': channels.count(),
            'by_content_type': dict(channels.values_list('content_type')
                                    .annotate(count=Count('id')))
        })

    @action(detail=True, methods=['get'])
    def site_stats(self, request, pk=None):
        """获取单个媒体的站点统计"""
        media = self.get_object()
        sites = media.sites.all()

        return Response({
            'total': sites.count(),
            'with_domain': sites.exclude(domain__isnull=True).exclude(domain='').count(),
            'positions': list(sites.values('name', 'position').order_by('position'))
        })

    @action(detail=False, methods=['get'])
    def options(self, request):
        """获取媒体选项（用于下拉列表）"""
        queryset = self.get_queryset().only('id', 'name')
        return Response([{'value': m.id, 'label': m.name} for m in queryset])


class ChannelViewSet(viewsets.ModelViewSet):
    """
    频道管理视图集
    """
    queryset = Channel.objects.all()
    serializer_class = ChannelSerializer
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_fields = ['media', 'content_type']
    search_fields = ['name', 'code']
    ordering_fields = ['created_at', 'updated_at']
    pagination_class = MyPageNumberPagination

    def get_queryset(self):
        queryset = Channel.objects.all()
        media = self.request.query_params.get('media', None)
        name = self.request.query_params.get('name', None)
        code = self.request.query_params.get('code', None)
        content_type = self.request.query_params.get('content_type', None)

        if media:
            queryset = queryset.filter(media=media)
        if name:
            queryset = queryset.filter(name__icontains=name)
        if code:
            queryset = queryset.filter(code__icontains=code)
        if content_type:
            queryset = queryset.filter(content_type=content_type)

        # 如果用户不是管理员，只能看到自己媒体下的频道
        if not self.request.user.is_staff:
            queryset = queryset.filter(media__owner=self.request.user)

        return queryset

    @action(detail=False, methods=['get'])
    def options(self, request):
        """获取频道选项（用于下拉列表）"""
        media_id = request.query_params.get('media_id')
        queryset = self.get_queryset()
        if media_id:
            queryset = queryset.filter(media_id=media_id)
        queryset = queryset.only('id', 'name', 'media_id')
        return Response([{'value': c.id, 'label': f"{c.media.name} - {c.name}"} for c in queryset])


class SiteViewSet(viewsets.ModelViewSet):
    """
    站点管理视图集
    """
    queryset = Site.objects.all()
    serializer_class = SiteSerializer
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_fields = ['media']
    search_fields = ['name', 'code', 'domain']
    ordering_fields = ['position', 'created_at', 'updated_at']
    pagination_class = MyPageNumberPagination

    def get_queryset(self):
        queryset = Site.objects.all()
        media = self.request.query_params.get('media', None)
        name = self.request.query_params.get('name', None)
        code = self.request.query_params.get('code', None)
        domain = self.request.query_params.get('domain', None)

        if media:
            queryset = queryset.filter(media=media)
        if name:
            queryset = queryset.filter(name__icontains=name)
        if code:
            queryset = queryset.filter(code__icontains=code)
        if domain:
            queryset = queryset.filter(domain__icontains=domain)

        # 如果用户不是管理员，只能看到自己媒体下的站点
        if not self.request.user.is_staff:
            queryset = queryset.filter(media__owner=self.request.user)

        return queryset

    @action(detail=False, methods=['get'])
    def options(self, request):
        """获取站点选项（用于下拉列表）"""
        media_id = request.query_params.get('media_id')
        queryset = self.get_queryset()
        if media_id:
            queryset = queryset.filter(media_id=media_id)
        queryset = queryset.only('id', 'name', 'media_id')
        return Response([{'value': s.id, 'label': f"{s.media.name} - {s.name}"} for s in queryset])
