from django.contrib import admin
from .models import Media, Channel, Site


@admin.register(Media)
class MediaAdmin(admin.ModelAdmin):
    list_display = ('name', 'code', 'type', 'status', 'owner', 'created_at')
    list_filter = ('type', 'status')
    search_fields = ('name', 'code')
    raw_id_fields = ('owner',)
    date_hierarchy = 'created_at'


@admin.register(Channel)
class ChannelAdmin(admin.ModelAdmin):
    list_display = ('name', 'code', 'media', 'content_type', 'created_at')
    list_filter = ('content_type',)
    search_fields = ('name', 'code')
    raw_id_fields = ('media',)
    date_hierarchy = 'created_at'


@admin.register(Site)
class SiteAdmin(admin.ModelAdmin):
    list_display = ('name', 'code', 'media', 'domain', 'position', 'created_at')
    search_fields = ('name', 'code', 'domain')
    raw_id_fields = ('media',)
    date_hierarchy = 'created_at'
