from rest_framework import serializers
from django.contrib.auth.models import User
from .models import Media, Channel, Site
import re
import uuid


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'first_name', 'last_name']


class MediaSerializer(serializers.ModelSerializer):
    """
    媒体序列化器
    """
    owner_name = serializers.CharField(source='owner.username', read_only=True)
    type_display = serializers.CharField(source='get_type_display', read_only=True)
    status_display = serializers.CharField(source='get_status_display', read_only=True)

    class Meta:
        model = Media
        fields = [
            'id', 'name', 'code', 'type', 'type_display',
            'status', 'status_display', 'owner_name',
            'description', 'created_at', 'updated_at'
        ]
        read_only_fields = ['created_at', 'updated_at']

    def validate_code(self, value):
        """
        验证媒体代码是否唯一
        """
        if self.instance and self.instance.code == value:
            return value
        if Media.objects.filter(code=value).exists():
            raise serializers.ValidationError("媒体代码已存在")
        return value


class ChannelSerializer(serializers.ModelSerializer):
    """
    频道序列化器
    """
    media_name = serializers.CharField(source='media.name', read_only=True)
    content_type_display = serializers.CharField(source='get_content_type_display', read_only=True)

    class Meta:
        model = Channel
        fields = [
            'id', 'media', 'media_name', 'name', 'code',
            'content_type', 'content_type_display',
            'description', 'created_at', 'updated_at'
        ]
        read_only_fields = ['created_at', 'updated_at']

    def validate(self, data):
        """
        验证频道代码在同一媒体下是否唯一
        """
        media = data.get('media')
        code = data.get('code')

        if self.instance and self.instance.code == code and self.instance.media == media:
            return data

        if Channel.objects.filter(media=media, code=code).exists():
            raise serializers.ValidationError({
                'code': '该媒体下已存在相同代码的频道'
            })
        return data


class SiteSerializer(serializers.ModelSerializer):
    """
    站点序列化器（支持code为空时自动生成）
    """
    media_name = serializers.CharField(source='media.name', read_only=True)
    code = serializers.CharField(required=False, allow_blank=True)

    class Meta:
        model = Site
        fields = [
            'id', 'media', 'media_name', 'name', 'code',
            'domain', 'position', 'description',
            'created_at', 'updated_at'
        ]
        read_only_fields = ['created_at', 'updated_at']

    def validate_code(self, value):
        """ 验证代码格式（若提供） """
        if value and not re.match(r'^[a-zA-Z0-9_-]+$', value):
            raise serializers.ValidationError('代码只能包含字母、数字、下划线和连字符')
        return value

    def validate(self, data):
        """
        处理code为空的情况并验证唯一性
        """
        media = data.get('media')
        code = data.get('code', '').strip()  # 获取可能为空的code

        # 自动生成逻辑：当code为空时
        if not code:
            base_name = data['name'].lower()
            # 生成规则：名称小写 + 随机后缀（确保唯一性）
            base_code = re.sub(r'[^a-z0-9]', '-', base_name)  # 非字母数字替换为-
            base_code = re.sub(r'-+', '-', base_code).strip('-')  # 去重-
            data['code'] = f"{base_code}-{uuid.uuid4().hex[:4]}"  # 示例: "my-site-1a2b"

        # 唯一性验证（针对自动生成或手动输入的code）
        if Site.objects.filter(media=media, code=data['code']).exclude(
                id=self.instance.id if self.instance else None).exists():
            raise serializers.ValidationError({'code': '该媒体下已存在相同代码的站点'})

        return data
