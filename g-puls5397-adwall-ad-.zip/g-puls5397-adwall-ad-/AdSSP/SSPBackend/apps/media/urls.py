from rest_framework.routers import DefaultRouter
from .views import (
    MediaViewSet,
    ChannelViewSet,
    SiteViewSet
)
urlpatterns = [
]
router = DefaultRouter()
router.register(r'channels', ChannelViewSet, basename='channel')
router.register(r'sites', SiteViewSet, basename='site')
router.register('', MediaViewSet, basename='media')
urlpatterns += router.urls
