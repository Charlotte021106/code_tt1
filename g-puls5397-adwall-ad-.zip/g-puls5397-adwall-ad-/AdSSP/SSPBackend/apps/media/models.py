from django.db import models
from django.contrib.auth.models import User
import uuid


class Media(models.Model):
    """
    媒体平台
    """
    TYPE_CHOICES = (
        ('comprehensive', '综合'),
        ('vertical', '垂直'),
        ('news', '新闻'),
        ('technology', '科技'),
        ('entertainment', '娱乐'),
        ('lifestyle', '生活'),
        ('education', '教育'),
        ('sports', '体育'),
        ('other', '其他'),
    )
    STATUS_CHOICES = (
        ('active', '启用'),
        ('inactive', '停用'),
        ('pending', '待审核'),
    )
    
    name = models.CharField('名称', max_length=100)
    code = models.CharField('代码', max_length=50, unique=True)
    type = models.CharField('类型', max_length=20, choices=TYPE_CHOICES, default='comprehensive')
    status = models.CharField('状态', max_length=20, choices=STATUS_CHOICES, default='pending')
    owner = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name='所有者', related_name='owned_media')
    description = models.TextField('描述', blank=True, null=True)
    created_at = models.DateTimeField('创建时间', auto_now_add=True)
    updated_at = models.DateTimeField('更新时间', auto_now=True)

    class Meta:
        verbose_name = '媒体'
        verbose_name_plural = '媒体'
        ordering = ['-created_at']

    def __str__(self):
        return self.name


class Channel(models.Model):
    """
    媒体频道/栏目
    """
    CONTENT_TYPE_CHOICES = (
        ('news', '新闻'),
        ('article', '文章'),
        ('video', '视频'),
        ('live', '直播'),
        ('picture', '图片'),
        ('audio', '音频'),
        ('other', '其他'),
    )
    
    media = models.ForeignKey(Media, on_delete=models.CASCADE, verbose_name='所属媒体', related_name='channels')
    name = models.CharField('名称', max_length=100)
    code = models.CharField('代码', max_length=50)
    content_type = models.CharField('内容类型', max_length=20, choices=CONTENT_TYPE_CHOICES, default='article')
    description = models.TextField('描述', blank=True, null=True)
    created_at = models.DateTimeField('创建时间', auto_now_add=True)
    updated_at = models.DateTimeField('更新时间', auto_now=True)

    class Meta:
        verbose_name = '频道/栏目'
        verbose_name_plural = '频道/栏目'
        ordering = ['media', 'code']
        unique_together = ['media', 'code']

    def __str__(self):
        return f"{self.media.name} - {self.name}"


class Site(models.Model):
    """
    媒体站点/页面
    """
    media = models.ForeignKey(Media, on_delete=models.CASCADE, verbose_name='所属媒体', related_name='sites')
    name = models.CharField('名称', max_length=100)
    code = models.CharField('代码', max_length=50, default='site-default')
    domain = models.CharField('域名', max_length=100, blank=True, null=True)
    position = models.IntegerField('排序位置', default=0)
    description = models.TextField('描述', blank=True, null=True)
    created_at = models.DateTimeField('创建时间', auto_now_add=True)
    updated_at = models.DateTimeField('更新时间', auto_now=True)

    class Meta:
        verbose_name = '站点/页面'
        verbose_name_plural = '站点/页面'
        ordering = ['media', 'position']
        unique_together = ['media', 'code']

    def __str__(self):
        return f"{self.media.name} - {self.name}"

    def save(self, *args, **kwargs):
        # 如果代码为空，则使用名称的小写形式和一个随机后缀作为默认代码
        if not self.code:
            self.code = f"{self.name.lower().replace(' ', '-')}-{str(uuid.uuid4())[:8]}"
        super().save(*args, **kwargs)
