##  1. 相关技术

### 1.1 后端(Python DRF)

环境：win11本地虚拟环境


| 名称 | Python | Django | djangorestframework | rest_framework_simplejwt | pymysql | coreapi | Faker  | py3Fdfs | django-redis |
| - |  |  | - |  | - | - |  | - |  |
| 版本 | 3.11.6 | 5.1.6  | 3.15.2              | 5.4.0                    | 1.1.1   | 2.3.3   | 35.0.0 | 2.2.0   | 5.4.0        |

### 1.2 celery

> 参考：[牛哄哄的celery - Mr·Yuan - 博客园 (cnblogs.com)](https://www.cnblogs.com/pyedu/p/12461819.html)

启动celery命令

```sh
celery -A celery_tasks.celery_main worker --loglevel=info
```

windows下还需安装：eventlet

```shell
pip install eventlet
```

```shell
celery -A celery_tasks.celery_main worker -l info -P eventlet
```

### 1.2 前端(Vue3)

#### 1.2.1 核心框架

| 名称 | Vue    | Element Plus | Pinia | Vue Router | Axios |
| - |  |  | -- | - | -- |
| 版本 | 3.5.13 | 2.9.3        | 2.3.1 | 4.5.0      | 1.7.9 |

#### 1.2.2 辅助工具

| 名称                        | 功能说明           | 版本  |
| --------------------------- | ------------------ | ----- |
| nprogress                   | 页面加载进度条     | 0.2.0 |
| pinia-plugin-persistedstate | 状态持久化插件     | 4.2.0 |
| @element-plus/icons-vue     | Element Plus图标库 | 2.3.1 |

#### 1.2.3 构建工具链

| 名称 | Vite  | @vitejs/plugin-vue | Less  |
| - | -- |  | -- |
| 版本 | 6.0.5 | 5.2.1              | 4.2.2 |

### 1.3 数据库

仅mysql

超级管理员账号

| 账号 | jiuwen |
| - |  |
| 密码 | qwe123 |

## 2. **需求分析**

### **2.1 广告主（Advertiser）**

广告主是广告活动的发起者，主要关注广告活动的创建、管理和效果分析。

#### **2.1.1 广告活动管理**

- **创建广告活动**：
  - 操作：填写广告活动名称、预算、投放时间等。
  - 权限：只能创建自己名下的广告活动。
  - 界面：表单页面，包含必填字段和可选字段。
- **查看广告活动**：
  - 操作：查看自己创建的广告活动列表，包括活动名称、状态、预算、投放时间等。
  - 权限：只能查看自己名下的广告活动。
  - 界面：列表页面，支持搜索和筛选。
- **编辑广告活动**：
  - 操作：修改广告活动的名称、预算、目标受众、投放时间等。
  - 权限：只能编辑自己名下的广告活动。
  - 界面：表单页面，预填充当前活动信息。
- **暂停/启动广告活动**：
  - 操作：暂停或重新启动广告活动。
  - 权限：只能操作自己名下的广告活动。
  - 界面：列表页面，每个活动旁边有“暂停”或“启动”按钮。

#### **2.1.2 广告创意管理**

- **上传创意**：
  - 操作：上传图片、视频或文字素材，填写标题和描述。
  - 权限：只能上传到自己名下的广告活动中。
  - 界面：上传页面，支持文件选择和预览。
- **查看创意**：
  - 操作：查看自己上传的创意列表，包括标题、类型、审核状态等。
  - 权限：只能查看自己名下的创意。
  - 界面：列表页面，支持搜索和筛选。
- **编辑创意**：
  - 操作：修改创意的标题、描述或替换素材。
  - 权限：只能编辑自己名下的创意。
  - 界面：表单页面，预填充当前创意信息。
- **删除创意**：
  - 操作：删除未通过审核或不再使用的创意。
  - 权限：只能删除自己名下的创意。
  - 界面：列表页面，每个创意旁边有“删除”按钮。

#### **2.1.3 数据统计与分析**

- **查看广告效果**：
  - 操作：查看广告活动的展示量、点击量、转化率等数据。
  - 权限：只能查看自己名下的广告活动数据。
  - 界面：图表页面，支持按时间范围筛选。
- **生成报表**：
  - 操作：生成并下载广告活动的详细报表（如 Excel 或 PDF 格式）。
  - 权限：只能生成自己名下的广告活动报表。
  - 界面：报表页面，支持选择时间范围和报表格式。

#### **2.1.4 预算与计费**

- **设置预算**：
  - 操作：为广告活动设置总预算
  - 权限：只能设置自己名下的广告活动预算。
  - 界面：表单页面，包含预算输入字段。
- **查看消费记录**：
  - 操作：查看广告活动的消费记录，包括日期、金额、消费类型等。
  - 权限：只能查看自己名下的消费记录。
  - 界面：列表页面，支持搜索和筛选。
- **查看账单**：
  - 操作：查看和下载账单及发票。
  - 权限：只能查看自己名下的账单。
  - 界面：列表页面，支持下载按钮。

### **2.2 代理商（Agency）**

代理商是广告主的代表，负责管理多个广告主的广告活动。

#### **2.2.1 广告活动管理**

- **创建广告活动**：
  - 操作：为代理的广告主创建广告活动，填写活动名称、预算、目标受众、投放时间等。
  - 权限：只能为代理的广告主创建广告活动。
  - 界面：表单页面，包含广告主选择字段。
- **查看广告活动**：
  - 操作：查看其名下所有广告主的广告活动列表。
  - 权限：只能查看代理的广告主的活动。
  - 界面：列表页面，支持按广告主筛选。
- **编辑广告活动**：
  - 操作：修改代理的广告主的广告活动设置。
  - 权限：只能编辑代理的广告主的活动。
  - 界面：表单页面，预填充当前活动信息。
- **暂停/启动广告活动**：
  - 操作：暂停或重新启动代理的广告主的广告活动。
  - 权限：只能操作代理的广告主的活动。
  - 界面：列表页面，每个活动旁边有“暂停”或“启动”按钮。

#### **2.2.2 广告创意管理**

- **上传创意**：
  - 操作：为代理的广告主上传广告素材。
  - 权限：只能上传到代理的广告主的广告活动中。
  - 界面：上传页面，支持文件选择和预览。
- **查看创意**：
  - 操作：查看其名下广告主的创意列表。
  - 权限：只能查看代理的广告主的创意。
  - 界面：列表页面，支持按广告主筛选。
- **编辑创意**：
  - 操作：修改代理的广告主的创意。
  - 权限：只能编辑代理的广告主的创意。
  - 界面：表单页面，预填充当前创意信息。
- **删除创意**：
  - 操作：删除代理的广告主的创意。
  - 权限：只能删除代理的广告主的创意。
  - 界面：列表页面，每个创意旁边有“删除”按钮。

#### **2.2.3 数据统计与分析**

- **查看广告效果**：
  - 操作：查看其名下广告主的广告活动效果数据。
  - 权限：只能查看代理的广告主的数据。
  - 界面：图表页面，支持按广告主和时间范围筛选。
- **生成报表**：
  - 操作：生成并下载其名下广告主的广告活动报表。
  - 权限：只能生成代理的广告主的报表。
  - 界面：报表页面，支持选择广告主、时间范围和报表格式。

#### **2.2.4 预算与计费**

- **设置预算**：
  - 操作：为代理的广告主设置广告活动的预算。
  - 权限：只能设置代理的广告主的预算。
  - 界面：表单页面，包含广告主选择字段。
- **查看消费记录**：
  - 操作：查看其名下广告主的消费记录。
  - 权限：只能查看代理的广告主的消费记录。
  - 界面：列表页面，支持按广告主筛选。
- **查看账单**：
  - 操作：查看和下载其名下广告主的账单及发票。
  - 权限：只能查看代理的广告主的账单。
  - 界面：列表页面，支持按广告主筛选和下载按钮。

#### **2.2.5 多客户管理**

- **管理广告主账户**：
  - 操作：查看和编辑代理的广告主的账户信息。
  - 权限：只能管理代理的广告主的账户。
  - 界面：列表页面，支持搜索和编辑按钮。
- **分配权限**：
  - 操作：为每个广告主分配不同的权限（如只读、编辑等）。
  - 权限：只能为代理的广告主分配权限。
  - 界面：表单页面，包含权限选择字段。

### **2.3 管理员（Admin）**

管理员负责系统的整体管理和维护，拥有最高权限。

#### **2.3.1 用户管理**

- **创建用户**：
  - 操作：创建广告主、代理商和其他管理员账户。
  - 权限：无限制。
  - 界面：表单页面，包含用户类型选择字段。
- **查看用户列表**：
  - 操作：查看所有用户的列表。
  - 权限：无限制。
  - 界面：列表页面，支持搜索和筛选。
- **编辑用户信息**：
  - 操作：修改用户的账户信息。
  - 权限：无限制。
  - 界面：表单页面，预填充当前用户信息。
- **删除用户**：
  - 操作：删除用户账户。
  - 权限：无限制。
  - 界面：列表页面，每个用户旁边有“删除”按钮。

#### **2.3.2 广告活动管理**

- **查看所有广告活动**：
  - 操作：查看系统中所有广告活动的列表。
  - 权限：无限制。
  - 界面：列表页面，支持搜索和筛选。
- **编辑广告活动**：
  - 操作：修改任何广告活动的设置。
  - 权限：无限制。
  - 界面：表单页面，预填充当前活动信息。
- **暂停/启动广告活动**：
  - 操作：暂停或重新启动任何广告活动。
  - 权限：无限制。
  - 界面：列表页面，每个活动旁边有“暂停”或“启动”按钮。

#### **2.3.3 广告创意管理**

- **审核创意**：
  - 操作：审核广告主和代理商上传的创意。
  - 权限：无限制。
  - 界面：列表页面，每个创意旁边有“审核通过”或“拒绝”按钮。
- **查看所有创意**：
  - 操作：查看系统中所有创意的列表。
  - 权限：无限制。
  - 界面：列表页面，支持搜索和筛选。
- **编辑创意**：
  - 操作：修改任何创意。
  - 权限：无限制。
  - 界面：表单页面，预填充当前创意信息。
- **删除创意**：
  - 操作：删除任何创意。
  - 权限：无限制。
  - 界面：列表页面，每个创意旁边有“删除”按钮。

#### **2.3.4 数据统计与分析**

- **查看全局数据**：
  - 操作：查看系统中所有广告活动的效果数据。
  - 权限：无限制。
  - 界面：图表页面，支持按时间范围筛选。
- **生成全局报表**：
  - 操作：生成并下载系统中所有广告活动的报表。
  - 权限：无限制。
  - 界面：报表页面，支持选择时间范围和报表格式。

#### **2.3.5 预算与计费**

- **查看所有消费记录**：
  - 操作：查看系统中所有广告主的消费记录。
  - 权限：无限制。
  - 界面：列表页面，支持搜索和筛选。
- **查看所有账单**：
  - 操作：查看和下载系统中所有广告主的账单及发票。
  - 权限：无限制。
  - 界面：列表页面，支持下载按钮。

#### **2.3.6 系统管理**

- **日志管理**：
  - 操作：查看系统中所有操作的日志记录。
  - 权限：无限制。
  - 界面：列表页面，支持搜索和筛选。
- **系统监控**：
  - 操作：监控系统的运行状态（如 CPU、内存、磁盘使用率等）。
  - 权限：无限制。
  - 界面：仪表盘页面，显示实时系统状态。
- **数据备份与恢复**：
  - 操作：备份和恢复系统数据。
  - 权限：无限制。
  - 界面：备份页面，支持手动备份和恢复操作。

### **2.3 功能模块与用户角色对应表**

| **功能模块**      | **广告主** | **代理商** | **管理员** |
| -- | - | - | - |
| 创建广告活动      | ✔️          | ❌         | ✔️          |
| 查看所有广告活动    | ❌         | ✔️         | ✔️          |
| 编辑广告活动      | ✔️          | ❌         | ✔️          |
| 暂停/启动广告活动 | ✔️          | ✔️          | ✔️          |
| 上传创意          | ✔️          | ✔️          | ✔️          |
| 查看创意          | ✔️          | ✔️          | ✔️          |
| 编辑创意          | ✔️          | ✔️          | ✔️          |
| 删除创意          | ✔️          | ✔️          | ✔️          |
| 审核创意          | ❌          | ❌          | ✔️          |
| 查看广告效果      | ✔️          | ✔️          | ✔️          |
| 生成报表          | ✔️          | ✔️          | ✔️          |
| 设置预算          | ✔️          | ✔️          | ❌          |
| 查看消费记录      | ✔️          | ✔️          | ✔️          |
| 查看账单          | ✔️          | ✔️          | ✔️          |
| 管理广告主账户    | ❌          | ✔️          | ✔️          |
| 分配权限          | ❌          | ✔️          | ✔️          |
| 创建用户          | ❌          | ❌          | ✔️          |
| 查看用户列表      | ❌          | ❌          | ✔️          |
| 编辑用户信息      | ❌          | ❌          | ✔️          |
| 删除用户          | ❌          | ❌          | ✔️          |
| 查看全局数据      | ❌          | ❌          | ✔️          |
| 生成全局报表      | ❌          | ❌          | ✔️          |
| 日志管理          | ❌          | ❌          | ✔️          |
| 系统监控          | ❌          | ❌          | ✔️          |
| 数据备份与恢复    | ❌          | ❌          | ✔️          |

## **3. 数据库设计**

### **3.1 用户管理**

```python
# 用户管理
class User(AbstractUser):
    USER_TYPE_CHOICES = (
        ('ADVERTISER', 'Advertiser'),
        ('AGENT', 'Agent'),
        ('ADMIN', 'Admin'),
    )
    user_type = models.CharField(
        max_length=10,
        choices=USER_TYPE_CHOICES,
        help_text="用户类型：广告主（ADVERTISER）、代理商（AGENT）、管理员（ADMIN）"
    )
    company_name = models.CharField(
        max_length=255,
        blank=True,
        null=True,
        help_text="公司名称，仅广告主和代理商需要填写"
    )
    phone_number = models.CharField(
        max_length=15,
        blank=True,
        null=True,
        help_text="联系电话"
    )
    billing_address = models.TextField(
        blank=True,
        null=True,
        help_text="账单地址"
    )

    def __str__(self):
        return f"{self.username} ({self.user_type})"
```

```python
class AgentClientRelationship(models.Model):
    """代理-广告主关联表"""
    agent = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='managed_clients',
        limit_choices_to={'user_type': 'AGENT'}
    )
    client = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='my_agents',
        limit_choices_to={'user_type': 'ADVERTISER'}
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = [['agent', 'client']]

```

### **3.2 广告活动管理**

```python
# 广告活动管理
class Campaign(models.Model):
    STATUS_CHOICES = (
        ('ACTIVE', 'Active'),
        ('PAUSED', 'Paused'),
        ('COMPLETED', 'Completed'),
    )
    name = models.CharField(
        max_length=255,
        help_text="广告活动名称"
    )
    advertiser = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='campaigns',
        help_text="关联的广告主"
    )
    budget = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        help_text="广告活动总预算"
    )
    start_date = models.DateTimeField(
        help_text="广告活动开始时间"
    )
    end_date = models.DateTimeField(
        help_text="广告活动结束时间"
    )
    status = models.CharField(
        max_length=10,
        choices=STATUS_CHOICES,
        default='ACTIVE',
        help_text="广告活动状态：ACTIVE（进行中）、PAUSED（暂停）、COMPLETED（已完成）"
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        help_text="广告活动创建时间"
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        help_text="广告活动最后更新时间"
    )

    def __str__(self):
        return f"{self.name} ({self.status})"
```

### **3.3 广告创意管理**

```python
# 广告创意管理
class Creative(models.Model):
    TYPE_CHOICES = (
        ('IMAGE', 'Image'),
        ('VIDEO', 'Video'),
    )
    campaign = models.ForeignKey(
        Campaign,
        on_delete=models.CASCADE,
        related_name='creatives',
        help_text="关联的广告活动"
    )
    creative_type = models.CharField(
        max_length=10,
        choices=TYPE_CHOICES,
        help_text="创意类型：图片（IMAGE）、视频（VIDEO）"
    )
    file_url = models.URLField(
        help_text="创意文件 URL"
    )
    title = models.CharField(
        max_length=255,
        help_text="创意标题"
    )
    description = models.TextField(
        blank=True,
        null=True,
        help_text="创意描述"
    )
    is_approved = models.BooleanField(
        default=False,
        help_text="创意是否已审核通过"
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        help_text="创意创建时间"
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        help_text="创意最后更新时间"
    )

    def __str__(self):
        return f"{self.title} ({self.creative_type})"
```

### **3.4 投放管理**

```python
# 投放管理
class AdPlacement(models.Model):
    campaign = models.ForeignKey(
        Campaign,
        on_delete=models.CASCADE,
        related_name='placements',
        help_text="关联的广告活动"
    )
    creative = models.ForeignKey(
        Creative,
        on_delete=models.CASCADE,
        help_text="关联的广告创意"
    )
    bid_type = models.CharField(
        max_length=10,
        choices=(('CPC', 'CPC'), ('CPM', 'CPM'), ('CPA', 'CPA')),
        help_text="竞价类型：CPC（每次点击成本）、CPM（每千次展示成本）、CPA（每次行动成本）"
    )
    bid_amount = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        help_text="竞价金额"
    )
    target_audience = models.JSONField(
        help_text="目标受众定向条件，JSON 格式"
    )
    start_time = models.DateTimeField(
        help_text="投放开始时间"
    )
    end_time = models.DateTimeField(
        help_text="投放结束时间"
    )
    status = models.CharField(
        max_length=10,
        choices=(('ACTIVE', 'Active'), ('PAUSED', 'Paused')),
        help_text="投放状态：ACTIVE（进行中）、PAUSED（暂停）"
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        help_text="投放创建时间"
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        help_text="投放最后更新时间"
    )

    def __str__(self):
        return f"{self.campaign.name} - {self.creative.title} ({self.status})"
```

### **3.5 数据统计**

```python
# 数据统计
class AdStat(models.Model):
    placement = models.ForeignKey(
        AdPlacement,
        on_delete=models.CASCADE,
        related_name='stats',
        help_text="关联的广告投放"
    )
    impressions = models.IntegerField(
        default=0,
        help_text="展示次数"
    )
    clicks = models.IntegerField(
        default=0,
        help_text="点击次数"
    )
    conversions = models.IntegerField(
        default=0,
        help_text="转化次数"
    )
    cost = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=0.00,
        help_text="花费金额"
    )
    date = models.DateField(
        help_text="统计日期"
    )

    def __str__(self):
        return f"{self.placement} - {self.date}"
```

### **3.6 预算与计费**

```python
# 预算与计费
class Billing(models.Model):
    advertiser = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='billing',
        help_text="关联的广告主"
    )
    campaign = models.ForeignKey(
        Campaign,
        on_delete=models.CASCADE,
        related_name='billing',
        help_text="关联的广告活动"
    )
    total_budget = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        help_text="总预算"
    )
    spent_amount = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=0.00,
        help_text="已花费金额"
    )
    invoice_number = models.CharField(
        max_length=255,
        unique=True,
        help_text="发票编号"
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        help_text="账单创建时间"
    )

    def __str__(self):
        return f"{self.advertiser.username} - {self.campaign.name} ({self.invoice_number})"
```

### **3.7 日志记录**

```python
# 日志记录
class Log(models.Model):
    LOG_TYPE_CHOICES = (
        ('CHAT', 'Chat'),
        ('INTERACTION', 'Interaction'),
        ('MESSAGE', 'Message'),
        ('LOCATION_VIEW', 'Location View'),
        ('RECHARGE', 'Recharge'),
        ('CONSUME', 'Consume'),
        ('ITEM_USE', 'Item Use'),
        ('LOCATION_REPORT', 'Location Report'),
        ('FEEDBACK', 'Feedback'),
        ('PAGE_STAY', 'Page Stay'),
    )
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='logs',
        help_text="关联的用户"
    )
    log_type = models.CharField(
        max_length=20,
        choices=LOG_TYPE_CHOICES,
        help_text="日志类型"
    )
    details = models.JSONField(
        help_text="日志详细信息，JSON 格式"
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        help_text="日志创建时间"
    )

    def __str__(self):
        return f"{self.user.username} - {self.log_type} ({self.created_at})"
```

### **3.8 聊天会话统计**

```python
# 聊天会话统计
class ChatStat(models.Model):
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='chat_stats',
        help_text="关联的用户"
    )
    session_id = models.CharField(
        max_length=255,
        help_text="聊天会话 ID"
    )
    start_time = models.DateTimeField(
        help_text="会话开始时间"
    )
    end_time = models.DateTimeField(
        help_text="会话结束时间"
    )
    duration = models.IntegerField(
        help_text="会话时长（秒）"
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        help_text="记录创建时间"
    )

    def __str__(self):
        return f"{self.user.username} - {self.session_id} ({self.duration}s)"
```

### **3.9 交互频率统计**

```python
# 交互频率统计
class InteractionStat(models.Model):
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='interaction_stats',
        help_text="关联的用户"
    )
    interaction_type = models.CharField(
        max_length=50,
        help_text="交互类型"
    )
    count = models.IntegerField(
        help_text="交互次数"
    )
    date = models.DateField(
        help_text="统计日期"
    )

    def __str__(self):
        return f"{self.user.username} - {self.interaction_type} ({self.count})"
```

### **3.10 消息处理统计**

```python
# 消息处理统计
class MessageStat(models.Model):
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='message_stats',
        help_text="关联的用户"
    )
    message_count = models.IntegerField(
        help_text="消息处理量"
    )
    time_window = models.CharField(
        max_length=50,
        help_text="时间窗口（如 1h、24h）"
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        help_text="记录创建时间"
    )

    def __str__(self):
        return f"{self.user.username} - {self.message_count} messages in {self.time_window}"
```

### **3.11 位置查看记录**

```python
# 位置查看记录
class LocationView(models.Model):
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='location_views',
        help_text="关联的用户"
    )
    location = models.CharField(
        max_length=255,
        help_text="查看的位置"
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        help_text="记录创建时间"
    )

    def __str__(self):
        return f"{self.user.username} - {self.location} ({self.created_at})"
```

### **3.12 账户充值记录**

```python
# 账户充值记录
class Recharge(models.Model):
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='recharges',
        help_text="关联的用户"
    )
    amount = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        help_text="充值金额"
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        help_text="充值时间"
    )

    def __str__(self):
        return f"{self.user.username} - {self.amount} ({self.created_at})"
```

### **3.13 账户消费记录**

```python
# 账户消费记录
class Consume(models.Model):
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='consumes',
        help_text="关联的用户"
    )
    amount = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        help_text="消费金额"
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        help_text="消费时间"
    )

    def __str__(self):
        return f"{self.user.username} - {self.amount} ({self.created_at})"
```

### **3.14 道具使用记录**

```python
# 道具使用记录
class ItemUse(models.Model):
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='item_uses',
        help_text="关联的用户"
    )
    item_name = models.CharField(
        max_length=255,
        help_text="道具名称"
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        help_text="使用时间"
    )

    def __str__(self):
        return f"{self.user.username} - {self.item_name} ({self.created_at})"
```

### **3.15 地理位置上报**

```python
# 地理位置上报
class LocationReport(models.Model):
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='location_reports',
        help_text="关联的用户"
    )
    latitude = models.FloatField(
        help_text="纬度"
    )
    longitude = models.FloatField(
        help_text="经度"
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        help_text="上报时间"
    )

    def __str__(self):
        return f"{self.user.username} - ({self.latitude}, {self.longitude}) ({self.created_at})"
```

### **3.16 评价记录**

```python
# 评价记录
class Feedback(models.Model):
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='feedbacks',
        help_text="关联的用户"
    )
    rating = models.IntegerField(
        help_text="评分"
    )
    comment = models.TextField(
        blank=True,
        null=True,
        help_text="评价内容"
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        help_text="评价时间"
    )

    def __str__(self):
        return f"{self.user.username} - {self.rating} ({self.created_at})"
```

### **3.17 页面停留与在线时长统计**

```python
# 页面停留与在线时长统计
class PageStay(models.Model):
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='page_stays',
        help_text="关联的用户"
    )
    page_url = models.URLField(
        help_text="页面 URL"
    )
    duration = models.IntegerField(
        help_text="停留时长（秒）"
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        help_text="记录创建时间"
    )

    def __str__(self):
        return f"{self.user.username} - {self.page_url} ({self.duration}s)"
```

## 4. user (用户管理)

> * **功能**：用户的登录注册。
> * **模型**：User
> * **视图**：登录的图片验证码、注册的手机验证码、登录注册。
> * **权限**：广告主、代理商、管理员均可操作。

### 4.1 登录注册

1. 登录![image-20250225120043628](https://typora5672.oss-cn-chengdu.aliyuncs.com/temp/image-20250225120043628.png)
2. 注册![image-20250225120118417](https://typora5672.oss-cn-chengdu.aliyuncs.com/temp/image-20250225120118417.png)
3. 登录后返回用户的token及其他信息![image-20250225120428037](https://typora5672.oss-cn-chengdu.aliyuncs.com/temp/image-20250225120428037.png)

### 4.2 广告主&代理人绑定关系



## 5. advertising（广告管理）

> - **功能**：广告活动创建/编辑/暂停、创意上传/管理、投放策略配置。
> - **模型**：`Campaign`（广告活动）、`Creative`（创意）、`AdPlacement`（投放管理）。
> - **视图**：活动列表/详情、创意管理、投放状态调整。
> - **权限**：广告主、代理商、管理员均可操作（部分操作需角色限制）。

