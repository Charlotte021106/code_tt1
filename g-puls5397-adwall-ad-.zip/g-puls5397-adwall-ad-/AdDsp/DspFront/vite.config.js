import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import path from 'path'
export default defineConfig({
  // base:"/static",
  plugins: [vue()],
  resolve: {
    alias: {
      // 设置别名 这里的./指的是 vite.config.js 的所载目录（根目录）下面的 src
      '@': path.resolve(__dirname, './src')//__dirname用来表示当前执行脚本所在的目录的绝对路径
    },
    //extensions数组的意思是在import组件的时候自动补全.vue等文件后缀
    extensions: ['.mjs', '.js', '.ts', '.jsx', '.tsx', '.json', '.vue']
  },
  server: {
    // open: true,
    host: '127.0.0.1',
    port: 4000,
    proxy: {
      '/api': {
        target: 'http://127.0.0.1:8888',
        ws: true,
        changeOrigin: true,
        rewrite: path => path.replace(/^\/api/, '')
      },
      '/aps': {
        target: 'http://116.62.230.206:8888',
        ws: true,
        changeOrigin: true,
        rewrite: path => path.replace(/^\/aps/, '')
      },
    }
  },
})