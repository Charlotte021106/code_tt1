import {createRouter, createWebHistory} from 'vue-router'
import {ElMessage} from "element-plus";
const Login = () => import('@/views/Login/Login.vue')
const Register = () => import('@/views/Register/Register.vue')
const Home = () => import('@/views/Home/Home.vue')
const homepage = () => import('@/views/Home/HomePage.vue')
const creative = () =>import('@/views/Creative/Creative.vue')
const placement = ()=>import('@/views/Placement/Placement.vue')
const districts = () =>import('@/views/Districts/districts.vue')
const hobbies = () =>import('@/views/Hobbies/hobbies.vue')
const summary = ()=>import('@/views/Stats/Stats.vue')
const manualStats = ()=>import('@/views/Stats/ManualStats.vue')
const billings = ()=>import('@/views/Stats/Billings.vue')
const logList = ()=>import('@/views/Logs/LogList.vue')
const chatStats = ()=>import('@/views/Logs/ChatStats.vue')
const interactionStats = ()=>import('@/views/Logs/InteractionStats.vue')
const messageStats = ()=>import('@/views/Logs/MessageStats.vue')
const locationViews = ()=>import('@/views/Logs/LocationViews.vue')
const recharges = ()=>import('@/views/Logs/Recharges.vue')
const consumes = ()=>import('@/views/Logs/Consumes.vue')
const itemUses = ()=>import('@/views/Logs/ItemUses.vue')
const locationReports = ()=>import('@/views/Logs/LocationReports.vue')
const feedbacks = ()=>import('@/views/Logs/Feedbacks.vue')
const pageStays = ()=>import('@/views/Logs/PageStays.vue')

const routes = [
    {
        path: '/login',
        name: 'login',
        component: Login,
    },
    {
        path: '/register',
        name: 'register',
        component: Register
    },
    {
        path: '/',
        component: Home,
        redirect: '/login',//首页默认重定向到登录页
        children: [
            {
                path: 'home',
                name: 'home',
                component: homepage,
                meta: {
                    isLoggedIn: true,
                    title: '广告活动'
                }
            },
            {
                path: 'creative',
                name: 'creative',
                component: creative,
                meta: {
                    isLoggedIn: true,
                    title: '广告创意'
                }
            },
            {
                path: 'placement',
                name: 'placement',
                component: placement,
                meta: {
                    isLoggedIn: true,
                    title: '广告投放'
                }
            },
            {
                path: 'districts',
                name: 'districts',
                component: districts
            },
            {
                path: 'hobbies',
                name: 'hobbies',
                component: hobbies
            },
            {
                path: 'summary',
                name: 'summary',
                component: summary
            },
            {
                path: 'manualStats',
                name: 'manualStats',
                component: manualStats
            },
            {
                path: 'billings',
                name: 'billings',
                component: billings
            },
            {
                path: 'logs',
                name: 'logs',
                component: logList,
                meta: {
                    isLoggedIn: true,
                    title: '日志管理'
                }
            },
            {
                path: 'chat-stats',
                name: 'chatStats',
                component: chatStats,
                meta: {
                    isLoggedIn: true,
                    title: '聊天统计'
                }
            },
            {
                path: 'interaction-stats',
                name: 'interactionStats',
                component: interactionStats,
                meta: {
                    isLoggedIn: true,
                    title: '交互统计'
                }
            },
            {
                path: 'message-stats',
                name: 'messageStats',
                component: messageStats,
                meta: {
                    isLoggedIn: true,
                    title: '消息统计'
                }
            },
            {
                path: 'location-views',
                name: 'locationViews',
                component: locationViews,
                meta: {
                    isLoggedIn: true,
                    title: '位置查看'
                }
            },
            {
                path: 'recharges',
                name: 'recharges',
                component: recharges,
                meta: {
                    isLoggedIn: true,
                    title: '充值记录'
                }
            },
            {
                path: 'consumes',
                name: 'consumes',
                component: consumes,
                meta: {
                    isLoggedIn: true,
                    title: '消费记录'
                }
            },
            {
                path: 'item-uses',
                name: 'itemUses',
                component: itemUses,
                meta: {
                    isLoggedIn: true,
                    title: '道具使用'
                }
            },
            {
                path: 'location-reports',
                name: 'locationReports',
                component: locationReports,
                meta: {
                    isLoggedIn: true,
                    title: '位置上报'
                }
            },
            {
                path: 'feedbacks',
                name: 'feedbacks',
                component: feedbacks,
                meta: {
                    isLoggedIn: true,
                    title: '评价记录'
                }
            },
            {
                path: 'page-stays',
                name: 'pageStays',
                component: pageStays,
                meta: {
                    isLoggedIn: true,
                    title: '页面停留'
                }
            }
        ]
    },
]

const router = createRouter({
    history: createWebHistory(),
    routes
})

router.beforeEach((to, from, next) => {
    if (to.meta.isLoggedIn) {
        try {
            let token = JSON.parse(localStorage.getItem('userInfo')).userInfo.token
            if (!token) {
                ElMessage.warning("请先登录！")
                next('/login')
            } else {
                next()
            }
        } catch (error) {
            ElMessage.warning("请先登录！")
            next('/login')
        }
    } else {
        next()
    }
})

export default router