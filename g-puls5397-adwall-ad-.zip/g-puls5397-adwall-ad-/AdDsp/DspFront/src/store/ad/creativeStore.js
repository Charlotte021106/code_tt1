import { defineStore } from 'pinia';
import { ref } from 'vue';
import {
    GetCampaigns,
    AddCreative,
    UpdateCreative,
    DeleteCreative,
    GetCreativesByCampaign, GetCreatives
} from '@/api/index.js';
import { ElMessage } from 'element-plus';

export const useCreativeStore = defineStore('creative', () => {
    // 广告活动数据
    const campaigns = ref([]);
    const campaignPagination = ref({
        page: 1,
        size: 5,
        total: 0,
    });

    // 创意数据
    const creatives = ref([]);

    // 获取广告活动列表
    const fetchCampaigns = async () => {
        try {
            const response = await GetCampaigns({
                page: campaignPagination.value.page,
                size: campaignPagination.value.size,
            });
            campaigns.value = response.results;
            campaignPagination.value.total = response.count; // 更新广告活动的总条数
        } catch (error) {
            ElMessage.error('获取广告活动列表失败');
        }
    };

    // 获取创意列表
    const fetchCreatives = async (params = {}) => {
        try {
            if (params.campaign_id) {
                // 直接获取该campaign下的所有创意
                const response = await GetCreativesByCampaign(params.campaign_id);
                creatives.value = response;
            } else {
                const response = await GetCreatives({ ordering: '-created_at' });
                creatives.value = response.results;
            }
        } catch (error) {
            ElMessage.error('获取创意列表失败');
        }
    };

    // 添加创意
    const addCreative = async (formData) => {
        try {
            await AddCreative(formData);
            ElMessage.success('创意添加成功');
            await fetchCreatives(); // 重新获取创意列表
        } catch (error) {
            ElMessage.error('添加创意失败');
        }
    };

    // 更新创意
    const updateCreative = async (id, data) => {
        try {
            await UpdateCreative(id, data);
            ElMessage.success('创意更新成功');
            await fetchCreatives(); // 重新获取创意列表
        } catch (error) {
            ElMessage.error('更新创意失败');
        }
    };

    // 删除创意
    const deleteCreative = async (id) => {
        try {
            await DeleteCreative(id);
            ElMessage.success('创意删除成功');
            await fetchCreatives(); // 重新获取创意列表
        } catch (error) {
            ElMessage.error('删除创意失败');
        }
    };

    // 更新广告活动的分页信息
    const updateCampaignPagination = (page, size) => {
        campaignPagination.value.page = page;
        campaignPagination.value.size = size;
    };

    return {
        campaigns,
        creatives,
        campaignPagination,
        fetchCampaigns,
        fetchCreatives,
        addCreative,
        updateCreative,
        deleteCreative,
        updateCampaignPagination,
    };
});