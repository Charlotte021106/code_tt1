import { defineStore } from "pinia"

const buttonStore = defineStore('button', {
    state: () => ({
        isCollapse: false,
    }),
})

export default buttonStore