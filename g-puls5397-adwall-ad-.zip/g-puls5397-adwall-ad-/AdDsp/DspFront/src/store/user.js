import { defineStore } from "pinia"
import {reactive} from "vue";

const useUserInfoStore = defineStore('userInfo', {
    state: () => ({
        userInfo: {}
    }),
    actions: {
        SetUserInfo(data) {
            this.userInfo = data
        },
        SetUserAvatar(data) {
            this.userInfo.avatar = data
        },
        // DeleteUserInfo() {
        //     // this.userInfo = {}
        //     window.localStorage.clear()
        //     // localStorage.removeItem('userInfo')
        // }
    },
    persist: {
        enabled: true // true 表示开启持久化保存
    },
})

export default useUserInfoStore