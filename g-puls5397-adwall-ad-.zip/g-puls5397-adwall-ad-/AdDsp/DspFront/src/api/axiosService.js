// 1.配置base url 超时时间
//2.请求拦截
//3.响应拦截
//4配置进度条
//显示 隐藏
import axios from 'axios'
import NProgress from 'nprogress'
import 'nprogress/nprogress.css'


const service = axios.create({
    baseURL: '/api',
    timeout: 5000
})

//请求拦截
service.interceptors.request.use(config => {
    //开启进度条
    NProgress.start();
    // 请求时，携带token

    let arr = ['/user/register/', '/user/login/','/user/code/'];

    if (arr.includes(config.url)) {
        // 如果请求的URL在数组中，不做任何特殊处理，这些请求可能是不需要携带token的特殊请求，比如验证码、注册、登录等。
    } else {// 从localStorage中获取保存的用户信息（假设在localStorage中存储了用户的信息）, // 获取用户信息中的token，并将其添加到请求的headers中
        config.headers['Authorization'] = 'Bearer ' + JSON.parse(localStorage.getItem('userInfo'))['userInfo']['token'];
    }
    return config;

})
// 响应拦截
service.interceptors.response.use(res => {
    //关闭进度条
    NProgress.done();
    // 返回响应数据
    return res.data;
}, err => {
    //关闭进度条
    NProgress.done();
    // 返回一个带有错误信息的Promise，用于后续处理
    return Promise.reject(err)

})

export default service