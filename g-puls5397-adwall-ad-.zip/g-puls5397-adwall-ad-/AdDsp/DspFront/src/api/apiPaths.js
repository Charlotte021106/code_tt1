const base = {
    getRegister: "/user/register/",//获取注册账号的接口
    getLogin: "/user/login/",//获取账号登录的接口
    getCode: "/user/code/", //获取注册验证码
    getAgents: "/user/advertiser/agents/", // 获取所有代理人列表
    getBoundAgents: "/user/advertiser/agents-bind/", // 获取绑定代理人列表
    postBindAgent: "/user/advertiser/bind-agent/", //绑定代理人
    deleteAgent: "/user/advertiser/unbind-agent/", //解绑代理人
    campaign: "/advertising/campaign/", //广告活动相关接口
    creative: "/advertising/creative/",//广告创意相关接口
    placement: "/advertising/placement/", //广告投放相关接口
    getHobbies: "/insights/hobby/", //兴趣标签相关接口
    getDistrict: "/insights/district/", //地域标签相关接口
    getAdStats: "/stats/ad-stats/summary/", //数据汇总报表
    manualAdStats: "/stats/manual-stats/", //操纵数据统计
    getBillings: "/stats/billings/", //账单相关
    // 日志相关接口
    logs: "/logs/logs/", //日志相关接口
    logsStatistics: "/logs/logs/statistics/", //日志统计接口
    chatStats: "/logs/chat-stats/", //聊天统计接口
    chatStatsDaily: "/logs/chat-stats/daily_stats/", //聊天每日统计
    interactionStats: "/logs/interaction-stats/", //交互统计接口
    interactionStatsType: "/logs/interaction-stats/type_summary/", //交互类型统计
    messageStats: "/logs/message-stats/", //消息统计接口
    messageStatsRecent: "/logs/message-stats/recent_stats/", //消息最近统计
    locationViews: "/logs/location-views/", //位置查看接口
    recharges: "/logs/recharges/", //充值记录接口
    rechargesTotal: "/logs/recharges/total_amount/", //充值总额统计
    consumes: "/logs/consumes/", //消费记录接口
    consumesTotal: "/logs/consumes/total_amount/", //消费总额统计
    itemUses: "/logs/item-uses/", //道具使用接口
    itemUsesStats: "/logs/item-uses/usage_stats/", //道具使用统计
    locationReports: "/logs/location-reports/", //位置上报接口
    feedbacks: "/logs/feedbacks/", //评价记录接口
    feedbacksRating: "/logs/feedbacks/rating_stats/", //评价评分统计
    pageStays: "/logs/page-stays/" //页面停留接口
}
export default base