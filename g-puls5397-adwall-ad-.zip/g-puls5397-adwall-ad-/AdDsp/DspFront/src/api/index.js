import service from './axiosService.js'
import base from './apiPaths.js'

//注册验证码
export const SendVerificationCode = (params)=>{
    return service.post(base.getCode,params)
}

// 封装用户注册账号的请求函数
export const GetRegisterAccount = (params)=>{
    return service.post(base.getRegister,params)
}

// 封装用户登录平台的请求函数
export const login = (params)=>{
    return service.post(base.getLogin,params)
}

export const GetAgents = (params) => {
    return service.get(base.getAgents,params)
}

export const GetBoundAgents = (params) => {
    return service.get(base.getBoundAgents,params)
}
export const PostBindAgent = (params)=>{
    return service.post(base.postBindAgent,params)
}

export const DeleteBindAgent= (id)=>{
    return service.delete(base.deleteAgent+`${id}/`)
}

export const GetCampaigns = (params)=>{
    return service.get(base.campaign,{params:params})
}

export const AddCampaign = (data)=>{
    return service.post(base.campaign,data)
}

export const UpdateCampaign = (id, data) => {
    return service.put(`${base.campaign}/${id}/`, data);
};

export const DeleteCampaign = (id) => {
    return service.delete(`${base.campaign}/${id}/`);
};

export const ActivateCampaign = (id)=>{
    return service.post(`${base.campaign}/${id}/activate/`)
}
export const PauseCampaign = (id)=>{
    return service.post(`${base.campaign}/${id}/pause/`)
}

export const ActiveAdPlacement = (id)=>{
    return service.post(`${base.placement}/${id}/activate/`)
}
export const PauseAdPlacement = (id)=>{
    return service.post(`${base.placement}/${id}/pause/`)
}


export const GetCreatives = (params)=>{
    return service.get(base.creative,{params:params})
}


export const AddCreative = (data) => {
    return service.post(base.creative,data)
};

export const UpdateCreative = (id, data) => {
    return service.put(`${base.creative}/${id}/`, data);
};


export const DeleteCreative = (id) => {
    return service.delete(`${base.creative}/${id}/`);
};




export const GetAdPlacements = (params)=>{
    return service.get(base.placement,{params:params})
}
export const CreateAdPlacement = (data)=>{
    return service.post(base.placement,data)
}
export const UpdateAdPlacement = (id,data)=>{
    return service.patch(`${base.placement}/${id}/`, data);
}

export const DeleteAdPlacement = (id)=>{
    return service.delete(`${base.placement}/${id}/`);
}

export const GetCreativesByCampaign = (id)=>{
    return service.get(base.creative+`by_campaign/?campaign_id=${id}`)
}

export const FetchInterests = ()=>{
    return service.get(base.getHobbies)
}
export const AddInterestTag = (data)=>{
    return service.post(base.getHobbies,data)
}
export const RemoveInterestTag = (id)=>{
    return service.delete(base.getHobbies+`${id}/`)
}
export const UpdateInterestTag =  (id,data)=>{
    return service.put(base.getHobbies+`${id}/`,data)
}

export const FetchDistricts = ()=>{
    return service.get(base.getDistrict)
}
export const AddDistrictTag = (data)=>{
    return service.post(base.getDistrict,data)
}

export const RemoveDistrictTag = (id)=>{
    return service.delete(base.getDistrict+`${id}/`)
}
export const UpdateDistrictTag =  (id,data)=>{
    return service.put(base.getDistrict+`${id}/`,data)
}

export const CreateManualStat = (data)=>{
    return service.post(base.manualAdStats,data)
}

export const GetAdStatsSummary = (params)=>{
    return service.get(base.getAdStats,{params:params})
}

export const GetBillingList = (params)=>{
    return service.get(base.getBillings,{params:params})
}
export const DownloadInvoice = (id)=>{
    return service.get(base.getBillings+`${id}/download_invoice/`)
}

// 日志相关接口
export const GetLogs = (params) => {
    return service.get(base.logs, {params: params})
}

export const GetLogDetail = (id) => {
    return service.get(`${base.logs}${id}/`)
}

export const CreateLog = (data) => {
    return service.post(base.logs, data)
}

export const UpdateLog = (id, data) => {
    return service.put(`${base.logs}${id}/`, data)
}

export const DeleteLog = (id) => {
    return service.delete(`${base.logs}${id}/`)
}

export const GetLogStatistics = () => {
    return service.get(`${base.logs}statistics/`)
}

// 聊天统计接口
export const GetChatStats = (params) => {
    return service.get(base.chatStats, {params: params})
}

export const GetChatDailyStats = () => {
    return service.get(`${base.chatStats}daily_stats/`)
}

// 交互统计接口
export const GetInteractionStats = (params) => {
    return service.get(base.interactionStats, {params: params})
}

export const GetInteractionTypeSummary = () => {
    return service.get(`${base.interactionStats}type_summary/`)
}

// 消息统计接口
export const GetMessageStats = (params) => {
    return service.get(base.messageStats, {params: params})
}

export const GetMessageRecentStats = () => {
    return service.get(`${base.messageStats}recent_stats/`)
}

// 位置查看接口
export const GetLocationViews = (params) => {
    return service.get(base.locationViews, {params: params})
}

// 充值记录接口
export const GetRecharges = (params) => {
    return service.get(base.recharges, {params: params})
}

export const GetRechargeTotalAmount = () => {
    return service.get(`${base.recharges}total_amount/`)
}

// 消费记录接口
export const GetConsumes = (params) => {
    return service.get(base.consumes, {params: params})
}

export const GetConsumeTotalAmount = () => {
    return service.get(`${base.consumes}total_amount/`)
}

// 道具使用接口
export const GetItemUses = (params) => {
    return service.get(base.itemUses, {params: params})
}

export const GetItemUsageStats = () => {
    return service.get(`${base.itemUses}usage_stats/`)
}

// 位置上报接口
export const GetLocationReports = (params) => {
    return service.get(base.locationReports, {params: params})
}

// 评价记录接口
export const GetFeedbacks = (params) => {
    return service.get(base.feedbacks, {params: params})
}

export const GetFeedbackRatingStats = () => {
    return service.get(`${base.feedbacks}rating_stats/`)
}

// 页面停留接口
export const GetPageStays = (params) => {
    return service.get(base.pageStays, {params: params})
}

export const GetPageStayStats = () => {
    return service.get(`${base.pageStays}page_stats/`)
}