<script setup>
import {ref, onMounted} from 'vue';
import {
  GetAdPlacements,
  CreateAdPlacement,
  UpdateAdPlacement,
  DeleteAdPlacement,
  GetCampaigns,
  GetCreativesByCampaign, ActiveAdPlacement, PauseAdPlacement,
} from '@/api/index.js';
import AdPlacementList from './PlacementList.vue';
import AdPlacementForm from './PlacementForm.vue';
import EditPlacementDialog from './PlacementDialog.vue'; // 新增
import {ElMessage} from "element-plus";

// 原有状态保持不变
const placements = ref([]);
const campaigns = ref([]);
const creatives = ref([]);
const formTitle = ref('创建广告投放');
const formData = ref({
  campaign: null,
  creative: null,
  bid_type: 'CPC',
  bid_amount: 0.5,
  target_audience: {
    geo: [],
    age_range: [18, 35],
    gender: '',
    device_type: [],
    interest_tags: [],
  },
  time_range: [],
});

// 新增编辑相关状态
const showEditDialog = ref(false);
const editingData = ref({});

// 保持原有方法不变
const fetchPlacements = async () => {
  try {
    const data = await GetAdPlacements();
    placements.value = data;
  } catch (error) {
    console.log(error);
  }
};

const fetchCampaigns = async () => {
  const data = await GetCampaigns();
  campaigns.value = data.results;
};

const fetchCreativesByCampaign = async (campaignId) => {
  const data = await GetCreativesByCampaign(campaignId);
  creatives.value = data;
};


const handleSubmit = async (data) => {
  try {
    const isDuplicate = placements.value.some(placement =>
        placement.campaign === data.campaign &&
        placement.creative === data.creative
    );

    if (isDuplicate) {
      ElMessage.error('同一广告活动和广告创意只能创建一个广告投放');
      return;
    }

    await CreateAdPlacement(data);

    // 新增成功提示
    ElMessage.success({
      message: '创建成功',
      duration: 2000
    });

    await fetchPlacements();

  } catch (error) {
    ElMessage.error({
      message: `创建失败：${error.message || '未知错误'}`,
      duration: 3000
    });
    console.error('创建失败详情:', error);
  }
};

// 新增编辑提交方法
const handleEditSubmit = async (data) => {
  console.log(data)
  try {
    await UpdateAdPlacement(data.id, {
      bid_type: data.bid_type,
      bid_amount: data.bid_amount,
      status: data.status
    });
    ElMessage.success('更新成功');
    await fetchPlacements();
  } catch (error) {
    ElMessage.error('更新失败');
  }
};


const handleDelete = async (id) => {
  try {
    await DeleteAdPlacement(id);
    await fetchPlacements();
    ElMessage.success('删除成功');
  } catch (error) {
    ElMessage.error('删除失败，请重试');
  }
};

// 状态操作方法（使用新接口）
const handleActivate = async (placement) => {
  try {
    const { id } = placement
    await ActiveAdPlacement(id)  // 调用专用激活接口
    ElMessage.success('投放已激活')
    await fetchPlacements()
  } catch (error) {
    ElMessage.error(`激活失败: ${error.response?.data?.error}`)
    console.error('激活失败详情:', error.response?.data)
  }
}

const handlePause = async (placement) => {
  try {
    const { id } = placement
    await PauseAdPlacement(id)  // 调用专用暂停接口
    ElMessage.warning('投放已暂停')
    await fetchPlacements()
  } catch (error) {
    ElMessage.error(`暂停失败: ${error.response?.data?.error}`)
    console.error('暂停失败详情:', error.response?.data)
  }
}
onMounted(async () => {
  await fetchPlacements();
  await fetchCampaigns();
});
</script>

<template>
  <div class="ad-placement-page">
    <div class="form-section">
      <h2>{{ formTitle }}</h2>
      <AdPlacementForm
          :campaigns="campaigns"
          :creatives="creatives"
          :initial-data="formData"
          @submit="handleSubmit"
          @campaign-change="fetchCreativesByCampaign"
      />
    </div>

    <EditPlacementDialog
        v-model:visible="showEditDialog"
        :placement-data="editingData"
        @submit="handleEditSubmit"
    />

    <!-- 列表区域修改事件处理 -->
    <div class="list-section">
      <h2>广告投放列表</h2>
      <AdPlacementList
          :placements="placements"
          @edit="(row) => {
          editingData = { ...row };
          showEditDialog = true;
        }"
          @delete="handleDelete"
          @activate="handleActivate"
          @pause="handlePause"
      />
    </div>
  </div>
</template>


<style scoped lang="less">
.ad-placement-page {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
  display: flex;
  gap: 24px;

  .form-section,
  .list-section {
    background: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  }

  h2 {
    margin-bottom: 20px;
    font-size: 20px;
    color: #303133;
  }
}
</style>