<script setup>
import {ref, watch} from 'vue';
import {ElMessage} from 'element-plus';

const props = defineProps({
  visible: Boolean,
  placementData: {
    type: Object,
    required: true
  }
});

const emit = defineEmits(['update:visible', 'submit']);

// 简化响应式状态
const visible = ref(false);
const formData = ref({
  id: null,
  bid_type: 'CPC',
  bid_amount: 0.5
});

// 状态同步逻辑优化
watch(() => props.visible, (val) => visible.value = val);
watch(visible, (val) => emit('update:visible', val));

// 数据初始化（去除状态字段）
watch(
    () => props.placementData,
    (newVal) => {
      if (newVal?.id) {
        formData.value = {
          id: newVal.id,
          bid_type: newVal.bid_type,
          bid_amount: Number(newVal.bid_amount) || 0.5
        }
      }
    },
    {immediate: true}
);

const handleSubmit = () => {
  // 强化验证逻辑
  if (!formData.value.bid_type || !formData.value.bid_amount) {
    ElMessage.error('请填写完整出价信息');
    return;
  }

  if (formData.value.bid_amount <= 0) {
    ElMessage.error('出价金额必须大于0');
    return;
  }

  emit('submit', {...formData.value});
  visible.value = false;
};
</script>

<template>
  <el-dialog
      v-model="visible"
      title="编辑广告参数"
      width="400px"
      :close-on-click-modal="false"
  >
    <el-form :model="formData" label-width="100px">
      <!-- 出价类型 -->
      <el-form-item label="出价类型" required>
        <el-select
            v-model="formData.bid_type"
            placeholder="请选择"
            class="full-width"
        >
          <el-option label="CPC（按点击付费）" value="CPC"/>
          <el-option label="CPM（按展示付费）" value="CPM"/>
        </el-select>
      </el-form-item>

      <!-- 出价金额 -->
      <el-form-item label="出价金额" required>
        <el-input-number
            v-model="formData.bid_amount"
            :min="0.1"
            :step="0.1"
            :precision="2"
            controls-position="right"
            class="full-width"
        />
        <div class="form-tips">单位：元</div>
      </el-form-item>
    </el-form>

    <template #footer>
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" @click="handleSubmit">保存</el-button>
    </template>
  </el-dialog>
</template>

<style scoped>
.full-width {
  width: 100%;
}

.form-tips {
  font-size: 12px;
  color: #999;
  margin-top: 4px;
}
</style>