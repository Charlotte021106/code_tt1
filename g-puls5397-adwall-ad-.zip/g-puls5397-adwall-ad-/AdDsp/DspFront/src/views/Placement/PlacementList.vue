<template>
  <el-table :data="placements" style="width: 100%">
    <el-table-column prop="id" label="ID" width="80" />
    <el-table-column prop="campaign_name" label="广告活动" />
    <el-table-column prop="creative_title" label="广告创意" />
    <el-table-column prop="bid_type" label="出价类型" />
    <el-table-column prop="bid_amount" label="出价金额" />
    <el-table-column prop="status" label="状态">
      <template #default="scope">
        <el-tag
            :type="scope.row.status === 'ACTIVE' ? 'success' : 'danger'"
            effect="light"
            round
        >
          {{ scope.row.status === 'ACTIVE' ? '进行中' : '暂停' }}
        </el-tag>
      </template>
    </el-table-column>
    <el-table-column label="投放时段" width="220">
      <template #default="scope">
        <div class="time-range">
          <div>{{ formatDateTime(scope.row.start_time) }}</div>
          <div class="separator">至</div>
          <div>{{ formatDateTime(scope.row.end_time) }}</div>
        </div>
      </template>
    </el-table-column>
    <el-table-column label="操作" width="260">
      <template #default="scope">
        <!-- 状态切换按钮 -->
        <el-button
            v-if="scope.row.status === 'PAUSED'"
            type="success"
            size="small"
            :loading="loadingStates[scope.row.id]?.activate"
            @click="emitActivate(scope.row)"
        >
          启用
        </el-button>
        <el-button
            v-else-if="scope.row.status === 'ACTIVE'"
            type="warning"
            size="small"
            :loading="loadingStates[scope.row.id]?.pause"
            @click="emitPause(scope.row)"
        >
          暂停
        </el-button>

        <!-- 独立编辑按钮 -->
        <el-button
            type="primary"
            size="small"
            @click="emitEdit(scope.row)"
        >
          编辑
        </el-button>

        <el-button
            type="danger"
            size="small"
            @click="emitDelete(scope.row.id)"
        >
          删除
        </el-button>
      </template>
    </el-table-column>
  </el-table>
</template>

<script setup>
import { ref } from 'vue'
import {formatDateTime} from "@/utils/formatTime.js";

const props = defineProps({
  placements: Array,
  required: true
})

const emit = defineEmits(['edit', 'delete', 'activate', 'pause'])

// 加载状态管理
const loadingStates = ref({})

const emitEdit = (placement) => emit('edit', placement)
const emitDelete = (id) => emit('delete', id)

const emitActivate = async (placement) => {
  loadingStates.value[placement.id] = { activate: true }
  emit('activate', placement)
  loadingStates.value[placement.id].activate = false
}

const emitPause = async (placement) => {
  loadingStates.value[placement.id] = { pause: true }
  emit('pause', placement)
  loadingStates.value[placement.id].pause = false
}
</script>

<style scoped>
.el-table {
  margin-top: 20px;
}
</style>