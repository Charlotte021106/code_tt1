<script setup>
import { ref, onMounted, watch } from 'vue'
import { ElNotification, ElIcon, ElTag, ElDescriptions, ElDescriptionsItem } from 'element-plus'
import {Apple, Cellphone, CollectionTag, Iphone, Location, Platform} from '@element-plus/icons-vue'
import { FetchInterests, FetchDistricts } from '@/api/index.js'
import { formatDateTime } from '@/utils/formatTime'
import dayjs from 'dayjs'

const props = defineProps({
  campaigns: {
    type: Array,
    required: true,
  },
  creatives: {
    type: Array,
    required: true,
  },
  initialData: {
    type: Object,
    default: () => ({
      campaign: null,
      creative: null,
      bid_type: 'CPC',
      bid_amount: 0.5,
      target_audience: {
        geo: [],
        age_range: [18, 35],
        gender: '',
        device_type: [],
        interest_tags: [],
      },
      start_time: null,
      end_time: null,
    }),
  },
})

const emit = defineEmits(['submit', 'campaign-change'])

// 表单数据
const form = ref({ ...props.initialData })
const dateRange = ref([])
const interests = ref([])
const districts = ref([])
const loading = ref({ interests: false, districts: false })
const selectedCampaign = ref(null)

// 状态映射配置
const statusMap = {
  ACTIVE: '进行中',
  COMPLETED: '已完成',
  PAUSED: '已暂停',
}

const statusTypeMap = {
  ACTIVE: 'success',
  COMPLETED: 'info',
  PAUSED: 'warning',
}

// 加载数据
onMounted(async () => {
  try {
    const [interestsRes, districtsRes] = await Promise.all([
      FetchInterests(),
      FetchDistricts()
    ])

    interests.value = interestsRes.map(item => ({
      value: item.hobby_tag,
      label: item.hobby_tag
    }))

    // 修正地域数据处理
    districts.value = districtsRes.map(item => ({
      value: item.city ? `${item.province}-${item.city}` : item.province,
      label: item.city ? `${item.province} - ${item.city}` : item.province
    }))
  } catch (error) {
    ElNotification({
      title: '错误',
      message: '数据加载失败',
      type: 'error'
    })
  }
})

// 处理广告活动选择
const handleCampaignChange = (campaignId) => {
  selectedCampaign.value = props.campaigns.find(c => c.id === campaignId)
  form.value.start_time = null
  form.value.end_time = null
  dateRange.value = []
  emit('campaign-change', campaignId)
}

// 日期禁用规则
const disabledDate = (time) => {
  if (!selectedCampaign.value) return true
  const start = dayjs(selectedCampaign.value.start_date)
  const end = dayjs(selectedCampaign.value.end_date)
  return dayjs(time).isBefore(start.startOf('day')) ||
      dayjs(time).isAfter(end.endOf('day'))
}

// 处理日期变化
const handleDateChange = (dates) => {
  if (dates && dates.length === 2) {
    form.value.start_time = dates[0]
    form.value.end_time = dates[1]
  } else {
    form.value.start_time = null
    form.value.end_time = null
  }
}

// 表单验证和提交
const submitForm = () => {
  if (!validateForm()) return
  emit('submit', form.value)
}

const validateForm = () => {
  // 基本验证
  if (!form.value.campaign) {
    ElNotification({ title: '警告', message: '请选择广告活动', type: 'warning' })
    return false
  }
  if (!form.value.creative) {
    ElNotification({ title: '警告', message: '请选择广告创意', type: 'warning' })
    return false
  }
  if (form.value.target_audience.geo.length === 0) {
    ElNotification({ title: '警告', message: '请至少选择一个地域', type: 'warning' })
    return false
  }

  // 时间验证
  if (!form.value.start_time || !form.value.end_time) {
    ElNotification({ title: '警告', message: '请选择完整的投放时间', type: 'warning' })
    return false
  }

  const start = dayjs(form.value.start_time)
  const end = dayjs(form.value.end_time)
  const campaignStart = dayjs(selectedCampaign.value.start_date)
  const campaignEnd = dayjs(selectedCampaign.value.end_date)

  // 时间顺序验证
  if (start.isAfter(end)) {
    ElNotification({ title: '错误', message: '结束时间不能早于开始时间', type: 'error' })
    return false
  }

  // 时间范围验证
  if (start.isBefore(campaignStart) || end.isAfter(campaignEnd)) {
    ElNotification({
      title: '错误',
      message: `投放时间必须在活动时间范围内（${formatDateTime(campaignStart)} - ${formatDateTime(campaignEnd)}）`,
      type: 'error'
    })
    return false
  }

  return true
}

// 重置表单
const resetForm = () => {
  form.value = { ...props.initialData }
  dateRange.value = []
  selectedCampaign.value = null
}

// 同步日期范围显示
watch(() => [form.value.start_time, form.value.end_time], ([start, end]) => {
  dateRange.value = start && end ? [start, end] : []
})
</script>

<template>
  <el-form class="ad-form" :model="form" label-width="120px" label-position="top">
    <!-- 广告活动 -->
    <el-form-item label="广告活动" required>
      <el-select
          v-model="form.campaign"
          placeholder="请选择广告活动"
          @change="handleCampaignChange"
      >
        <el-option
            v-for="campaign in campaigns"
            :key="campaign.id"
            :label="campaign.name"
            :value="campaign.id"
        >
          <div class="campaign-option">
            <div class="campaign-header">
              <span class="name">{{ campaign.name }}</span>
              <el-tag
                  :type="statusTypeMap[campaign.status]"
                  size="small"
                  effect="light"
              >
                {{ statusMap[campaign.status] }}
              </el-tag>
            </div>
            <div class="campaign-dates">
              <span>{{ formatDateTime(campaign.start_date, 'YYYY-MM-DD') }}</span>
              <span class="separator">至</span>
              <span>{{ formatDateTime(campaign.end_date, 'YYYY-MM-DD') }}</span>
            </div>
          </div>
        </el-option>
      </el-select>

      <!-- 活动详情展示 -->
      <div v-if="selectedCampaign" class="campaign-details">
        <el-descriptions :column="1" border>
          <el-descriptions-item label="状态" width="120px">
            <el-tag :type="statusTypeMap[selectedCampaign.status]" size="small">
              {{ statusMap[selectedCampaign.status] }}
            </el-tag>
          </el-descriptions-item>
          <el-descriptions-item label="开始时间">
            {{ formatDateTime(selectedCampaign.start_date) }}
          </el-descriptions-item>
          <el-descriptions-item label="结束时间">
            {{ formatDateTime(selectedCampaign.end_date) }}
          </el-descriptions-item>
          <el-descriptions-item label="预算">
            ￥{{ selectedCampaign.budget }}
          </el-descriptions-item>
        </el-descriptions>
      </div>
    </el-form-item>

    <!-- 广告创意 -->
    <el-form-item label="广告创意" required>
      <el-select v-model="form.creative" placeholder="请选择广告创意">
        <el-option
            v-for="creative in creatives"
            :key="creative.id"
            :label="creative.title"
            :value="creative.id"
        />
      </el-select>
    </el-form-item>

    <!-- 出价设置 -->
    <div class="bid-settings">
      <el-form-item label="出价类型" required>
        <el-select v-model="form.bid_type" placeholder="请选择出价类型">
          <el-option label="CPC" value="CPC" />
          <el-option label="CPM" value="CPM" />
          <el-option label="CPA" value="CPA" />
        </el-select>
      </el-form-item>
      <el-form-item label="出价金额" required>
        <el-input-number
            v-model="form.bid_amount"
            :min="0.1"
            :precision="2"
            controls-position="right"
        />
      </el-form-item>
    </div>

    <!-- 目标受众 -->
    <div class="target-audience">
      <h3>目标受众设置</h3>

      <!-- 地域选择 -->
      <el-form-item label="投放地域" required>
        <el-select
            v-model="form.target_audience.geo"
            multiple
            filterable
            collapse-tags
            :loading="loading.districts"
            placeholder="选择或搜索投放地域"
        >
          <template #prefix>
            <el-icon><Location /></el-icon>
          </template>
          <el-option
              v-for="district in districts"
              :key="district.value"
              :label="district.label"
              :value="district.value"
          />
        </el-select>
      </el-form-item>

      <!-- 年龄范围 -->
      <el-form-item label="年龄范围" required>
        <el-slider
            v-model="form.target_audience.age_range"
            range
            :min="18"
            :max="65"
            :format-tooltip="value => `${value}岁`"
        />
      </el-form-item>

      <!-- 兴趣标签 -->
      <el-form-item label="兴趣标签">
        <el-select
            v-model="form.target_audience.interest_tags"
            multiple
            filterable
            collapse-tags
            :loading="loading.interests"
            placeholder="选择或搜索兴趣标签"
        >
          <template #prefix>
            <el-icon><CollectionTag /></el-icon>
          </template>
          <el-option
              v-for="interest in interests"
              :key="interest.value"
              :label="interest.label"
              :value="interest.value"
          />
        </el-select>
      </el-form-item>

      <!-- 其他受众设置 -->
      <div class="audience-extra">
        <el-form-item label="性别" class="gender-select">
          <el-select v-model="form.target_audience.gender" clearable placeholder="全部">
            <el-option label="全部" value="" />
            <el-option label="男性" value="male" />
            <el-option label="女性" value="female" />
          </el-select>
        </el-form-item>

        <el-form-item label="设备类型" class="device-checkboxes">
          <el-checkbox-group
              v-model="form.target_audience.device_type"
          >
            <!-- 移动设备 -->
            <el-checkbox label="ios" border size="large">
              <div class="device-option">
                <el-icon class="apple"><Iphone /></el-icon>
                <span>iOS 设备</span>
              </div>
            </el-checkbox>

            <el-checkbox label="android" border size="large">
              <div class="device-option">
                <el-icon class="android"><Cellphone /></el-icon>
                <span>Android 手机</span>
              </div>
            </el-checkbox>
            <!-- 桌面设备 -->
            <el-checkbox label="windows" border size="large">
              <div class="device-option">
                <el-icon class="windows"><Platform /></el-icon>
                <span>Windows PC</span>
              </div>
            </el-checkbox>

            <el-checkbox label="macos" border size="large">
              <div class="device-option">
                <el-icon class="mac"><Apple /></el-icon>
                <span>Mac 电脑</span>
              </div>
            </el-checkbox>
          </el-checkbox-group>
        </el-form-item>
      </div>
    </div>

    <!-- 投放时间 -->
    <el-form-item label="投放时间" required>
      <el-date-picker
          v-model="dateRange"
          type="datetimerange"
          :disabled="!form.campaign"
          :disabled-date="disabledDate"
          range-separator="至"
          start-placeholder="开始时间"
          end-placeholder="结束时间"
          value-format="YYYY-MM-DD HH:mm:ss"
          @change="handleDateChange"
      />
      <div v-if="selectedCampaign" class="time-tip">
        活动有效时间：{{ formatDateTime(selectedCampaign.start_date) }} - {{ formatDateTime(selectedCampaign.end_date) }}
      </div>
    </el-form-item>

    <!-- 表单操作 -->
    <el-form-item class="form-actions">
      <el-button type="primary" @click="submitForm" size="large">立即投放</el-button>
      <el-button @click="resetForm" size="large">重置表单</el-button>
    </el-form-item>
  </el-form>
</template>

<style scoped lang="less">
.ad-form {
  max-width: 800px;
  margin: 20px auto;
  padding: 24px;
  background: #fff;
  border-radius: 8px;
  box-shadow: 0 2px 12px rgba(0,0,0,0.1);

  .campaign-option {
    width: 100%;
    padding: 8px 12px;

    .campaign-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 4px;

      .name {
        font-weight: 500;
        margin-right: 8px;
      }
    }

    .campaign-dates {
      font-size: 12px;
      color: #666;

      .separator {
        margin: 0 4px;
        color: #999;
      }
    }
  }

  .campaign-details {
    margin-top: 16px;

    :deep(.el-descriptions__body) {
      background: #f8f9fa;
    }
  }

  .bid-settings {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
  }

  .target-audience {
    margin-top: 24px;
    padding-top: 24px;
    border-top: 1px solid #eee;

    h3 {
      color: #333;
      margin-bottom: 20px;
    }

    .audience-extra {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 20px;
    }
  }

  .form-actions {
    margin-top: 32px;
    text-align: center;
  }

  :deep(.el-select) {
    width: 100%;
  }

  :deep(.el-select__tags) {
    max-width: 90%;
    flex-wrap: nowrap;
    overflow: hidden;
  }

  .el-icon {
    margin-right: 8px;
    color: #666;
  }

  .time-tip {
    font-size: 12px;
    color: #666;
    margin-top: 8px;
  }

  @media (max-width: 768px) {
    .campaign-option {
      .campaign-header {
        flex-wrap: wrap;

        .name {
          width: 100%;
          margin-bottom: 4px;
        }
      }
    }

    .bid-settings,
    .audience-extra {
      grid-template-columns: 1fr;
    }
  }
}
.device-checkboxes {
  .device-option {
    display: flex;
    align-items: center;
    padding: 8px 12px;

    .el-icon {
      font-size: 20px;
      margin-right: 8px;

      &.apple { color: #666; }
      &.android { color: #3ddc84; }
      &.windows { color: #00adef; }
      &.mac { color: #999; }
      &.tablet { color: #ff2d55; }
      &.smart { color: #666; }
    }

    span {
      font-size: 14px;
    }
  }

  /* 响应式布局 */
  @media (max-width: 768px) {
    .el-checkbox {
      width: 100%;
      margin: 5px 0;
    }
  }
}
</style>