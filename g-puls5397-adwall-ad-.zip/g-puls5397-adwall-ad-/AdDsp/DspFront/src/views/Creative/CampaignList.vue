<script setup>
import { useCreativeStore } from '@/store/ad/creativeStore';
import CreativeList from './CreativeList.vue';
import { formatDateTime } from '@/utils/formatTime';

const creativeStore = useCreativeStore();

// 广告活动分页变化处理
const handleCampaignPageChange = (page) => {
  creativeStore.updateCampaignPagination(page, creativeStore.campaignPagination.size);
  creativeStore.fetchCampaigns();
};
</script>

<template>
  <div class="campaign-list">
    <!-- 遍历分页后的广告活动 -->
    <el-card
        v-for="campaign in creativeStore.campaigns"
        :key="campaign.id"
        class="campaign-item"
        shadow="hover"
    >
      <!-- 广告活动基本信息 -->
      <div class="campaign-info">
        <h3>{{ campaign.name }}</h3>
        <p>预算: {{ campaign.budget }}</p>
        <p>状态: {{
            campaign.status === 'ACTIVE' ? '进行中' :
                campaign.status === 'PAUSED' ? '暂停' : '已完成'
          }}</p>
        <p>开始时间: {{ formatDateTime(campaign.start_date) }}</p>
        <p>结束时间: {{ formatDateTime(campaign.end_date) }}</p>
      </div>

      <!-- 关联的创意列表（只传campaignId） -->
      <CreativeList
          v-if="campaign.status !== 'COMPLETED'"
          :campaignId="campaign.id"
      />
    </el-card>

    <!-- 广告活动分页组件（保留） -->
    <el-pagination
        v-if="creativeStore.campaignPagination.total > 0"
        :current-page="creativeStore.campaignPagination.page"
        :page-size="creativeStore.campaignPagination.size"
        :total="creativeStore.campaignPagination.total"
        layout="total, prev, pager, next, jumper"
        @current-change="handleCampaignPageChange"
        class="pagination"
    />
  </div>
</template>

<style scoped lang="less">
.campaign-list {
  display: flex;
  flex-direction: column;
  gap: 16px;
  padding: 16px;
}

.campaign-item {
  border-radius: 8px;
  background-color: #fff;
  transition: box-shadow 0.3s ease;

  &:hover {
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  }
}

.campaign-info {
  margin-bottom: 16px;

  h3 {
    margin: 0;
    font-size: 16px;
    font-weight: bold;
    color: #333;
  }

  p {
    margin: 4px 0;
    font-size: 14px;
    color: #666;
  }
}

.pagination {
  margin-top: 16px;
  text-align: center;
}
</style>