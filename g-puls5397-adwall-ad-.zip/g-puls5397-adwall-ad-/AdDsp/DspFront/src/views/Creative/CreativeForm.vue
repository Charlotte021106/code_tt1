<template>
  <el-form :model="creative" ref="formRef" label-width="120px">
    <!-- 创意标题 -->
    <el-form-item
        label="创意标题"
        prop="title"
        :rules="[{ required: true, message: '请输入创意标题', trigger: 'blur' }]"
    >
      <el-input v-model="creative.title" placeholder="请输入创意标题" />
    </el-form-item>

    <!-- 创意描述 -->
    <el-form-item label="创意描述" prop="description">
      <el-input
          v-model="creative.description"
          type="textarea"
          placeholder="请输入创意描述"
      />
    </el-form-item>

    <!-- 创意类型 -->
    <el-form-item
        label="创意类型"
        prop="creative_type"
        :rules="[{ required: true, message: '请选择创意类型', trigger: 'change' }]"
    >
      <el-radio-group v-model="creative.creative_type" @change="handleTypeChange">
        <el-radio :label="'IMAGE'">图片</el-radio>
        <el-radio :label="'VIDEO'">视频</el-radio>
      </el-radio-group>
    </el-form-item>

    <!-- 图片上传区域 -->
    <el-form-item v-if="creative.creative_type === 'IMAGE'" label="上传图片">
      <el-upload
          ref="uploadRef"
          action="#"
          list-type="picture-card"
          :auto-upload="false"
          :multiple="false"
          :limit="1"
          :on-exceed="handleExceed"
          :on-preview="onPreview"
          :on-remove="onRemove"
          :on-change="handleFileChange"
          accept="image/*"
          class="upload-area"
          :file-list="fileList"
      >
        <el-icon>
          <Plus />
        </el-icon>
      </el-upload>
      <div class="upload-tip">请上传格式为 JPG、PNG、BMP 等图片文件。</div>
    </el-form-item>

    <!-- 视频上传区域 -->
    <el-form-item v-if="creative.creative_type === 'VIDEO'" label="上传视频">
      <el-upload
          ref="uploadRef"
          action="#"
          drag
          :auto-upload="false"
          :limit="1"
          :multiple="false"
          :on-exceed="handleExceed"
          :on-remove="onRemove"
          :on-change="handleFileChange"
          accept="video/*"
          class="upload-area"
          :file-list="fileList"
      >
        <el-icon class="el-icon--upload">
          <UploadFilled />
        </el-icon>
        <div class="el-upload__text">
          将视频文件拖到此处，或<em>点击上传</em>
        </div>
        <template #tip>
          <div class="el-upload__tip">
            请上传格式为 MP4、AVI 等视频文件，文件大小不超过 10MB。
          </div>
        </template>
      </el-upload>
      <!-- 视频预览 -->
      <div v-if="video_url && creative.creative_type === 'VIDEO'" class="video-preview">
        <video :src="video_url" controls class="preview-video"></video>
      </div>
    </el-form-item>
  </el-form>

  <!-- 预览对话框 -->
  <el-dialog v-model="dialogImgVisible" title="预览">
    <div v-if="isVideoPreview">
      <video :src="dialogImgUrl" controls style="width: 100%;"></video>
    </div>
    <img v-else :src="dialogImgUrl" alt="Preview Image" style="max-width: 100%;" />
  </el-dialog>
</template>

<script setup>
import {ref, watch, computed} from 'vue'
import {ElMessage} from 'element-plus'
import {Plus, UploadFilled} from '@element-plus/icons-vue'

const props = defineProps({
  creative: {
    type: Object,
    required: true
  }
})

const emit = defineEmits(['preview'])

// 响应式数据
const video_url = ref('')
const formRef = ref(null)
const uploadRef = ref(null)
const dialogImgVisible = ref(false)
const dialogImgUrl = ref('')
const temp_file = ref(null)
const fileList = ref([])

// 计算属性判断是否为视频预览
const isVideoPreview = computed(() => {
  return dialogImgUrl.value?.endsWith('.mp4') || dialogImgUrl.value?.endsWith('.avi')
})

// 监听创意文件URL变化
watch(
    () => props.creative.file_url,
    (newUrl) => {
      if (newUrl) {
        // 直接使用原始URL，避免添加额外前缀
        fileList.value = [{
          name: newUrl.split('/').pop(),
          url: newUrl
        }]
        if (props.creative.creative_type === 'VIDEO') {
          video_url.value = newUrl
        }
      } else {
        fileList.value = []
        video_url.value = ''
      }
    },
    {immediate: true}
)

// 类型切换处理
const handleTypeChange = () => {
  clearUploadState()
}

// 清除上传状态
const clearUploadState = () => {
  uploadRef.value?.clearFiles()
  video_url.value = ''
  temp_file.value = null
  dialogImgUrl.value = ''
}

// 文件预览处理
const onPreview = (file) => {
  dialogImgVisible.value = true
  dialogImgUrl.value = file.url
}

// 超出文件限制处理
const handleExceed = () => {
  ElMessage.warning('每次只能上传一个文件')
}

// 文件移除处理
const onRemove = () => {
  video_url.value = ''
  temp_file.value = null
}

// 文件变化处理（核心修复）
const handleFileChange = (file) => {
  if (file.status !== 'ready') return

  // 文件大小验证
  const maxSize = 10 * 1024 * 1024 // 10MB
  if (file.size > maxSize) {
    ElMessage.error('文件大小不能超过 10MB')
    return false
  }

  // 文件类型验证
  const fileExtension = file.name.split('.').pop().toLowerCase()
  const materialTypeMap = {
    bmp: 'IMAGE',
    jpg: 'IMAGE',
    png: 'IMAGE',
    mp4: 'VIDEO',
    avi: 'VIDEO'
  }

  if (!(fileExtension in materialTypeMap)) {
    ElMessage.error('不支持的文件类型，请上传 JPG、PNG、BMP、MP4 或 AVI 格式的文件')
    return false
  }

  // 生成预览URL
  const previewUrl = URL.createObjectURL(file.raw)

  // 更新文件列表（关键修复点）
  fileList.value = [{
    ...file,
    url: previewUrl
  }]

  // 更新创意类型和临时文件
  props.creative.creative_type = materialTypeMap[fileExtension]
  temp_file.value = file.raw

  // 处理视频预览
  if (props.creative.creative_type === 'VIDEO') {
    video_url.value = previewUrl
  }

  return true
}

// 暴露验证方法和临时文件
defineExpose({
  validate: () => formRef.value.validate(),
  temp_file
})
</script>

<style scoped>
.el-form-item {
  margin-bottom: 20px;
}

.upload-area {
  margin-top: 10px;
}

.upload-tip {
  font-size: 12px;
  color: #666;
  margin-top: 10px;
}

.video-preview {
  margin-top: 20px;
}

.preview-video {
  width: 100%;
  max-width: 400px;
  border-radius: 8px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
}

.el-upload__tip {
  font-size: 12px;
  color: #666;
}
</style>