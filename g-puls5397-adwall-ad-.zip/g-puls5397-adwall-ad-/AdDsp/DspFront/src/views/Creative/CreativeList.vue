<script setup>
import { ref, watch, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { useCreativeStore } from '@/store/ad/creativeStore'
import CreativeForm from './CreativeForm.vue'

const props = defineProps({
  campaignId: {
    type: Number,
    required: true
  }
})

const creativeStore = useCreativeStore()
const creatives = ref([]) // 本地存储创意数据
const dialogImgVisible = ref(false)
const dialogImgUrl = ref('')
const isCreativeFormVisible = ref(false)
const isEditMode = ref(false)
const currentCreative = ref({})
const creativeFormRef = ref(null)

// 获取创意数据
const fetchCreatives = async () => {
  try {
    await creativeStore.fetchCreatives({ campaign_id: props.campaignId })
    creatives.value = creativeStore.creatives
  } catch (error) {
    ElMessage.error('获取创意数据失败')
  }
}



// 监听campaignId变化
watch(
    () => props.campaignId,
    (newVal) => {
      if (newVal) fetchCreatives()
    },
    { immediate: true }
)

// 打开表单
const toggleCreativeForm = () => {
  isCreativeFormVisible.value = true
  isEditMode.value = false
  currentCreative.value = {
    title: '',
    description: '',
    creative_type: 'IMAGE'
  }
}

// 创建创意
const createCreative = async () => {
  try {
    const valid = await creativeFormRef.value.validate()
    if (!valid) {
      ElMessage.warning('请填写合法的数据')
      return
    }

    const formData = new FormData()
    formData.append('title', currentCreative.value.title)
    formData.append('description', currentCreative.value.description)
    formData.append('creative_type', currentCreative.value.creative_type)
    formData.append('campaign', props.campaignId)

    if (creativeFormRef.value.temp_file) {
      formData.append('file', creativeFormRef.value.temp_file)
    }

    await creativeStore.addCreative(formData)
    await fetchCreatives() // 刷新列表
    isCreativeFormVisible.value = false
  } catch (error) {
    ElMessage.error('创建创意失败')
  }
}

// 编辑创意
const editCreative = (id) => {
  const creative = creatives.value.find(item => item.id === id)
  if (creative) {
    currentCreative.value = { ...creative }
    isCreativeFormVisible.value = true
    isEditMode.value = true
  } else {
    ElMessage.error('未找到对应的创意')
  }
}

// 更新创意
const updateCreative = async () => {
  try {
    const valid = await creativeFormRef.value.validate()
    if (!valid) {
      ElMessage.warning('请填写合法的数据')
      return
    }

    const formData = new FormData()
    formData.append('title', currentCreative.value.title)
    formData.append('description', currentCreative.value.description)
    formData.append('creative_type', currentCreative.value.creative_type)
    formData.append('campaign', currentCreative.value.campaign)
    // 保留原有文件（如果没有新上传）
    if (currentCreative.value.file_url) {
      formData.append('file_url', currentCreative.value.file_url)
    }

    if (creativeFormRef.value.temp_file) {
      formData.append('file', creativeFormRef.value.temp_file)
    }
    console.log(currentCreative.value)
    await creativeStore.updateCreative(currentCreative.value.id, formData)
    await fetchCreatives() // 刷新列表
    isCreativeFormVisible.value = false
  } catch (error) {
    ElMessage.error('更新创意失败')
  }
}

// 删除创意
const deleteCreative = async (id) => {
  try {
    await ElMessageBox.confirm('确定删除此创意吗？', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    })
    await creativeStore.deleteCreative(id)
    await fetchCreatives() // 刷新列表
  } catch (error) {
    // 取消删除不处理
  }
}

// 预览处理
const handlePreview = (url) => {
  dialogImgUrl.value = `http://116.62.230.206:8888/${url}`
  dialogImgVisible.value = true
}

// 下载处理
const handleDownload = async (url) => {
  const fullUrl = `/aps/${url}`
  try {
    const response = await fetch(fullUrl)
    if (!response.ok) throw new Error('网络响应错误')

    const blob = await response.blob()
    const downloadUrl = window.URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = downloadUrl
    link.download = url.split('/').pop()
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    window.URL.revokeObjectURL(downloadUrl)
  } catch (error) {
    ElMessage.error('下载失败')
  }
}
</script>

<template>
  <div class="creative-list">
    <div class="action-bar">
      <el-button type="primary" @click="toggleCreativeForm">添加创意</el-button>
    </div>

    <div v-if="creatives.length === 0" class="no-data">
      <el-empty description="暂无创意数据" />
    </div>

    <el-table v-else :data="creatives" style="width: 100%">
      <el-table-column prop="title" label="标题" />
      <el-table-column prop="creative_type" label="类型">
        <template #default="{ row }">
          <el-tag :type="row.creative_type === 'IMAGE' ? 'success' : 'info'">
            {{ row.creative_type === 'IMAGE' ? '图片' : '视频' }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column label="物料" width="150">
        <template #default="{ row }">
          <div v-if="row.file_url">
            <el-button type="text" @click="handlePreview(row.file_url)">预览</el-button>
            <el-button type="text" @click="handleDownload(row.file_url)">下载</el-button>
          </div>
          <span v-else>无物料</span>
        </template>
      </el-table-column>
      <el-table-column prop="description" label="描述" />
      <el-table-column label="操作" width="180">
        <template #default="{ row }">
          <el-button type="primary" size="small" @click="editCreative(row.id)">编辑</el-button>
          <el-button type="danger" size="small" @click="deleteCreative(row.id)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <!-- 表单弹窗 -->
    <el-dialog
        v-model="isCreativeFormVisible"
        :title="isEditMode ? '编辑创意' : '添加创意'"
        width="600px"
    >
      <CreativeForm :creative="currentCreative" ref="creativeFormRef" />
      <template #footer>
        <el-button @click="isCreativeFormVisible = false">取消</el-button>
        <el-button type="primary" @click="isEditMode ? updateCreative() : createCreative()">
          {{ isEditMode ? '更新' : '添加' }}
        </el-button>
      </template>
    </el-dialog>

    <!-- 预览弹窗 -->
    <el-dialog v-model="dialogImgVisible" title="预览">
      <video
          v-if="dialogImgUrl.endsWith('.mp4') || dialogImgUrl.endsWith('.avi')"
          :src="dialogImgUrl"
          controls
          class="preview-media"
      />
      <img v-else :src="dialogImgUrl" alt="预览图片" class="preview-media" />
    </el-dialog>
  </div>
</template>

<style scoped lang="less">
.creative-list {
  margin-top: 16px;
  background: #fff;
  padding: 16px;
  border-radius: 8px;
}

.action-bar {
  margin-bottom: 16px;
}

.no-data {
  padding: 40px 0;
  background: #f8f9fa;
  border-radius: 4px;
}

.preview-media {
  max-width: 100%;
  max-height: 70vh;
  display: block;
  margin: 0 auto;
}

.el-table {
  margin-top: 12px;

  :deep(.el-table__cell) {
    padding: 12px 0;
  }
}

.el-tag {
  margin: 2px;
}
</style>