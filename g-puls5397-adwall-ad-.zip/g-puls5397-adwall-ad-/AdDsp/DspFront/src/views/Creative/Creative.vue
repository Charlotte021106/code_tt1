<script setup>
import { onMounted } from 'vue'
import { useCreativeStore } from '@/store/ad/creativeStore'
import CampaignList from './CampaignList.vue'

const creativeStore = useCreativeStore()

// 只获取广告活动数据
onMounted(async () => {
  await creativeStore.fetchCampaigns()
})
</script>

<template>
  <div class="creative-container">
    <!-- 广告活动列表（会自动加载对应创意） -->
    <CampaignList />
  </div>
</template>

<style scoped lang="less">
.creative-container {
  padding: 20px;
  background: #f5f7fa;
  min-height: 100vh;
}
</style>