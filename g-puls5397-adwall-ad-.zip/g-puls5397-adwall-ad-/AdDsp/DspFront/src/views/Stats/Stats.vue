<script setup>
import {ref, onMounted} from 'vue';
import {ElMessage} from 'element-plus';
import * as echarts from 'echarts';
import {GetAdStatsSummary, GetAdPlacements} from '@/api/index.js';


// 数据状态（根据接口返回结构定义）
const statsData = ref({
  placement: '',
  impressions: 0,
  clicks: 0,
  conversions: 0,
  cost: 0,
  ctr: 0,
  details: [] // 明细数据字段
});

const lineChart = ref(null);
const pieChart = ref(null);
const placementOptions = ref([]);
const selectedPlacement = ref('');
const dateRange = ref([]);

// 初始化图表
const initCharts = () => {
  const lineInstance = echarts.init(lineChart.value);
  const pieInstance = echarts.init(pieChart.value);

  // 折线图配置
  lineInstance.setOption({
    title: {text: '效果趋势分析', left: 'center'},
    tooltip: {trigger: 'axis'},
    legend: {
      data: ['曝光量', '点击量', '转化量', '花费'],
      bottom: 0
    },
    xAxis: {type: 'category', data: []},
    yAxis: [{type: 'value', name: '次数'}, {type: 'value', name: '金额'}],
    series: [
      {name: '曝光量', type: 'line', smooth: true},
      {name: '点击量', type: 'line', smooth: true},
      {name: '转化量', type: 'line', smooth: true},
      {name: '花费', type: 'line', yAxisIndex: 1, smooth: true}
    ]
  });

  // 饼图配置（显示费用构成）
  pieInstance.setOption({
    title: {text: '费用构成', left: 'center'},
    tooltip: {trigger: 'item', formatter: '{b} : ¥{c} ({d}%)'},
    legend: {orient: 'vertical', left: 'left'},
    series: [{
      type: 'pie',
      radius: '50%',
      data: [],
      emphasis: {itemStyle: {shadowBlur: 10}}
    }]
  });
};

// 获取投放列表
const loadPlacements = async () => {
  try {
    const res = await GetAdPlacements();
    placementOptions.value = res.map(item => ({
      value: item.id,
      label: `${item.campaign_name} - ${item.creative_title}`
    }));
  } catch (error) {
    ElMessage.error('获取广告投放列表失败');
  }
};

// 获取统计数据
const fetchStats = async () => {
  if (!selectedPlacement.value) {
    ElMessage.warning('请先选择广告投放');
    return;
  }

  try {
    const params = {
      placement: selectedPlacement.value,
      start_date: dateRange.value?.[0],
      end_date: dateRange.value?.[1]
    };

    const data = await GetAdStatsSummary(params);
    statsData.value = data;
    console.log(data)
    // 生成图表数据
    updateCharts(
        generateTrendData(data.details),
        generateCostData(data.details)
    );
  } catch (error) {
    ElMessage.error(error.response?.data?.error || '获取数据失败');
  }
};

// 生成趋势数据（使用details数据）
const generateTrendData = (details) => ({
  dates: details.map(d => d.date),
  impressions: details.map(d => d.impressions),
  clicks: details.map(d => d.clicks),
  conversions: details.map(d => d.conversions),
  costs: details.map(d => d.cost)
});

// 生成费用数据（根据明细中的每日花费）
const generateCostData = (details) => {
  const totalCost = details.reduce((sum, d) => sum + d.cost, 0);
  return [{
    name: '总花费',
    value: totalCost.toFixed(2)
  }];
};

// 更新图表
const updateCharts = (trendData, costData) => {
  const lineInstance = echarts.getInstanceByDom(lineChart.value);
  const pieInstance = echarts.getInstanceByDom(pieChart.value);

  // 折线图更新
  lineInstance.setOption({
    xAxis: {data: trendData.dates},
    series: [
      {data: trendData.impressions},
      {data: trendData.clicks},
      {data: trendData.conversions},
      {data: trendData.costs}
    ]
  });

  // 饼图更新
  pieInstance.setOption({
    series: [{
      data: costData
    }]
  });
};

// 日期快捷选项
const shortcuts = [
  {
    text: '最近7天',
    value: () => {
      const end = new Date();
      const start = new Date();
      start.setDate(start.getDate() - 6);
      return [start, end];
    }
  },
  {
    text: '最近30天',
    value: () => {
      const end = new Date();
      const start = new Date();
      start.setDate(start.getDate() - 29);
      return [start, end];
    }
  }
];

onMounted(() => {
  initCharts();
  loadPlacements();
});
</script>

<template>
  <div class="dashboard-container">
    <!-- 筛选工具栏 -->
    <div class="filter-bar">
      <el-select
          v-model="selectedPlacement"
          placeholder="选择广告投放"
          clearable
          filterable
          style="width: 300px"
      >
        <el-option
            v-for="item in placementOptions"
            :key="item.value"
            :label="item.label"
            :value="item.value"
        />
      </el-select>

      <el-date-picker
          v-model="dateRange"
          type="daterange"
          range-separator="至"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
          :shortcuts="shortcuts"
          value-format="YYYY-MM-DD"
      />

      <el-button type="primary" @click="fetchStats">查询</el-button>
      <el-button @click="() => { dateRange = []; selectedPlacement = '' }">重置</el-button>
    </div>

    <!-- 数据概览卡片 -->
    <div class="metric-cards">
      <el-card shadow="hover">
        <template #header>
          <span>总曝光量</span>
          <el-tag type="info">{{ statsData.impressions.toLocaleString() }}</el-tag>
        </template>
        <div class="metric-value">
          <span class="compare">日均 </span>
          {{ (statsData.impressions / statsData.details.length || 0).toLocaleString() }}
        </div>
      </el-card>

      <el-card shadow="hover">
        <template #header>
          <span>点击率 (CTR)</span>
          <el-tag type="success">{{ (statsData.ctr * 100).toFixed(2) }}%</el-tag>
        </template>
        <div class="metric-value">
          <span class="compare">总点击 </span>
          {{ statsData.clicks.toLocaleString() }}
        </div>
      </el-card>

      <el-card shadow="hover">
        <template #header>
          <span>总花费</span>
          <el-tag type="danger">¥ {{ statsData.cost.toFixed(2) }}</el-tag>
        </template>
        <div class="metric-value">
          <span class="compare">日均 </span>
          ¥ {{ (statsData.cost / statsData.details.length || 0).toFixed(2) }}
        </div>
      </el-card>
    </div>

    <!-- 可视化图表 -->
    <div class="chart-area">
      <div ref="lineChart" class="chart-item" style="height:400px"></div>
      <div ref="pieChart" class="chart-item" style="height:400px"></div>
    </div>

    <!-- 数据表格 -->
    <el-table
        :data="statsData.details"
        stripe
        style="width: 100%"
        v-loading="!statsData.details.length"
        empty-text="暂无详细数据"
    >
      <el-table-column prop="date" label="日期" width="120" sortable/>
      <el-table-column label="曝光量" sortable>
        <template #default="{row}">{{ row.impressions.toLocaleString() }}</template>
      </el-table-column>
      <el-table-column label="点击量" sortable>
        <template #default="{row}">{{ row.clicks.toLocaleString() }}</template>
      </el-table-column>
      <el-table-column label="转化量" sortable>
        <template #default="{row}">{{ row.conversions.toLocaleString() }}</template>
      </el-table-column>
      <el-table-column label="花费" sortable>
        <template #default="{row}">¥ {{ row.cost.toFixed(2) }}</template>
      </el-table-column>
      <el-table-column label="CTR" sortable>
        <template #default="{row}">
          {{ ((row.clicks / row.impressions) * 100 || 0).toFixed(2) }}%
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<style scoped lang="less">
.dashboard-container {
  padding: 20px;
  background: #f5f7fa;
  min-height: 100vh;
}

.filter-bar {
  display: flex;
  gap: 15px;
  margin-bottom: 20px;
  align-items: center;
  flex-wrap: wrap;

  > * {
    margin: 5px 0;
  }
}

.metric-cards {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 20px;
  margin-bottom: 20px;

  .el-card {
    transition: transform 0.3s;

    &:hover {
      transform: translateY(-5px);
    }
  }

  .metric-value {
    font-size: 24px;
    font-weight: bold;
    color: #2c3e50;
    text-align: center;
    padding: 15px 0;

    .compare {
      display: block;
      font-size: 12px;
      color: #7f8c8d;
      margin-bottom: 5px;
    }
  }

  .el-card__header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: rgba(236, 240, 241, 0.5);
  }
}

.chart-area {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(600px, 1fr));
  gap: 20px;
  margin-bottom: 20px;
  background: white;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
}

@media (max-width: 768px) {
  .filter-bar {
    flex-direction: column;

    .el-select, .el-date-editor {
      width: 100%;
    }
  }

  .chart-area {
    grid-template-columns: 1fr;
    padding: 10px;
  }
}
</style>