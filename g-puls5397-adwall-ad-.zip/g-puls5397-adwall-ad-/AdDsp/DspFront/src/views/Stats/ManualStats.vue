<script setup>
import { ref, onMounted } from 'vue';
import { ElMessage } from 'element-plus';
import { GetAdPlacements, CreateManualStat } from '@/api/index.js';

const formRef = ref(null);
// 表单数据
const form = ref({
  placement: null,
  impressions: null,
  clicks: null,
  conversions: null
});

// 投放选项
const placementOptions = ref([]);

// 表单验证规则
const rules = ref({
  placement: [{ required: true, message: '必须选择广告投放', trigger: 'blur' }],
  impressions: [
    { required: true, message: '必须填写展示量', trigger: 'blur' },
    { type: 'number', min: 1, message: '至少1次展示', trigger: 'blur' }
  ],
  clicks: [
    { required: true, message: '必须填写点击量', trigger: 'blur' },
    {
      validator: (rule, value, callback) => {
        if (value > form.value.impressions) {
          callback(new Error(`点击量不能超过展示量（当前展示量：${form.value.impressions}）`));
        } else {
          callback();
        }
      },
      trigger: ['blur', 'change']
    }
  ],
  conversions: [
    { required: true, message: '必须填写转化量', trigger: 'blur' },
    {
      validator: (rule, value, callback) => {
        if (value > form.value.clicks) {
          callback(new Error(`转化量不能超过点击量（当前点击量：${form.value.clicks}）`));
        } else {
          callback();
        }
      },
      trigger: ['blur', 'change']
    }
  ]
});

// 加载投放列表
const loadPlacements = async () => {
  try {
    const res = await GetAdPlacements();
    placementOptions.value = res.map(p => ({
      value: p.id,
      label: `${p.creative_title} (${p.campaign_name})`
    }));
  } catch (error) {
    ElMessage.error('加载广告投放列表失败');
  }
};

// 提交表单
const submitForm = async (formEl) => {
  if (!formEl) return;

  await formEl.validate(async (valid) => {
    if (valid) {
      try {
        await CreateManualStat({
          placement: form.value.placement,
          impressions: form.value.impressions,
          clicks: form.value.clicks,
          conversions: form.value.conversions
        });

        ElMessage.success('统计创建成功');
        formEl.resetFields();
      } catch (error) {
        if (error.response?.data) {
          // 处理字段级错误
          for (const [field, messages] of Object.entries(error.response.data)) {
            ElMessage.error(`${field}: ${messages.join('; ')}`);
          }
        } else {
          ElMessage.error('提交失败，请检查网络');
        }
      }
    }
  });
};

// 初始化加载投放数据
onMounted(loadPlacements);
</script>

<template>
  <div class="manual-stats-container">
    <el-card class="form-card">
      <template #header>
        <div class="card-header">
          <h2>手动创建广告统计</h2>
          <span class="tip">注：相同投放+日期的数据会自动合并</span>
        </div>
      </template>

      <el-form
          ref="formRef"
          :model="form"
          :rules="rules"
          label-width="120px"
          label-position="right"
      >
        <el-form-item label="广告投放" prop="placement">
          <el-select
              v-model="form.placement"
              placeholder="请选择广告投放"
              filterable
              clearable
          >
            <el-option
                v-for="item in placementOptions"
                :key="item.value"
                :label="item.label"
                :value="item.value"
            />
          </el-select>
        </el-form-item>

        <el-form-item label="展示量" prop="impressions">
          <el-input-number
              v-model="form.impressions"
              :min="1"
              :max="2147483647"
              controls-position="right"
              placeholder="输入展示次数"
              style="width: 100%"
          />
        </el-form-item>

        <el-form-item label="点击量" prop="clicks">
          <el-input-number
              v-model="form.clicks"
              :min="0"
              :max="form.impressions || 0"
              controls-position="right"
              placeholder="输入点击次数"
              style="width: 100%"
          />
        </el-form-item>

        <el-form-item label="转化量" prop="conversions">
          <el-input-number
              v-model="form.conversions"
              :min="0"
              :max="form.clicks || 0"
              controls-position="right"
              placeholder="输入转化次数"
              style="width: 100%"
          />
        </el-form-item>

        <el-form-item>
          <el-button
              type="primary"
              @click="submitForm(formRef)"
              style="width: 200px"
          >
            立即创建
          </el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<style scoped lang="scss">
.manual-stats-container {
  max-width: 800px;
  margin: 20px auto;
  padding: 20px;

  .form-card {
    :deep(.el-card__header) {
      background: #f5f7fa;
      border-bottom: 1px solid #ebeef5;
    }

    .card-header {
      display: flex;
      justify-content: space-between;
      align-items: center;

      h2 {
        margin: 0;
        color: #303133;
      }

      .tip {
        font-size: 12px;
        color: #909399;
      }
    }

    .el-form-item {
      margin-bottom: 24px;

      :deep(.el-input-number) {
        width: 100%;

        .el-input__inner {
          text-align: left;
        }
      }
    }
  }
}

@media (max-width: 768px) {
  .manual-stats-container {
    padding: 10px;

    .form-card {
      :deep(.el-card__header) {
        padding: 12px;
      }

      .card-header {
        flex-direction: column;
        align-items: flex-start;

        h2 {
          margin-bottom: 8px;
        }
      }
    }
  }
}
</style>