<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import * as echarts from 'echarts'
import {DownloadInvoice, GetBillingList} from '@/api/index.js'

// 初始化响应式数据
const billingData = ref({
  billings: [],      // 账单列表（支持多账单）
  currentBill: null, // 当前展示的账单
  dailySpending: []  // 合并后的消费数据
})

const lineChart = ref(null)
const pieChart = ref(null)
const dateRange = ref([])
const loading = ref(false)

// 初始化图表
const initCharts = () => {
  const lineInstance = echarts.init(lineChart.value)
  const pieInstance = echarts.init(pieChart.value)

  // 消费趋势图配置
  lineInstance.setOption({
    title: { text: '消费趋势', left: 'center' },
    tooltip: { trigger: 'axis' },
    xAxis: { type: 'category' },
    yAxis: { type: 'value', name: '金额（元）' },
    series: [{
      name: '每日消耗',
      type: 'line',
      smooth: true,
      areaStyle: { color: '#1890ff20' },
      lineStyle: { color: '#1890ff' }
    }]
  })

  // 预算构成图配置
  pieInstance.setOption({
    title: { text: '预算构成', left: 'center' },
    tooltip: {
      trigger: 'item',
      formatter: ({ data }) => `${data.name}: ¥${data.value.toFixed(2)} (${data.percent}%)`
    },
    series: [{
      type: 'pie',
      radius: ['35%', '60%'],
      data: [],
      itemStyle: {
        borderRadius: 6,
        borderWidth: 2
      }
    }]
  })
}

const fetchBillings = async () => {
  try {
    loading.value = true;
    const data = await GetBillingList({
      start_date: dateRange.value?.[0],
      end_date: dateRange.value?.[1]
    });

    const processBillData = (bill = {}) => ({
      ...bill,
      daily_spending: bill.daily_spending || [],
      total_budget: parseFloat(bill.total_budget) || 0,
      spent_amount: parseFloat(bill.spent_amount) || 0,
      remaining_budget: parseFloat(bill.remaining_budget) || 0,
      utilization_rate: parseFloat(bill.utilization_rate) || 0
    });

    // 2. 确保处理数据前已定义
    const rawBills = data ? (Array.isArray(data) ? data : [data]) : [];
    const bills = rawBills.map(processBillData);

    // 3. 聚合多账单数据
    const aggregateData = bills.reduce(
        (acc, bill) => ({
          total_budget: acc.total_budget + bill.total_budget,
          spent_amount: acc.spent_amount + bill.spent_amount,
          remaining_budget: acc.remaining_budget + bill.remaining_budget,
          daily_spending: [...acc.daily_spending, ...bill.daily_spending]
        }),
        {
          total_budget: 0,
          spent_amount: 0,
          remaining_budget: 0,
          daily_spending: []
        }
    );

    // 4. 更新响应式数据
    billingData.value = {
      billings: bills,
      currentBill: {
        ...aggregateData,
        utilization_rate: (aggregateData.spent_amount / aggregateData.total_budget) * 100 || 0
      },
      dailySpending: aggregateData.daily_spending
    };

    updateCharts();
  } catch (error) {
    ElMessage.error(error.response?.data?.message || '数据加载失败');
  } finally {
    loading.value = false;
  }
};
const generateChartData = () => {
  if (!billingData.value.currentBill) return {};

  // 按日期合并消费金额
  const dailyCostMap = billingData.value.dailySpending.reduce((map, d) => {
    const cost = parseFloat(d.total_cost) || 0;
    map[d.date] = (map[d.date] || 0) + cost;
    return map;
  }, {});

  // 转换为趋势图数据并按日期排序
  const trendData = Object.entries(dailyCostMap)
      .map(([date, cost]) => ({ date, cost }))
      .sort((a, b) => a.date.localeCompare(b.date));

  // 计算预算构成
  const total = billingData.value.currentBill.total_budget;
  const spent = billingData.value.currentBill.spent_amount;
  const remaining = total - spent;

  return {
    trendData,
    pieData: [
      {
        name: '已消耗',
        value: spent,
        percent: ((spent / total) * 100).toFixed(1)
      },
      {
        name: '剩余预算',
        value: remaining,
        percent: ((remaining / total) * 100).toFixed(1)
      }
    ]
  };
};

// 更新图表
const updateCharts = () => {
  const { trendData, pieData } = generateChartData()
  const lineInstance = echarts.getInstanceByDom(lineChart.value)
  const pieInstance = echarts.getInstanceByDom(pieChart.value)

  // 更新折线图
  lineInstance.setOption({
    xAxis: { data: trendData.map(d => d.date) },
    series: [{
      data: trendData.map(d => d.cost),
      markPoint: {
        data: [
          { type: 'max', name: '峰值' },
          { type: 'min', name: '谷值' }
        ]
      }
    }]
  })

  // 更新饼图
  pieInstance.setOption({
    series: [{
      data: pieData,
      color: ['#ff4d4f', '#13c2c2']
    }]
  })
}

const handleDownload = async (id) => {
  try {
    const  data  = await DownloadInvoice(id)
    if (data.download_link) {
      const link = document.createElement('a')
      link.href = data.download_link
      link.target = '_blank'
      link.rel = 'noopener noreferrer'
      link.click()
    }
  } catch (error) {
    ElMessage.error(error.response?.data?.message || '下载失败')
  }
}
// 数值格式化
const formatCurrency = (value) => {
  const num = parseFloat(value) || 0
  return num.toLocaleString('zh-CN', {
    style: 'currency',
    currency: 'CNY',
    minimumFractionDigits: 2
  })
}

onMounted(() => {
  initCharts()
  fetchBillings()
})
</script>

<template>
  <div class="dashboard-container">
    <!-- 筛选栏 -->
    <div class="filter-bar">
      <el-date-picker
          v-model="dateRange"
          type="daterange"
          unlink-panels
          range-separator="至"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
          value-format="YYYY-MM-DD"
      />
      <el-button
          type="primary"
          @click="fetchBillings"
          :loading="loading"
      >
        查询
      </el-button>
    </div>

    <!-- 数据概览 -->
    <div class="metric-cards" v-if="billingData.currentBill">
      <el-card shadow="hover">
        <template #header>
          <span class="card-title">总预算（全部账单）</span>
          <el-tag type="info" effect="dark">
            {{ formatCurrency(billingData.currentBill.total_budget) }}
          </el-tag>
        </template>
        <div class="metric-detail">
          <span class="subtext">总使用率</span>
          <span class="highlight">
        {{ billingData.currentBill.utilization_rate.toFixed(1) }}%
      </span>
        </div>
      </el-card>

      <el-card shadow="hover">
        <template #header>
          <span class="card-title">总消耗（全部账单）</span>
          <el-tag type="danger" effect="dark">
            {{ formatCurrency(billingData.currentBill.spent_amount) }}
          </el-tag>
        </template>
        <div class="metric-detail">
          <span class="subtext">总剩余预算</span>
          <span class="highlight">
        {{ formatCurrency(billingData.currentBill.remaining_budget) }}
      </span>
        </div>
      </el-card>
    </div>


    <!-- 可视化图表 -->
    <div class="chart-area">
      <div ref="lineChart" class="chart-item" style="height:400px"></div>
      <div ref="pieChart" class="chart-item" style="height:400px"></div>
    </div>

    <!-- 账单表格 -->
    <el-table
        :data="billingData.billings"
        v-loading="loading"
        empty-text="暂无账单数据"
    >
      <el-table-column prop="invoice_number" label="发票编号" width="200">
        <template #default="{row}">
          <el-tooltip :content="row.invoice_number">
            <span class="text-ellipsis">{{ row.invoice_number }}</span>
          </el-tooltip>
        </template>
      </el-table-column>

      <el-table-column label="关联活动" prop="campaign" width="120" />

      <el-table-column label="总预算" width="150">
        <template #default="{row}">
          {{ formatCurrency(row.total_budget) }}
        </template>
      </el-table-column>

      <el-table-column label="已消耗" width="150">
        <template #default="{row}">
          <span class="danger-text">
            {{ formatCurrency(row.spent_amount) }}
          </span>
        </template>
      </el-table-column>

      <el-table-column label="使用率" width="120">
        <template #default="{row}">
          <el-tag
              :type="row.utilization_rate >= row.alert_threshold ? 'danger' : 'success'"
              effect="dark"
          >
            {{ parseFloat(row.utilization_rate).toFixed(1) }}%
          </el-tag>
        </template>
      </el-table-column>

      <el-table-column label="操作" width="120">
        <template #default="{row}">
          <el-button
              link
              type="primary"
              @click="handleDownload(row.id)"
          >
            下载
          </el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<style scoped lang="less">
.dashboard-container {
  padding: 20px;
  background: #f5f7fa;
  min-height: 100vh;

  .filter-bar {
    display: flex;
    gap: 12px;
    margin-bottom: 20px;
    flex-wrap: wrap;

    .el-date-editor {
      width: 280px;
    }
  }

  .metric-cards {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 16px;
    margin-bottom: 20px;

    .el-card {
      transition: transform 0.3s;

      &:hover {
        transform: translateY(-3px);
      }

      &__header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 12px 20px;
      }

      .card-title {
        font-weight: 500;
      }

      .metric-detail {
        padding: 8px 0;
        text-align: center;

        .subtext {
          display: block;
          font-size: 12px;
          color: #666;
          margin-bottom: 4px;
        }

        .highlight {
          font-size: 18px;
          font-weight: 600;
          color: #2c3e50;
        }
      }
    }
  }

  .chart-area {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 20px;
    margin-bottom: 20px;
    background: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);

    @media (max-width: 768px) {
      grid-template-columns: 1fr;
      padding: 10px;
    }
  }

  .el-table {
    margin-top: 20px;
    background: white;
    border-radius: 8px;
    box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);

    .text-ellipsis {
      display: inline-block;
      max-width: 160px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      vertical-align: bottom;
    }

    .danger-text {
      color: #ff4d4f;
      font-weight: 500;
    }
  }
}
</style>