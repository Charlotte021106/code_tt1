<script setup>
import {ref, reactive, onMounted} from "vue";
import { Lock, User } from "@element-plus/icons-vue";
import { ElMessage } from "element-plus";
import { login } from "@/api/index.js";
import useUserInfoStore from '@/store/user.js'
import { useRouter } from "vue-router";
import { v4 as uuidv4 } from 'uuid';
import {aesCipher, desCipher} from '@/utils/crypto.js';
import SvgIcon from "@/components/iconfont/SvgIcon.vue";
const router = useRouter();
const store = useUserInfoStore();
const loginFormRef = ref();
const loginForm = reactive({
  username: "",
  password: "",
  code: "",
  uuid: "",
})
const captchaUrl = ref(""); // 验证码图片URL
// 生成UUID并获取验证码图片
const generateCaptcha = () => {
  const uuid = uuidv4(); // 生成UUID
  loginForm.uuid = uuid; // 将UUID存储到表单中
  captchaUrl.value = `http://127.0.0.1:8888/user/logcode/${uuid}/`; // 生成验证码图片URL
};

//对数据进行校验
const loginFormRules = reactive({
  username: [
    {
      required: true,
      message: "请输入用户名",
      trigger: "blur",//当用户在对应的输入框中输入完成并且焦点离开输入框时，相关的验证规则会生效，检查输入的合法性，并在必要时显示相应的错误消息
    },
  ],
  password: [
    {
      required: true,
      message: "请输入密码",
      trigger: "blur",
    },
    {
      min: 6,
      message: "密码长度不能少于6位",
      trigger: "blur",
    },
  ],
  code: [
    {
      required: true,
      message: "请输入验证码",
      trigger: "blur",
    },
    {
      len:4,
      message: "验证码长度为4位",
    }
  ],
});
const submitForm = async (rulFormRef) => {
  if (!rulFormRef) return;
  await rulFormRef.validate(async (valid) => {
    if (valid) {
      await submitUserLogin();
    }
  })
}

const submitUserLogin = async () => {
  try {
    // 对密码进行 AES 加密
    const encryptedPassword = desCipher.desEncrypt(loginForm.password);
    const formData = {
      ...loginForm,
      password: encryptedPassword, // 使用加密后的密码
    };

    const res = await login(formData)
    if (res.status === 200) {
      // 通过pinia存储后端返回的用户数据以及token (存储token到localStorage)
      store.SetUserInfo(res.data)
      // 跳转页面到首页
      await router.push("/home")
      ElMessage.success('登录成功')
    } else if(res.status === 400){
      ElMessage.warning(res.msg)
      generateCaptcha(); // 刷新验证码
    }else if (res.status === 404) {
      ElMessage.warning(res.msg);
      generateCaptcha(); // 刷新验证码
    } else {
      ElMessage.error('登录失败，请稍后重试');
      generateCaptcha(); // 刷新验证码
    }
  } catch (error) {
    ElMessage.error('网络错误，请稍后尝试登录！');
    generateCaptcha(); // 刷新验证码
  }
}
// 页面加载时生成验证码
onMounted(() => {
  generateCaptcha();
});
</script>

<template>
  <div class="login-container">
    <div class="title">AdDsp</div>
    <div class="form-container">
      <h2 class="welcome-text">欢迎登录</h2>
      <el-form ref="loginFormRef" :model="loginForm" status-icon :rules="loginFormRules" label-width="auto"
        class="demo-loginForm">
        <!-- 用户名 -->
        <el-form-item prop="username" class="form-item">
          <el-icon color="#409efc" :size="24">
            <User />
          </el-icon>
          <el-input type="text" v-model="loginForm.username" placeholder="请输入用户名" />
        </el-form-item>

        <!-- 密码 -->
        <el-form-item prop="password" class="form-item">
          <el-icon color="#409efc" :size="24">
            <Lock />
          </el-icon>
          <el-input type="password" v-model="loginForm.password" placeholder="请输入密码" />
        </el-form-item>
        <!-- 验证码 -->
        <el-form-item prop="code" class="form-item">
          <el-icon  color="#409efc" :size="24">
            <SvgIcon iconName="icon-tupianyanzhengma1"/>
          </el-icon>
          <el-input v-model="loginForm.code" placeholder="请输入验证码" style="width: 60%;" />
          <img :src="captchaUrl" alt="验证码" @click="generateCaptcha" style="cursor: pointer; margin-left: 10px; height: 40px;" />
        </el-form-item>
        <!-- 注册链接 -->
        <p class="register-link-box">
          <router-link to="/register" class="register-link">没有账号？点击注册</router-link>
        </p>

        <!-- 登录按钮 -->
        <el-form-item id="button" class="form-item">
          <el-button type="primary" @click="submitForm(loginFormRef)">登录</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>


<style lang="less" scoped>
.login-container {
  background-image: url("@/assets/img/background.png");
  background-size: cover;
  background-attachment: fixed; /* 背景图固定，不随页面滚动 */
  height: 100%;
}

.title {
  font-size: 35px;
  font-weight: bold;
  color: #ffffff;
  text-align: center;
}

.form-container {
  margin: auto;
  background: linear-gradient(135deg, #fff3e6, #f5f8fa);
  padding: 40px;
  border-radius: 8px;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15); /* 更柔和的阴影 */
  width: 100%;
  max-width: 400px; /* 最大宽度 */
  transition: box-shadow 0.3s ease-in-out; /* 添加动态阴影效果 */
}

.form-container:hover {
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2); /* 鼠标悬停时阴影效果增强 */
}

.welcome-text {
  text-align: center;
  font-size: 1.5rem;
  margin-bottom: 30px;
  color: #333333;
}

.demo-loginForm {
  .form-item {
    display: flex;
    align-items: center;
    margin-bottom: 20px;

    .el-icon {
      margin-right: 10px; // 图标与输入框之间的间距
    }

    .el-input {
      flex: 1; // 输入框占据剩余空间
    }
  }

  .el-input__inner {
    padding: 12px;
    font-size: 14px;
    border-radius: 4px;
    border: 1px solid #e0e0e0;
    transition: all 0.3s ease-in-out; /* 输入框过渡效果 */
  }

  .el-input__inner:focus {
    border-color: #409efc;
    box-shadow: 0 0 8px rgba(64, 158, 252, 0.3); /* 输入框聚焦时的光辉效果 */
    transform: scale(1.02); /* 聚焦时轻微放大 */
  }

  .el-icon {
    margin-right: 10px;
  }

  .register-link-box {
    text-align: center;
    margin-top: 10px;

    .register-link {
      color: #409efc;
      font-size: 14px;
      text-decoration: none;
      transition: color 0.3s ease; /* 过渡效果 */
    }

    .register-link:hover {
      text-decoration: underline;
      color: #2980b9; /* 鼠标悬停时颜色变更 */
    }
  }

  #button {
    text-align: center;
    .el-button {
      width: 100%;
      padding: 12px;
      font-size: 16px;
      border-radius: 4px;
      background: linear-gradient(45deg, #409efc, #1e74d8); /* 渐变背景 */
      border: none;
      transition: all 0.3s ease; /* 按钮过渡效果 */
    }

    .el-button:hover {
      background: linear-gradient(45deg, #1e74d8, #409efc);
      transform: scale(1.05); /* 鼠标悬停时按钮放大 */
      box-shadow: 0 4px 12px rgba(64, 158, 252, 0.3); /* 按钮悬停时阴影效果 */
    }
  }
}
</style>