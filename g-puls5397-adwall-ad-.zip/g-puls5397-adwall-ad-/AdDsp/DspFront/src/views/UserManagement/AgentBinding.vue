<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { DeleteBindAgent, GetAgents, GetBoundAgents, PostBindAgent } from "@/api/index.js"
import useUserInfoStore from "@/store/user.js"
import { formatDateTime } from '@/utils/formatTime.js' // 引入时间格式化函数
const userStore = useUserInfoStore()

const allAgents = ref([]) // 所有代理列表
const boundAgents = ref([]) // 已绑定代理列表

// 获取所有代理列表
const fetchAllAgents = async () => {
  try {
    const res = await GetAgents()
    allAgents.value = res.results
  } catch (error) {
    ElMessage.error('获取代理列表失败')
  }
}

// 获取已绑定代理列表
const fetchBoundAgents = async () => {
  try {
    const res = await GetBoundAgents()
    boundAgents.value = res.results
  } catch (error) {
    ElMessage.error('获取绑定列表失败')
  }
}

// 绑定代理
const handleBind = async (agentId) => {
  try {
    await PostBindAgent({ agent: agentId })
    ElMessage.success('代理绑定成功')
    await fetchBoundAgents() // 重新获取已绑定列表
  } catch (error) {
    ElMessage.error(error.response?.data?.agent?.[0] || '绑定失败，请检查网络连接')
  }
}

// 解绑代理
const handleUnbind = async (agentId) => {
  try {
    const agent = boundAgents.value.find(item => item.agent.id === agentId)
    if (!agent) {
      ElMessage.error('未找到代理')
      return
    }

    await ElMessageBox.confirm(
        `确定要解除与代理 ${agent.agent.name} 的绑定吗？`,
        '解除绑定确认',
        {
          confirmButtonText: '确认解绑',
          cancelButtonText: '取消',
          type: 'warning'
        }
    )

    await DeleteBindAgent(agentId)
    ElMessage.success(`成功解除与代理 ${agent.agent.name} 的绑定`)
    await fetchBoundAgents() // 重新获取已绑定列表
  } catch (error) {
    ElMessage.error('解绑失败')
  }
}

// 判断代理是否已绑定
const isAgentBound = (agentId) => {
  return boundAgents.value.some(item => item.agent.id === agentId)
}

// 获取绑定日期
const getBindingDate = (agentId) => {
  const boundAgent = boundAgents.value.find(item => item.agent.id === agentId)
  return boundAgent ? boundAgent.binding_date : null
}

onMounted(() => {
  fetchAllAgents()
  fetchBoundAgents()
})
</script>

<template>
  <div class="agent-binding">
    <h3>寻找代理</h3>

    <!-- 代理列表 -->
    <div class="agent-list">
      <el-table :data="allAgents" style="width: 100%">
        <el-table-column prop="username" label="用户名"/>
        <el-table-column prop="email" label="邮箱"/>
        <el-table-column prop="date_joined" label="加入时间">
          <template #default="{ row }">
            <span>{{ formatDateTime(row.date_joined) }}</span>
          </template>
        </el-table-column>
        <el-table-column label="状态" width="150">
          <template #default="{ row }">
            <el-tag v-if="isAgentBound(row.id)" type="success">已绑定</el-tag>
            <el-tag v-else type="info">未绑定</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="绑定日期" width="180">
          <template #default="{ row }">
            <span v-if="isAgentBound(row.id)">{{ formatDateTime(getBindingDate(row.id)) }}</span>
            <span v-else>-</span>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="200">
          <template #default="{ row }">
            <el-button
                v-if="!isAgentBound(row.id)"
                type="primary"
                size="small"
                @click="handleBind(row.id)"
            >
              绑定
            </el-button>
            <el-button
                v-if="isAgentBound(row.id) && userStore.userInfo.user_type === 'ADVERTISER'"
                type="danger"
                size="small"
                @click="handleUnbind(row.id)"
            >
              解绑
            </el-button>
            <el-button
                v-if="isAgentBound(row.id) && userStore.userInfo.user_type === 'AGENT'"
                type="warning"
                size="small"
                @click="showUnbindConfirm(row)"
            >
              申请解绑
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>

<style scoped>
.agent-binding {
  max-width: 1200px;
  margin: 20px auto;
  padding: 20px;
  border: 1px solid #ebeef5;
  border-radius: 8px;
  background: #fff;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
}

h3 {
  margin-bottom: 20px;
  color: #409eff;
}

.agent-list {
  margin-top: 20px;
}

:deep(.el-table) {
  border-radius: 8px;
  overflow: hidden;
}

:deep(.el-table .cell) {
  padding: 0 16px;
}
</style>