<script setup>
import { ref, onMounted, watch } from 'vue';
import { ElMessage, ElMessageBox } from 'element-plus';
import {
  GetCampaigns,
  AddCampaign,
  UpdateCampaign,
  DeleteCampaign,
  ActivateCampaign, PauseCampaign
} from '@/api/index.js';
import CampaignTable from './CampaignTable.vue';
import CampaignForm from './CampaignForm.vue';

// 数据
const campaigns = ref([]);
const totalItems = ref(0);
const currentPage = ref(1);
const pageSize = ref(5);
const sortField = ref('');
const searchText = ref('');
const isCampaignFormVisible = ref(false);
const isEditMode = ref(false);
const currentCampaign = ref({});
const campaignFormRef = ref(null);

// 获取广告活动列表
const getCampaigns = async () => {
  try {
    const response = await GetCampaigns({
      page: currentPage.value,
      size: pageSize.value,
      ordering: sortField.value,
      search: searchText.value,
    });
    campaigns.value = response.results;
    totalItems.value = response.count;
  } catch (error) {
    ElMessage.error('获取广告活动列表失败');
  }
};

// 分页变化
const handlePageChange = (page) => {
  currentPage.value = page;
  getCampaigns();
};

// 排序变化
const handleSortChange = () => {
  getCampaigns();
};

// 搜索
const handleSearch = () => {
  currentPage.value = 1;
  getCampaigns();
};

// 监听搜索关键词的变化，添加防抖
let searchTimeout = null;
watch(searchText, () => {
  clearTimeout(searchTimeout);
  searchTimeout = setTimeout(() => {
    handleSearch();
  }, 300);
});

// 打开广告活动表单
const toggleCampaignForm = () => {
  isCampaignFormVisible.value = true;
  isEditMode.value = false;
  currentCampaign.value = {
    name: '',
    budget: 0,
    start_date: '',
    end_date: '',
  };
};

// 创建广告活动
const createCampaign = async () => {
  try {
    // 校验表单
    await campaignFormRef.value.validate();
    await AddCampaign(currentCampaign.value);
    ElMessage.success('广告活动创建成功');
    isCampaignFormVisible.value = false;
    await getCampaigns();
  } catch (error) {
    if (error instanceof Error) {
      ElMessage.error(error.message);
    } else {
      ElMessage.error('创建广告活动失败');
    }
  }
};

// 编辑广告活动
const editCampaign = (id) => {
  const campaign = campaigns.value.find((item) => item.id === id);
  if (campaign) {
    currentCampaign.value = {...campaign};
    isCampaignFormVisible.value = true;
    isEditMode.value = true;
  } else {
    ElMessage.error('未找到对应的广告活动');
  }
};

// 更新广告活动
const updateCampaign = async () => {
  try {
    // 校验表单
    await campaignFormRef.value.validate();
    await UpdateCampaign(currentCampaign.value.id, currentCampaign.value);
    ElMessage.success('广告活动更新成功');
    isCampaignFormVisible.value = false;
    await getCampaigns();
  } catch (error) {
    if (error instanceof Error) {
      ElMessage.error(error.message);
    } else {
      ElMessage.error('更新广告活动失败');
    }
  }
};

// 删除广告活动
const deleteCampaign = (id) => {
  ElMessageBox.confirm('确定删除此广告活动吗？', '提示', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning',
  })
      .then(async () => {
        try {
          await DeleteCampaign(id);
          ElMessage.success('删除成功');
          await getCampaigns();
        } catch (error) {
          ElMessage.error('删除失败');
        }
      })
      .catch(() => {
      });
};

// 状态操作
const activateCampaign = (id) => {
  ElMessageBox.confirm('确定启用此广告活动吗？', '提示', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning',
  }).then(async () => {
    try {
      await ActivateCampaign(id);
      ElMessage.success('已启用');
      await getCampaigns();
    } catch (error) {
      ElMessage.error(error.response?.data?.error || '启用失败');
    }
  });
};

const pauseCampaign = (id) => {
  ElMessageBox.confirm('确定暂停此广告活动吗？', '提示', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning',
  }).then(async () => {
    try {
      await PauseCampaign(id);
      ElMessage.success('已暂停');
      await getCampaigns();
    } catch (error) {
      ElMessage.error(error.response?.data?.error || '暂停失败');
    }
  });
};

// 页面加载时获取广告活动列表
onMounted(() => {
  getCampaigns();
});
</script>

<template>
  <div class="campaign-container">
    <!-- 操作栏 -->
    <div class="action-bar">
      <el-button @click="toggleCampaignForm" type="primary">添加广告活动</el-button>
    </div>

    <!-- 搜索和排序 -->
    <div class="header">
      <el-input
          v-model="searchText"
          placeholder="请输入广告活动名称搜索"
          clearable
          @clear="handleSearch"
      >
        <template #append>
          <el-button @click="handleSearch" icon="el-icon-search"></el-button>
        </template>
      </el-input>
      <el-select v-model="sortField" placeholder="排序" @change="handleSortChange">
        <el-option label="名称" value="name"></el-option>
        <el-option label="预算" value="-budget"></el-option>
        <el-option label="状态" value="status"></el-option>
        <el-option label="创建时间" value="created_at"></el-option>
        <el-option label="开始时间" value="start_date"></el-option>
        <el-option label="结束时间" value="end_date"></el-option>
      </el-select>
    </div>

    <!-- 广告活动表格 -->
    <CampaignTable
        :campaigns="campaigns"
        @edit="editCampaign"
        @delete="deleteCampaign"
        @activate="activateCampaign"
        @deactivate="pauseCampaign"
    />

    <!-- 分页 -->
    <el-pagination
        v-if="totalItems > 0"
        :current-page="currentPage"
        :page-size="pageSize"
        :total="totalItems"
        @current-change="handlePageChange"
        layout="total, prev, pager, next, jumper"
        class="custom-pagination"
    />

    <!-- 广告活动表单 -->
    <el-dialog v-model="isCampaignFormVisible" :title="isEditMode ? '编辑广告活动' : '添加广告活动'">
      <CampaignForm :campaign="currentCampaign" ref="campaignFormRef"/>
      <span slot="footer" class="dialog-footer">
        <el-button @click="isCampaignFormVisible = false">取消</el-button>
        <el-button type="primary" @click="isEditMode ? updateCampaign() : createCampaign()">
          {{ isEditMode ? '更新' : '添加' }}
        </el-button>
      </span>
    </el-dialog>
  </div>
</template>

<style scoped lang="less">
.campaign-container {
  padding: 20px;
}

.action-bar {
  margin-bottom: 20px;
}

.header {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 20px;
}

.custom-pagination {
  margin-top: 20px;
  text-align: right;
}
</style>