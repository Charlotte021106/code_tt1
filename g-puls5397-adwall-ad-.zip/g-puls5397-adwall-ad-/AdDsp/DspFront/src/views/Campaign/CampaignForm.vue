<script setup>
import {ref, watch} from 'vue';

const props = defineProps({
  campaign: {
    type: Object,
    required: true,
  },
});

const emit = defineEmits(['update:campaign']);

// 表单校验规则
const rules = ref({
  name: [
    {required: true, message: '名称不能为空', trigger: 'blur'},
  ],
  budget: [
    {required: true, message: '预算不能为空', trigger: 'blur'},
    {
      validator: (rule, value, callback) => {
        if (value <= 0) {
          callback(new Error('预算必须大于0'));
        } else if (!/^\d{1,8}(\.\d{1,2})?$/.test(value)) {
          callback(new Error('预算最多十位数字，最多两位小数'));
        } else {
          callback();
        }
      },
      trigger: 'blur',
    },
  ],
  start_date: [
    {required: true, message: '开始时间不能为空', trigger: 'blur'},
    {
      validator: (rule, value, callback) => {
        const now = new Date();
        const startDate = new Date(value);
        if (startDate <= now) {
          callback(new Error('开始时间必须大于当前时间'));
        } else {
          callback();
        }
      },
      trigger: 'blur',
    },
  ],
  end_date: [
    {required: true, message: '结束时间不能为空', trigger: 'blur'},
    {
      validator: (rule, value, callback) => {
        const startDate = new Date(props.campaign.start_date);
        const endDate = new Date(value);
        if (endDate <= startDate) {
          callback(new Error('结束时间必须大于开始时间'));
        } else {
          callback();
        }
      },
      trigger: 'blur',
    },
  ],
});

// 监听表单数据变化
watch(
    () => props.campaign,
    (newVal) => {
      emit('update:campaign', newVal);
    },
    {deep: true}
);

// 暴露 validate 方法
const campaignFormRef = ref(null);
defineExpose({
  validate: () => campaignFormRef.value.validate(),
});

</script>

<template>
  <el-form
      :model="campaign"
      :rules="rules"
      label-width="80px"
      ref="campaignFormRef"
  >
    <el-form-item label="名称" prop="name">
      <el-input v-model="campaign.name"></el-input>
    </el-form-item>
    <el-form-item label="预算" prop="budget">
      <el-input v-model="campaign.budget" type="number"></el-input>
    </el-form-item>
    <el-form-item label="开始时间" prop="start_date">
      <el-date-picker
          v-model="campaign.start_date"
          type="datetime"
          placeholder="选择开始时间"
          value-format="YYYY-MM-DD HH:mm:ss"
      ></el-date-picker>
    </el-form-item>
    <el-form-item label="结束时间" prop="end_date">
      <el-date-picker
          v-model="campaign.end_date"
          type="datetime"
          placeholder="选择结束时间"
          value-format="YYYY-MM-DD HH:mm:ss"
      ></el-date-picker>
    </el-form-item>
  </el-form>
</template>

<style scoped lang="less">
/* 样式可以根据需要添加 */
</style>