<script setup>
import { formatDateTime } from '@/utils/formatTime';
const tableRowClassName = ({ row }) => {
  if (row.status === 'COMPLETED') {
    return 'completed-row';
  }
  return '';
};
defineProps({
  campaigns: {
    type: Array,
    required: true,
  },
});

defineEmits(['edit', 'delete', 'activate', 'deactivate']);
</script>

<template>
  <el-table
      :data="campaigns"
      style="width: 100%"
      stripe
      :row-class-name="tableRowClassName"
  >
    <el-table-column label="名称" prop="name"></el-table-column>
    <el-table-column label="预算" prop="budget"></el-table-column>
    <el-table-column label="状态" prop="status">
      <template #default="{ row }">
        <el-tag
            :type="row.status === 'ACTIVE' ? 'success' : row.status === 'PAUSED' ? 'warning' : 'info'"
            :class="{ 'completed-tag': row.status === 'COMPLETED' }"
        >
          {{ row.status === 'ACTIVE' ? '进行中' : row.status === 'PAUSED' ? '暂停' : '已完成' }}
        </el-tag>
      </template>
    </el-table-column>
    <el-table-column label="开始时间" prop="start_date">
      <template #default="{ row }">
        <span>{{ formatDateTime(row.start_date) }}</span>
      </template>
    </el-table-column>
    <el-table-column label="结束时间" prop="end_date">
      <template #default="{ row }">
        <span>{{ formatDateTime(row.end_date) }}</span>
      </template>
    </el-table-column>
    <el-table-column label="操作" align="center" width="200px">
      <template #default="{ row }">
        <el-button-group>
          <el-button @click="$emit('edit', row.id)" type="primary" size="small">编辑</el-button>
          <el-button @click="$emit('delete', row.id)" type="danger" size="small">删除</el-button>
          <el-button
              v-if="row.status === 'PAUSED'"
              @click="$emit('activate', row.id)"
              type="success"
              size="small"
          >
            启用
          </el-button>
          <el-button
              v-if="row.status === 'ACTIVE'"
              @click="$emit('deactivate', row.id)"
              type="warning"
              size="small"
          >
            停用
          </el-button>
        </el-button-group>
      </template>
    </el-table-column>
  </el-table>
</template>

<style scoped lang="less">
.completed-tag {
   background-color: #909399; /* 灰色背景 */
   color: #fff; /* 白色文字 */
   border: none; /* 去掉边框 */
 }

.completed-row {
  background-color: #f0f0f0; /* 灰色背景 */
  color: #909399; /* 灰色文字 */
}
</style>