<script setup>
import AgentBinding from "@/views/UserManagement/AgentBinding.vue";
import Campaign from "@/views/Campaign/Campaign.vue";
import useUserInfoStore from "@/store/user.js";
import { ElAlert, ElCard } from "element-plus";


const userStore = useUserInfoStore();
</script>

<template>
  <div v-if="userStore.userInfo.user_type === 'ADVERTISER'" class="page-container">
    <!-- 左侧主内容区域 -->
    <div class="main-content">

    <Campaign/>
    </div>

    <!-- 右侧代理绑定区域 -->
    <div class="agent-binding-wrapper">
      <!-- 代理绑定卡片 -->
      <el-card class="agent-binding-card">
        <template #header>
          <div class="card-header">
            <span>代理绑定</span>
          </div>
        </template>
        <!-- 提示信息 -->
        <el-alert
            title="代理绑定说明"
            type="info"
            description="绑定代理可以帮助您更好地管理广告投放，提升广告效果。"
            show-icon
            :closable="false"
            style="margin-bottom: 16px;"
        />
        <!-- AgentBinding 组件 -->
        <AgentBinding />
      </el-card>
    </div>
  </div>
</template>

<style scoped lang="less">
.page-container {
  display: flex;
  gap: 20px;
  padding: 20px;
}

.main-content {
  flex: 1;
  background: #fff;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.agent-binding-wrapper {
  width: 400px;
}

.agent-binding-card {
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);

  .card-header {
    font-size: 16px;
    font-weight: bold;
    color: #409eff;
  }
}
</style>