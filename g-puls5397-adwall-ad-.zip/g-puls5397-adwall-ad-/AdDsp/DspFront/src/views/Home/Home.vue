<script setup>
import Sidebar from "@/components/Sidebar.vue";
import Header from "@/components/Header.vue";
</script>
<template>
  <el-container class="layout-container">
    <Sidebar/>
    <el-container class="layout-container-2">
      <Header/>
      <el-main class="main">
        <!-- 根据路由展示，main里面的内容-->
        <router-view/>
      </el-main>
    </el-container>
  </el-container>
</template>
<style scoped lang="less">
.layout-container {
  height: 100%; /*元素的高度为其父元素高度的100%*/
  width: 100%; /*元素的高度为其父元素宽度的100%*/
}

.layout-container-2 {
  width: 100%;
  flex-direction: column;
}
</style>