import dayjs from 'dayjs'

// 格式化时间为 YYYY-MM-DD HH:mm:ss
export const formatDateTime = (dateTime) => {
    return dayjs(dateTime).format('YYYY-MM-DD HH:mm:ss')
}