import {createApp} from 'vue'
import './style.css'
import App from './App.vue'
import router from './router'
import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'
import * as ElementPlusIconsVue from '@element-plus/icons-vue'
import SvgIcon from '@/components/iconfont/SvgIcon.vue'
import '@/assets/iconfont/iconfont.js'
import pinia from "@/store/index.js"
import VueAMap from 'vue-amap';

createApp(App).use(router).use(ElementPlus).use(ElementPlusIconsVue).use(SvgIcon).use(pinia).mount('#app')
