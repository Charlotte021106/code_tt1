from rest_framework.permissions import BasePermission


# 广告主权限
class AdvertiserPermissions(BasePermission):
    def has_permission(self, request, view):
        user = request.user
        return not user.is_staff and not user.is_superuser


# 代理商（AGENT）权限
class AgentPermission(BasePermission):
    def has_permission(self, request, view):
        user = request.user
        return user.is_staff and not user.is_superuser


# 管理员权限
class AdminPermission(BasePermission):
    def has_permission(self, request, view):
        user = request.user
        return user.is_superuser


