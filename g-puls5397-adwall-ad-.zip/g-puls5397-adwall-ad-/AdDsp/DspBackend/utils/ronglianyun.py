# -*- coding: utf-8 -*-
"""
@Time ： 2025/2/20 18:18
@Auth ： 九问
@File ：ronglianyun.py
@IDE ：PyCharm
@Email : 2750826557@qq.com
"""
import json

from ronglian_sms_sdk import SmsSDK

from config.ronglianyun.ronglianyunConfig import accId, accToken, appId


class Message:
    """
    短信发送工具类，使用容联云短信服务进行短信发送。

    该类采用单例模式设计，确保在整个应用程序中只有一个Message实例，
    以避免重复创建和初始化短信SDK，提高资源利用效率。

    属性:
        _instance: 类的单例实例。
        sdk: 容联云短信服务的SDK实例，用于发送短信。

    方法:
        __new__: 控制实例的创建，实现单例模式。
        send_message: 发送短信到指定手机号，包含验证码和过期时间等信息。
    """

    # 单例模式
    def __new__(cls, *args, **kwargs):
        # 如果是第一次创建对象，初始化SDK实例；否则返回已存在的实例
        if not hasattr(cls, '_instance'):
            cls._instance = super().__new__(cls, *args, **kwargs)
            cls._instance.sdk = SmsSDK(accId, accToken, appId)
        return cls._instance

    def send_message(self, mobile, datas):
        """
        发送短信到指定手机号。

        参数:
            mobile (str): 接收短信的手机号码。
            datas (tuple): 短信内容数据，通常包含验证码和过期时间。

        返回:
            int: 发送结果，0表示成功，1表示失败。
        """
        sdk = self.sdk
        tid = '1'  # 短信模板ID
        resp = sdk.sendMessage(tid, mobile, datas)  # 调用SDK发送短信
        resp = json.loads(resp)  # 解析响应结果
        if resp['statusCode'] == '000000':  # 判断是否发送成功
            return 0
        else:
            return 1


if __name__ == '__main__':
    m = Message()
    m.send_message('13272631958', ('8787', '5'))  # datas为验证码和过期时间
