# -*- coding: utf-8 -*-
"""
@Time ： 2025/2/20 11:08
@Auth ： 九问
@File ：filters.py
@IDE ：PyCharm
@Email : 2750826557@qq.com
"""
from rest_framework.pagination import PageNumberPagination


class MyPageNumberPagination(PageNumberPagination):
    page_size = 10  # 默认每页多少条
    page_size_query_param = 'size'  # 规定哪个参数为分页大小参数 size = 10
    max_page_size = 100  # 最大每页多少条
