# -*- coding: utf-8 -*-
"""
@Time ： 2025/2/25 12:21
@Auth ： 九问
@File ：serializers.py
@IDE ：PyCharm
@Email : 2750826557@qq.com
"""
from rest_framework import serializers
from django.utils import timezone
from decimal import Decimal
from user.models import User
from .models import Campaign, Creative, AdPlacement


class CampaignSerializer(serializers.ModelSerializer):
    advertiser = serializers.PrimaryKeyRelatedField(
        queryset=User.objects.all(),
        help_text="广告主ID",
        required=False
    )

    class Meta:
        model = Campaign
        fields = [
            'id', 'name', 'advertiser', 'budget', 'start_date',
            'end_date', 'status', 'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']

    def validate_budget(self, value):
        """确保预算大于零"""
        if value < Decimal('0.01'):
            raise serializers.ValidationError("预算必须大于0。")
        return value

    def validate_status(self, value):
        """转换状态值为大写以匹配模型选项"""
        return value.upper()

    def validate_start_date(self, value):
        """确保开始时间不在过去"""
        if value < timezone.now():
            raise serializers.ValidationError("开始时间不能早于当前时间。")
        return value

    def validate_name(self, value):
        """验证广告活动名称在同一广告主下唯一"""
        advertiser = self.context['request'].user  # 从上下文中获取当前用户
        if self.instance:  # 更新操作
            if Campaign.objects.filter(advertiser=advertiser, name=value).exclude(pk=self.instance.pk).exists():
                raise serializers.ValidationError("您已创建过相同名称的广告活动啦！")
        else:  # 创建操作
            if Campaign.objects.filter(advertiser=advertiser, name=value).exists():
                raise serializers.ValidationError("您已创建过相同名称的广告活动啦！")
        return value

    def validate(self, data):
        """验证时间顺序，处理部分更新情况"""
        # 获取传入或已有的时间值
        start_date = data.get('start_date', self.instance.start_date if self.instance else None)
        end_date = data.get('end_date', self.instance.end_date if self.instance else None)

        # 创建时必须提供时间
        if self.instance is None and (start_date is None or end_date is None):
            missing_field = 'start_date' if start_date is None else 'end_date'
            raise serializers.ValidationError({missing_field: "该字段为必填项。"})

        # 检查时间顺序
        if start_date and end_date and end_date <= start_date:
            raise serializers.ValidationError({'end_date': '结束时间必须晚于开始时间。'})

        return data


class CreativeSerializer(serializers.ModelSerializer):
    file_url = serializers.CharField(required=False)

    class Meta:
        model = Creative
        exclude = ['is_approved']
        read_only_fields = ['id', 'created_at', 'updated_at']

    def validate_creative_type(self, value):
        """
        自定义验证创意类型字段。
        确保创意类型只能是 'IMAGE' 或 'VIDEO'。
        """
        if value not in dict(Creative.TYPE_CHOICES).keys():
            raise serializers.ValidationError("创意类型必须是 'IMAGE' 或 'VIDEO'")
        return value

    def validate_campaign(self, value):
        """
        验证广告活动是否属于当前用户。
        """
        user = self.context['request'].user
        if value.advertiser != user:
            raise serializers.ValidationError("您没有权限操作此广告活动")
        return value

    def validate_title(self, value):
        """
        验证广告创意标题在同一广告活动中唯一
        """
        campaign = self.initial_data.get('campaign')
        if self.instance:  # 更新操作
            if Creative.objects.filter(campaign=campaign, title=value).exclude(pk=self.instance.pk).exists():
                raise serializers.ValidationError("您已创建过标题相同的广告创意啦！")
        else:
            if Creative.objects.filter(campaign=campaign, title=value).exists():
                raise serializers.ValidationError("您已创建过标题相同的广告创意啦！")
        return value


class AdPlacementSerializer(serializers.ModelSerializer):

    campaign_name = serializers.CharField(source='campaign.name', read_only=True)
    creative_title = serializers.CharField(source='creative.title', read_only=True)

    class Meta:
        model = AdPlacement
        fields = '__all__'
        read_only_fields = ['created_at', 'updated_at']
        extra_kwargs = {
            'campaign': {'required': True},
            'creative': {'required': True}
        }

    def validate_target_audience(self, value):
        """验证定向条件格式"""
        required_keys = ['geo', 'age_range']
        if not all(k in value for k in required_keys):
            raise serializers.ValidationError("必须包含geo和age_range字段")
        return value

    def validate(self, data):
        """全局校验逻辑"""
        campaign = data.get('campaign')
        creative = data.get('creative')
        if creative and campaign and creative.campaign != campaign:
            raise serializers.ValidationError("该广告创意和广告活动不存在绑定关系")
        # 检查是否已存在相同的 campaign 和 creative 组合
        if AdPlacement.objects.filter(campaign=campaign, creative=creative).exists():
            raise serializers.ValidationError("同一广告活动和广告创意只能创建一个广告投放")
        # 时间范围校验
        start_time = data.get('start_time')
        end_time = data.get('end_time')
        if start_time and end_time:
            if start_time < campaign.start_date:
                raise serializers.ValidationError("投放开始时间不能早于广告活动开始时间")
            if end_time > campaign.end_date:
                raise serializers.ValidationError("投放结束时间不能晚于广告活动结束时间")

        return data
