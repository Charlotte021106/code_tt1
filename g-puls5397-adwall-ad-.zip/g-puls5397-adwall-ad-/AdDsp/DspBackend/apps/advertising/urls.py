# -*- coding: utf-8 -*-
"""
@Time ： 2025/2/27 23:12
@Auth ： 九问
@File ：urls.py
@IDE ：PyCharm
@Email : 2750826557@qq.com
"""

from rest_framework.routers import DefaultRouter
from .views import *

urlpatterns = [
]

router = DefaultRouter()
router.register('campaign', CampaignViewSet, 'campaign')
router.register('creative', CreativeViewSet, 'creative')
router.register('placement', AdPlacementViewSet)
urlpatterns += router.urls

"""
API接口说明：

1. 广告活动管理
   - 活动列表和创建
     * 路径: /advertising/campaign/
     * 方法: GET, POST
     * 权限: 广告主可查看自己的活动，代理商可查看代理的活动，管理员可查看所有活动
     * 功能: 获取广告活动列表和创建新活动

   - 活动详情、更新和删除
     * 路径: /advertising/campaign/<id>/
     * 方法: GET, PUT, DELETE
     * 权限: 广告主可操作自己的活动，代理商可操作代理的活动，管理员可操作所有活动
     * 功能: 获取、更新和删除广告活动

2. 广告创意管理
   - 创意列表和创建
     * 路径: /advertising/creative/
     * 方法: GET, POST
     * 权限: 广告主可查看自己的创意，代理商可查看代理的创意，管理员可查看所有创意
     * 功能: 获取广告创意列表和创建新创意

   - 创意详情、更新和删除
     * 路径: /advertising/creative/<id>/
     * 方法: GET, PUT, DELETE
     * 权限: 广告主可操作自己的创意，代理商可操作代理的创意，管理员可操作所有创意
     * 功能: 获取、更新和删除广告创意

3. 广告投放管理
   - 投放列表和创建
     * 路径: /advertising/placement/
     * 方法: GET, POST
     * 权限: 广告主可查看自己的投放，代理商可查看代理的投放，管理员可查看所有投放
     * 功能: 获取广告投放列表和创建新投放

   - 投放详情、更新和删除
     * 路径: /advertising/placement/<id>/
     * 方法: GET, PUT, DELETE
     * 权限: 广告主可操作自己的投放，代理商可操作代理的投放，管理员可操作所有投放
     * 功能: 获取、更新和删除广告投放
"""
