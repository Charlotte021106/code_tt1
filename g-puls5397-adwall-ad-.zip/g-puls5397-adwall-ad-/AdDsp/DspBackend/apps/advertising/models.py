from django.db import models
from django.utils import timezone
from user.models import User


# 广告活动管理
class Campaign(models.Model):
    STATUS_CHOICES = (
        ('ACTIVE', 'Active'),
        ('PAUSED', 'Paused'),
        ('COMPLETED', 'Completed'),
    )
    name = models.CharField(
        max_length=255,
        help_text="广告活动名称"
    )
    advertiser = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='campaigns',
        help_text="关联的广告主"
    )
    budget = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        help_text="广告活动总预算"
    )
    start_date = models.DateTimeField(
        help_text="广告活动开始时间"
    )
    end_date = models.DateTimeField(
        help_text="广告活动结束时间"
    )
    status = models.CharField(
        max_length=10,
        choices=STATUS_CHOICES,
        default='ACTIVE',
        help_text="广告活动状态：ACTIVE（进行中）、PAUSED（暂停）、COMPLETED（已完成）"
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        help_text="广告活动创建时间"
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        help_text="广告活动最后更新时间"
    )

    def save(self, *args, **kwargs):
        # 检查广告活动是否过期
        if self.end_date and self.end_date <= timezone.now():
            self.status = 'COMPLETED'
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.name} ({self.status})"


# 广告创意管理
class Creative(models.Model):
    TYPE_CHOICES = (
        ('IMAGE', 'Image'),
        ('VIDEO', 'Video'),
    )
    campaign = models.ForeignKey(
        Campaign,
        on_delete=models.CASCADE,
        related_name='creatives',
        help_text="关联的广告活动"
    )
    creative_type = models.CharField(
        max_length=10,
        choices=TYPE_CHOICES,
        help_text="创意类型：图片（IMAGE）、视频（VIDEO）"
    )
    file_url = models.URLField(
        help_text="创意文件 URL"
    )
    title = models.CharField(
        max_length=255,
        help_text="创意标题"
    )
    description = models.TextField(
        blank=True,
        null=True,
        help_text="创意描述"
    )
    is_approved = models.BooleanField(
        default=False,
        help_text="创意是否已审核通过"
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        help_text="创意创建时间"
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        help_text="创意最后更新时间"
    )

    def __str__(self):
        return f"{self.title} ({self.creative_type})"


# 投放管理
class AdPlacement(models.Model):
    campaign = models.ForeignKey(
        Campaign,
        on_delete=models.CASCADE,
        related_name='placements',
        help_text="关联的广告活动"
    )
    creative = models.ForeignKey(
        Creative,
        on_delete=models.CASCADE,
        help_text="关联的广告创意"
    )
    bid_type = models.CharField(
        max_length=10,
        choices=(('CPC', 'CPC'), ('CPM', 'CPM'), ('CPA', 'CPA')),
        help_text="竞价类型：CPC（每次点击成本）、CPM（每千次展示成本）、CPA（每次行动成本）"
    )
    bid_amount = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        help_text="竞价金额"
    )
    target_audience = models.JSONField(
        help_text="目标受众定向条件，JSON 格式"
    )
    start_time = models.DateTimeField(
        help_text="投放开始时间"
    )
    end_time = models.DateTimeField(
        help_text="投放结束时间"
    )
    status = models.CharField(
        max_length=10,
        choices=(
            ('ACTIVE', '进行中'),
            ('PAUSED', '已暂停'),
            ('COMPLETED', '已完成')
        ),
        default='ACTIVE',  # 增加默认值
        help_text="投放状态：ACTIVE（进行中）、PAUSED（暂停）、COMPLETED（已完成）"
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        help_text="投放创建时间"
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        help_text="投放最后更新时间"
    )

    def __str__(self):
        return f"{self.campaign.name} - {self.creative.title} ({self.status})"

    def save(self, *args, **kwargs):
        # 当广告活动状态变化时同步状态
        if self.campaign.status == 'COMPLETED':
            self.status = 'COMPLETED'
        elif self.campaign.status == 'PAUSED' and self.status == 'ACTIVE':
            self.status = 'PAUSED'

        # 自动完成状态判断（根据时间）
        now = timezone.now()
        if self.end_time and self.end_time < now:
            self.status = 'COMPLETED'

        super().save(*args, **kwargs)
