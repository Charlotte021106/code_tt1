from django.db import transaction
from rest_framework import viewsets, status, filters
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
import logging
from advertising.models import Campaign, Creative, AdPlacement
from advertising.serializers import CampaignSerializer, CreativeSerializer, AdPlacementSerializer
from stats.models import Billing
from utils.filters import MyPageNumberPagination
from utils.permissions import AdvertiserPermissions
from utils.tools import ThreadImgs
from celery_tasks.fdfs.tasks import remove_fdfs_resources
logger = logging.getLogger(__name__)


class CampaignViewSet(viewsets.ModelViewSet):
    serializer_class = CampaignSerializer
    pagination_class = MyPageNumberPagination
    # 基础查询集
    queryset = Campaign.objects.all()
    permission_classes = [IsAuthenticated, AdvertiserPermissions]
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['name']  # 指定搜索字段
    ordering_fields = ['name', 'created_at', 'budget', 'start_date', 'end_date']  # 指定排序字段
    ordering = '-created_at'  # 默认排序

    def get_serializer_context(self):
        """将请求对象传递给序列化器"""
        context = super().get_serializer_context()
        context['request'] = self.request
        return context

    def get_queryset(self):
        """智能数据过滤"""
        user = self.request.user
        queryset = super().get_queryset()
        # 权限过滤
        if user.is_superuser:
            # 管理员查看全部
            pass
        elif user.is_staff:
            # 代理查看其负责的广告主的广告活动
            queryset = queryset.filter(advertiser__agentclientrelationship__agent=user)
        else:
            # 普通用户只能看自己的
            queryset = queryset.filter(advertiser=user)
        return queryset.order_by('-created_at')

    def perform_create(self, serializer):
        """创建时自动关联用户"""
        serializer.save(advertiser=self.request.user)

    @action(detail=True, methods=['post'], url_path='activate')
    def activate_campaign(self, request, pk=None):
        """激活广告活动（原子操作 + 状态校验）"""
        try:
            with transaction.atomic():
                # 原子操作锁定记录
                campaign = Campaign.objects.select_for_update().get(pk=pk)

                # 状态校验
                if campaign.status == 'COMPLETED':
                    return Response(
                        {"error": "已完成的活动不可激活"},
                        status=status.HTTP_400_BAD_REQUEST
                    )

                # 预算校验（如果存在账单）
                try:
                    billing = Billing.get_campaign_billing(campaign.id)
                    budget_status, _ = billing.check_budget_status()
                    if budget_status == 'exhausted':
                        return Response(
                            {"error": "预算已耗尽，无法激活活动"},
                            status=status.HTTP_400_BAD_REQUEST
                        )
                except ValueError as e:
                    # 账单不存在时，仅记录日志，不阻止激活
                    logger.info(f"Campaign {campaign.id} has no billing info, allow activation")

                # 状态流转
                if campaign.status == 'PAUSED':
                    campaign.status = 'ACTIVE'
                    campaign.save()
                    return Response(
                        {"status": 'ACTIVE', "message": "活动已激活"},
                        status=status.HTTP_200_OK
                    )
                else:
                    return Response(
                        {"error": f"仅允许从PAUSED状态激活"},
                        status=status.HTTP_400_BAD_REQUEST
                    )

        except Campaign.DoesNotExist:
            return Response(
                {"error": "广告活动不存在或无权访问"},
                status=status.HTTP_404_NOT_FOUND
            )

    @action(detail=True, methods=['post'], url_path='pause')
    def pause_campaign(self, request, pk=None):
        """暂停广告活动（原子操作）"""
        try:
            with transaction.atomic():
                campaign = Campaign.objects.select_for_update().get(pk=pk)

                if campaign.status == 'ACTIVE':
                    campaign.status = 'PAUSED'
                    campaign.save()
                    return Response(
                        {"status": 'PAUSED', "message": "活动已暂停"},
                        status=status.HTTP_200_OK
                    )
                else:
                    return Response(
                        {"error": f"仅允许ACTIVE状态的活动暂停"},
                        status=status.HTTP_400_BAD_REQUEST
                    )

        except Campaign.DoesNotExist:
            return Response(
                {"error": "广告活动不存在或无权访问"},
                status=status.HTTP_404_NOT_FOUND
            )


class CreativeViewSet(viewsets.ModelViewSet):
    queryset = Creative.objects.all()
    serializer_class = CreativeSerializer
    pagination_class = MyPageNumberPagination
    permission_classes = [IsAuthenticated, AdvertiserPermissions]
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['title']
    ordering_fields = ['title', 'created_at', 'updated_at']
    ordering = '-created_at'
    threadImgs = ThreadImgs()  # 文件上传工具类

    def get_queryset(self):
        """
        只返回当前用户的广告创意。
        """
        user = self.request.user
        return Creative.objects.filter(campaign__advertiser=user)

    def get_serializer_context(self):
        """将请求对象传递给序列化器"""
        context = super().get_serializer_context()
        context['request'] = self.request
        return context

    def update(self, request, *args, **kwargs):
        """
        完全更新创意（PUT 请求）。
        """
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=False)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)
        return Response(serializer.data)

    def partial_update(self, request, *args, **kwargs):
        """
        部分更新创意（PATCH 请求）。
        """
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)
        return Response(serializer.data)

    def perform_update(self, serializer):
        """
        执行更新操作，包含文件上传和事务管理。
        """
        with transaction.atomic():
            save_point = transaction.savepoint()
            try:
                instance = serializer.save()

                # 用户未填写file_url字段
                if self.request.FILES.getlist('file'):
                    self.handle_file_upload(instance)
                # 删除旧文件（如果有新文件上传）
                if self.request.FILES.getlist('file') and instance.file_url:
                    self.handle_file_upload(instance)
                    remove_fdfs_resources.delay(instance.file_url)  # 异步删除旧文件
                # 清空临时文件列表
                self.threadImgs.clear()

            except Exception as e:
                transaction.savepoint_rollback(save_point)
                # 删除新上传的文件（如果出错）
                if self.request.FILES.getlist('file'):
                    remove_fdfs_resources.delay(self.threadImgs.image_list[0])
                raise e
            else:
                transaction.savepoint_commit(save_point)

    def create(self, request, *args, **kwargs):
        """
        创建新创意（POST 请求）。
        """
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)

    def perform_create(self, serializer):
        """
        执行创建操作，包含文件上传和事务管理。
        """
        with transaction.atomic():
            save_point = transaction.savepoint()
            try:
                campaign_id = self.request.data.get('campaign')
                # 保存创意，并关联当前用户和广告活动
                instance = serializer.save(campaign_id=campaign_id)
                # 处理文件上传
                if self.request.FILES.getlist('file'):
                    self.handle_file_upload(instance)

                # 清空临时文件列表
                self.threadImgs.clear()

            except Exception as e:
                transaction.savepoint_rollback(save_point)
                # 删除新上传的文件（如果出错）
                if self.request.FILES.getlist('file'):
                    remove_fdfs_resources.delay(self.threadImgs.image_list[0])
                raise e
            else:
                transaction.savepoint_commit(save_point)

    def handle_file_upload(self, instance):
        """
        处理文件上传逻辑。
        """
        files = self.request.FILES.getlist('file')
        if files:
            self.threadImgs.circulate_add_file(files)
            instance.file_url = self.threadImgs.image_list[0]  # 更新文件 URL
            instance.save()

    @action(detail=False, methods=['get'],url_path='by_campaign')
    def by_campaign(self, request):
        """
        根据广告活动ID查询广告创意
        params：campaign_id
        """
        campaign_id = request.query_params.get('campaign_id')
        if not campaign_id:
            return Response({"error": "缺少 campaign_id 参数"}, status=400)

        creatives = self.queryset.filter(campaign_id=campaign_id)
        serializer = self.get_serializer(creatives, many=True)
        return Response(serializer.data)


class AdPlacementViewSet(viewsets.ModelViewSet):
    serializer_class = AdPlacementSerializer
    permission_classes = [IsAuthenticated, AdvertiserPermissions]
    queryset = AdPlacement.objects.all()

    def get_queryset(self):
        """数据隔离：仅返回当前用户的投放"""
        return self.queryset.filter(
            campaign__advertiser=self.request.user
        ).select_related('campaign', 'creative')

    @action(detail=True, methods=['post'], url_path='activate')
    def activate_placement(self, request, pk=None):
        """激活广告投放（需关联广告活动为ACTIVE状态）"""
        try:
            with transaction.atomic():
                # 锁定广告投放及其关联的广告活动（防止并发操作）
                placement = AdPlacement.objects.select_for_update().get(pk=pk)
                campaign = Campaign.objects.select_for_update().get(pk=placement.campaign_id)

                # 状态校验 - 广告活动
                if campaign.status != 'ACTIVE':
                    return Response(
                        {"error": "关联广告活动未启用，无法启用投放"},
                        status=status.HTTP_400_BAD_REQUEST
                    )

                # 状态校验 - 广告投放
                if placement.status == 'COMPLETED':
                    return Response(
                        {"error": "已结束的投放不可激活"},
                        status=status.HTTP_400_BAD_REQUEST
                    )

                # 状态流转
                if placement.status == 'PAUSED':
                    placement.status = 'ACTIVE'
                    placement.save()
                    return Response(
                        {"status": 'ACTIVE', "message": "广告投放已激活"},
                        status=status.HTTP_200_OK
                    )
                else:
                    return Response(
                        {"error": "仅允许从PAUSED状态激活"},
                        status=status.HTTP_400_BAD_REQUEST
                    )

        except AdPlacement.DoesNotExist:
            return Response(
                {"error": "广告投放不存在或无权访问"},
                status=status.HTTP_404_NOT_FOUND
            )
        except Campaign.DoesNotExist:
            return Response(
                {"error": "关联广告活动不存在"},
                status=status.HTTP_400_BAD_REQUEST
            )

    @action(detail=True, methods=['post'], url_path='pause')
    def pause_placement(self, request, pk=None):
        """暂停广告投放（原子操作）"""
        try:
            with transaction.atomic():
                placement = AdPlacement.objects.select_for_update().get(pk=pk)

                if placement.status == 'ACTIVE':
                    placement.status = 'PAUSED'
                    placement.save()
                    return Response(
                        {"status": 'PAUSED', "message": "广告投放已暂停"},
                        status=status.HTTP_200_OK
                    )
                else:
                    return Response(
                        {"error": f"仅允许ACTIVE状态的投放暂停"},
                        status=status.HTTP_400_BAD_REQUEST
                    )

        except AdPlacement.DoesNotExist:
            return Response(
                {"error": "广告投放不存在或无权访问"},
                status=status.HTTP_404_NOT_FOUND
            )
