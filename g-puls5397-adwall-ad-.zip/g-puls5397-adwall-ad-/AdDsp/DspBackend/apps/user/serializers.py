import re
from django.contrib.auth import authenticate
from django.contrib.auth.models import update_last_login
from rest_framework import serializers
from rest_framework_simplejwt.serializers import TokenObtainSerializer
from rest_framework_simplejwt.settings import api_settings
from rest_framework_simplejwt.tokens import RefreshToken

from user.models import User, AgentClientRelationship
from utils.crypto_tool import myAESCipher, myDESCipher


class RegisterCodeSerializer(serializers.Serializer):
    mobile = serializers.CharField(max_length=11, label='手机号')

    def validate_mobile(self, mobile):
        # 检查长度
        if len(mobile) != 11:
            raise serializers.ValidationError('手机号码长度必须为11位！')

        # 使用正则表达式校验手机号码格式
        pattern = r'^1[3-9]\d{9}$'
        if not re.match(pattern, mobile):
            raise serializers.ValidationError('手机号码格式不正确，请重新输入！')
        return mobile


class RegisterSerializer(serializers.Serializer):
    user_type = serializers.ChoiceField(choices=[('AGENT', 'Agent'), ('ADVERTISER', 'Advertiser')], label='用户类型',
                                        help_text="广告主或代理商(传入ADVERTISER或者AGENT)")
    username = serializers.CharField(max_length=30, label='用户名')
    password = serializers.CharField(min_length=6, label='密码', help_text='密码(需用AES加密)，6位及以上')
    phone_number = serializers.CharField(max_length=11, label='手机号')
    code = serializers.CharField(min_length=4, max_length=4, label='验证码', help_text='4位验证码')
    email = serializers.EmailField(label="邮箱号")
    company_name = serializers.CharField(min_length=1, max_length=20, required=False, help_text='公司名或个人名')

    def validate_mobile(self, mobile):
        # 检查长度
        if len(mobile) != 11:
            raise serializers.ValidationError('手机号码长度必须为11位！')

        # 使用正则表达式校验手机号码格式
        pattern = r'^1[3-9]\d{9}$'
        if not re.match(pattern, mobile):
            raise serializers.ValidationError('手机号码格式不正确，请重新输入！')
        return mobile

    def validate_code(self, code):
        # 确保验证码是4位数字
        if len(code) != 4 or not code.isdigit():
            raise serializers.ValidationError('验证码必须为4位数字！')
        return code

    def validate_password(self, password):
        try:
            decrypted_password = myAESCipher.decrypt(password)
        except Exception as e:
            raise serializers.ValidationError('密码格式错误')

        # 验证解密后的密码长度是否大于等于6
        if len(decrypted_password) < 6:
            raise serializers.ValidationError('密码长度必须大于等于6！')
        return decrypted_password

    def validate_user_type(self, user_type):
        user_type = user_type.upper()
        if user_type not in ['AGENT', 'ADVERTISER']:
            raise serializers.ValidationError('用户类型只能是代理商（AGENT）或广告主（ADVERTISER）！')
        return user_type


class LoginTokenObtainSerializer(TokenObtainSerializer):
    token_class = RefreshToken
    code = serializers.CharField(max_length=4, min_length=4)
    uuid = serializers.UUIDField()

    def validate(self, attrs):
        data = {}

        # 对于密码进行解密。再做校验
        try:
            attrs['password'] = myDESCipher.decrypt(attrs['password'])
        except Exception as e:
            raise serializers.ValidationError("密码错误")
        # 校验用户是否存在 (校验用户是否是活跃状态，是否是激活)
        user = authenticate(username=attrs['username'], password=attrs['password'])
        # 生成token
        if user:
            refresh = self.get_token(user)
            data["access"] = str(refresh.access_token)
            data['user'] = user
        if api_settings.UPDATE_LAST_LOGIN:
            update_last_login(None, user)
        return data


class AllAgentSerializer(serializers.ModelSerializer):
    """代理信息展示"""

    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'date_joined']
        read_only_fields = fields


class AgentBindingSerializer(serializers.ModelSerializer):
    class Meta:
        model = AgentClientRelationship
        fields = ['agent']

    def validate_agent(self, value):
        if value.user_type != 'AGENT':
            raise serializers.ValidationError("必须选择代理用户")
        return value

    def validate(self, attrs):
        # 获取当前用户（广告主）
        client = self.context['request'].user
        agent = attrs.get('agent')

        # 检查是否已存在绑定关系
        if AgentClientRelationship.objects.filter(agent=agent, client=client).exists():
            raise serializers.ValidationError({"agent": "您已绑定过该代理，不能重复添加。"})

        return attrs


class ClientSerializer(serializers.ModelSerializer):
    """广告主信息展示"""
    binding_date = serializers.DateTimeField(source='created_at')
    client = serializers.SerializerMethodField()

    def get_client(self, obj):
        return {
            'id': obj.client.id,
            'name': obj.client.username,
            'email': obj.client.email
        }

    class Meta:
        model = AgentClientRelationship
        fields = ['binding_date', 'client']


class AgentSerializer(serializers.ModelSerializer):
    """代理人信息展示"""
    binding_date = serializers.DateTimeField(source='created_at')
    agent = serializers.SerializerMethodField()

    def get_agent(self, obj):
        return {
            'id': obj.agent.id,
            'name': obj.agent.username,
            'email': obj.agent.email
        }

    class Meta:
        model = AgentClientRelationship
        fields = ['binding_date', 'agent']


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = [
            'id', 'username', 'first_name', 'last_name', 'email',
            'user_type', 'company_name', 'phone_number', 'billing_address',
            'is_active', 'is_staff', 'date_joined'
        ]
        read_only_fields = ['id', 'date_joined']
