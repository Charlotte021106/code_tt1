import io
import random
from datetime import timezone

from django.http import HttpResponse
from django_redis import get_redis_connection
from rest_framework import status, generics, filters
from rest_framework.exceptions import PermissionDenied, NotFound
from rest_framework.permissions import IsAuthenticated
from rest_framework.viewsets import GenericViewSet
from rest_framework.response import Response
from rest_framework_simplejwt.views import TokenObtainPairView

from utils.filters import MyPageNumberPagination
from utils.permissions import AgentPermission, AdvertiserPermissions
# from utils.ronglianyun import Message
from .models import User, AgentClientRelationship
from .serializers import *
from utils.tools import MyCaptchaImage


class GetLoginCodeGenericViewSet(GenericViewSet):
    """
    获取登录验证码的视图集。

    该视图集用于生成并返回一个图形验证码，并将验证码存储在Redis缓存中，以便后续验证。

    属性:
        myCaptchaImage (MyCaptchaImage): 用于生成图形验证码的工具类实例。

    方法:
        retrieve: 根据传入的UUID生成验证码图片，并将验证码存储在Redis中，返回验证码图片。
    """
    myCaptchaImage = MyCaptchaImage()

    def retrieve(self, request, uuid):
        """
        生成并返回图形验证码。

        参数:
            request (HttpRequest): HTTP请求对象。
            uuid (str): 唯一标识符，用于在Redis中存储验证码时作为键的一部分。

        返回值:
            HttpResponse: 包含验证码图片的HTTP响应，内容类型为'image/png'。
        """
        # 生成验证码图片和对应的验证码
        img, code = self.myCaptchaImage.generate_code()

        # 将图片转换为字节数据
        img_bytes = io.BytesIO()
        img.save(img_bytes, format='PNG')
        image_bytes = img_bytes.getvalue()  # 图片的字节数据

        # 将验证码存储在Redis中，键为'picturecode_{uuid}'，有效期为300秒
        cache = get_redis_connection(alias='verify_code_pic')
        code_template = f'picturecode_{uuid}'
        cache.set(f'{code_template}', code, 300)

        # 返回验证码图片
        return HttpResponse(image_bytes, content_type='image/png')


class GetRegisterCodeGenericViewSet(GenericViewSet):
    """
    获取注册验证码的视图集。

    该视图集用于生成并发送手机验证码，并将验证码存储在Redis缓存中，以便后续验证。

    属性:
        serializer_class (RegisterCodeSerializer): 用于验证请求数据的序列化器。

    方法:
        create: 根据传入的手机号码生成验证码，并将验证码存储在Redis中，返回验证码发送结果。
    """
    serializer_class = RegisterCodeSerializer
    queryset = User.objects.all()

    def create(self, request):
        """
        生成并发送手机验证码。

        参数:
            request (HttpRequest): HTTP请求对象，包含用户提交的手机号码等信息。

        返回值:
            Response: 包含验证码发送结果的HTTP响应，状态码和消息。
        """
        # 使用序列化器验证请求数据
        serializer = self.get_serializer(data=request.data)
        if not serializer.is_valid():
            # 如果数据无效，直接返回序列化器的错误响应
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        # 获取已验证的手机号码
        mobile = request.data.get('mobile')
        if self.get_queryset().filter(phone_number=mobile).exists():
            return Response({
                "status": status.HTTP_409_CONFLICT,
                "msg": "该手机号已被注册，请换一个手机号进行注册",
            })
        # 生成4位随机数字验证码
        codes = ''.join(random.choices('123456789', k=4))
        # 假设验证码发送成功，将验证码存储在Redis中，键为'verify_code_phone-{mobile}'，有效期为300秒
        cache = get_redis_connection(alias='verify_code_phone')
        template = f'verify_code_phone-{mobile}'
        cache.set(f'{template}', codes, 300)
        # 返回验证码发送成功的响应
        return Response({
            'status': 200,
            'msg': '验证码已发送,请在5分钟之内完成验证！'
        })

        # # 调用短信服务发送验证码
        # message = Message().send_message(mobile, (codes, '5'))
        # if message == 0:
        #     # 假设验证码发送成功，将验证码存储在Redis中，键为'verify_code_phone-{mobile}'，有效期为300秒
        #     cache = get_redis_connection(alias='verify_code_phone')
        #     template = f'verify_code_phone-{mobile}'
        #     cache.set(f'{template}', codes, 300)
        #     # 返回验证码发送成功的响应
        #     return Response({
        #         'status': 200,
        #         'msg': '验证码已发送,请在5分钟之内完成验证！'
        #     })
        # else:
        #     return Response({
        #         'status': 500,
        #         'msg': '验证码发送失败，无法向该手机号发送验证码'
        #     })


class RegisterGenericViewSet(GenericViewSet):
    queryset = User.objects.all()
    serializer_class = RegisterSerializer

    def create(self, request):
        # 校验用户名是否存在
        user = self.get_queryset().filter(username=request.data.get("username")).first()
        if user:
            return Response({
                "status": status.HTTP_409_CONFLICT,
                "msg": "该用户已存在，请换一个用户名进行注册",
            })

        # 校验手机号是否存在
        mobile = request.data.get("phone_number")
        if self.get_queryset().filter(phone_number=mobile).exists():
            return Response({
                "status": status.HTTP_409_CONFLICT,
                "msg": "该手机号已被注册，请换一个手机号进行注册",
            })

        # 校验数据是否正确
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        # 校验验证码 如果不正确则返回报错信息
        cache = get_redis_connection(alias='verify_code_phone')
        template = f'verify_code_phone-{mobile}'
        redis_code = cache.get(template)
        if not redis_code:  # 如果redis_code为None
            redis_code = b'11111111111111'
        if redis_code.decode('utf-8') != request.data['code']:
            cache.delete(f'{template}')
            return Response({
                'status': status.HTTP_400_BAD_REQUEST,
                'msg': '验证码不正确，请重新输入'
            })

        # 如果正确，则删除验证码
        cache.delete(f'{template}')

        try:
            # 创建用户
            user = User(
                username=request.data.get('username'),
                email=request.data.get('email'),
                phone_number=mobile,
                user_type=serializer.validated_data['user_type'],
                is_active=1,
                is_staff=0 if serializer.validated_data['user_type'] == 'ADVERTISER' else 1
            )
            user.set_password(serializer.validated_data['password'])
            user.save()
        except Exception as e:
            # 返回响应告知用户注册失败
            return Response({
                "status": status.HTTP_500_INTERNAL_SERVER_ERROR,
                "msg": "注册失败，请稍后重试",
            })

        # 如果一切正常，返回成功响应
        return Response({
            'status': status.HTTP_201_CREATED,
            'msg': '恭喜您注册成功，可前往登录页面使用用户名和密码进行登录！'
        })


class LoginGenericViewSet(TokenObtainPairView):
    """
        return: res_data.status=18为老师组 status=0为管理员
    """
    serializer_class = LoginTokenObtainSerializer

    def post(self, request, *args, **kwargs):

        # 校验用户信息
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        # 验证码校验
        cache = get_redis_connection(alias='verify_code_pic')
        code_template = f"picturecode_{request.data.get('uuid')}"
        #   取出redis里面的验证码
        redis_code = cache.get(code_template)
        if not redis_code:  # 如果redis_code为None
            redis_code = b'11111111111111'
        if redis_code.decode('utf-8').lower() != request.data.get('code'):
            cache.delete(f'{code_template}')
            return Response({
                'status': status.HTTP_400_BAD_REQUEST,
                'msg': '验证码不正确，请重新输入'
            })
        # 清除验证码
        cache.delete(f'{code_template}')

        try:
            user = serializer.validated_data['user']
        except KeyError:
            return Response({
                "status": status.HTTP_404_NOT_FOUND,
                "msg": "该用户不存在或密码错误"
            })

        response_data = {
            "status": status.HTTP_200_OK,
            "data": {
                "token": serializer.validated_data['access'],
                "username": user.username,
                "user_id": myDESCipher.encrypt(str(user.id)),
                "user_type": user.user_type
            }
        }
        return Response(response_data)


class AgentListAPI(generics.ListAPIView):
    """广告主可查看的代理列表"""
    permission_classes = [IsAuthenticated & AdvertiserPermissions]
    serializer_class = AllAgentSerializer
    pagination_class = MyPageNumberPagination
    filter_backends = [filters.SearchFilter]
    search_fields = ['username', 'email']

    def get_queryset(self):
        # 仅返回代理类型的用户
        return User.objects.filter(user_type='AGENT')


class AgentBindingAPI(generics.CreateAPIView):
    """广告主选择代理"""
    serializer_class = AgentBindingSerializer
    permission_classes = [IsAuthenticated & AdvertiserPermissions]

    def perform_create(self, serializer):
        # 自动设置client为当前用户
        serializer.save(client=self.request.user)


class AgentUnbindAPI(generics.DestroyAPIView):
    """解除代理关系"""
    permission_classes = [IsAuthenticated & AdvertiserPermissions]
    queryset = AgentClientRelationship.objects.all()
    lookup_field = 'id'

    def get_object(self):
        # 从前端获取agent_id
        agent_id = self.kwargs.get('id')

        # 查询绑定关系
        try:
            return AgentClientRelationship.objects.get(
                agent__id=agent_id,
                client=self.request.user
            )
        except AgentClientRelationship.DoesNotExist:
            raise NotFound(detail="未找到绑定关系")

    def perform_destroy(self, instance):
        instance.delete()

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        self.perform_destroy(instance)
        return Response({
            "status": status.HTTP_204_NO_CONTENT,
            "msg": "代理解绑成功",
            "unbound_agent_id": kwargs.get('id'),
        }, status=status.HTTP_200_OK)


class ManagedAgentsAPI(generics.ListAPIView):
    """广告主查看选择的代理"""

    serializer_class = AgentSerializer
    permission_classes = [IsAuthenticated & AdvertiserPermissions]
    pagination_class = MyPageNumberPagination
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['agent__username', 'agent__email']
    ordering_fields = ['created_at']

    def get_queryset(self):
        # 通过中间表获取关联代理
        return AgentClientRelationship.objects.filter(
            client=self.request.user
        ).select_related('agent')


class ManagedClientsAPI(generics.ListAPIView):
    """代理查看名下广告主"""

    serializer_class = ClientSerializer
    permission_classes = [IsAuthenticated & AgentPermission]
    pagination_class = MyPageNumberPagination
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['client__username', 'client__email']
    ordering_fields = ['created_at']

    def get_queryset(self):
        # 通过中间表获取关联广告主
        return AgentClientRelationship.objects.filter(
            agent=self.request.user
        ).select_related('client')
