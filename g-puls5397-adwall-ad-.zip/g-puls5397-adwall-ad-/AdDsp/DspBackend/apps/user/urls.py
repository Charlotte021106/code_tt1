# -*- coding: utf-8 -*-
"""
@Time ： 2024/7/5 17:06
@Auth ： 九问
@File ：urls.py
@IDE ：PyCharm
@Email : 2750826557@qq.com
"""
from django.urls import path
from rest_framework.routers import DefaultRouter
from .views import *

urlpatterns = [
    path('token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),  # jwtToken获取
    path("logcode/<uuid:uuid>/", GetLoginCodeGenericViewSet.as_view({"get": "retrieve"})),  # 登录验证码
    path("code/", GetRegisterCodeGenericViewSet.as_view({"post": "create"})),  # 注册验证码
    path("register/", RegisterGenericViewSet.as_view({"post": "create"})),
    path('login/', LoginGenericViewSet.as_view()),
    # 广告主操作
    path('advertiser/agents/', AgentListAPI.as_view()),  # 查看所有代理
    path('advertiser/agents-bind/', ManagedAgentsAPI.as_view()),  # 查看绑定的代理
    path('advertiser/bind-agent/', AgentBindingAPI.as_view()),
    path('advertiser/unbind-agent/<int:id>/', AgentUnbindAPI.as_view(), name='agent-unbind'),
    # 代理操作
    path('agent/managed-clients/', ManagedClientsAPI.as_view()),
]

"""
API接口说明：

1. 用户认证
   - JWT Token获取
     * 路径: /user/token/
     * 方法: POST
     * 权限: 无需认证
     * 功能: 获取JWT访问令牌

   - 登录验证码
     * 路径: /user/logcode/<uuid>/
     * 方法: GET
     * 权限: 无需认证
     * 功能: 获取登录验证码

   - 注册验证码
     * 路径: /user/code/
     * 方法: POST
     * 权限: 无需认证
     * 功能: 获取注册验证码

   - 用户注册
     * 路径: /user/register/
     * 方法: POST
     * 权限: 无需认证
     * 功能: 新用户注册

   - 用户登录
     * 路径: /user/login/
     * 方法: POST
     * 权限: 无需认证
     * 功能: 用户登录

2. 广告主操作
   - 查看所有代理
     * 路径: /user/advertiser/agents/
     * 方法: GET
     * 权限: 广告主
     * 功能: 获取所有可用代理列表

   - 查看绑定的代理
     * 路径: /user/advertiser/agents-bind/
     * 方法: GET
     * 权限: 广告主
     * 功能: 获取已绑定的代理列表

   - 绑定代理
     * 路径: /user/advertiser/bind-agent/
     * 方法: POST
     * 权限: 广告主
     * 功能: 绑定新的代理

   - 解绑代理
     * 路径: /user/advertiser/unbind-agent/<id>/
     * 方法: POST
     * 权限: 广告主
     * 功能: 解除与代理的绑定

3. 代理操作
   - 查看管理的广告主
     * 路径: /user/agent/managed-clients/
     * 方法: GET
     * 权限: 代理商
     * 功能: 获取管理的广告主列表
"""

router = DefaultRouter()

urlpatterns += router.urls
