from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    USER_TYPE_CHOICES = (
        ('ADVERTISER', 'Advertiser'),
        ('AGENT', 'Agent'),
        ('ADMIN', 'Admin'),
    )
    user_type = models.CharField(
        max_length=10,
        choices=USER_TYPE_CHOICES,
        help_text="用户类型：广告主（ADVERTISER）、代理商（AGENT）、管理员（ADMIN）"
    )
    company_name = models.CharField(
        max_length=255,
        blank=True,
        null=True,
        help_text="公司名称，仅广告主和代理商需要填写"
    )
    phone_number = models.CharField(
        max_length=15,
        blank=True,
        null=True,
        help_text="联系电话"
    )
    billing_address = models.TextField(
        blank=True,
        null=True,
        help_text="账单地址"
    )

    def __str__(self):
        return f"{self.username} ({self.user_type})"


class AgentClientRelationship(models.Model):
    """代理-广告主关联表"""
    agent = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='managed_clients',
        limit_choices_to={'user_type': 'AGENT'}
    )
    client = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='my_agents',
        limit_choices_to={'user_type': 'ADVERTISER'}
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = [['agent', 'client']]
