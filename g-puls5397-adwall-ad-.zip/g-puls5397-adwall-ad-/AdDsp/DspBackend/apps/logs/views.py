from django.db import models
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django.utils import timezone
from datetime import timedelta
from .models import (
    Log, ChatStat, InteractionStat, MessageStat,
    LocationView, Recharge, Consume, ItemUse,
    LocationReport, Feedback, PageStay
)
from .serializers import (
    LogSerializer, ChatStatSerializer, InteractionStatSerializer,
    MessageStatSerializer, LocationViewSerializer, RechargeSerializer,
    ConsumeSerializer, ItemUseSerializer, LocationReportSerializer,
    FeedbackSerializer, PageStaySerializer
)


class LogViewSet(viewsets.ModelViewSet):
    """
    日志记录视图集
    提供日志的CRUD操作
    包含按用户、类型、时间范围等筛选功能
    """
    serializer_class = LogSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        queryset = Log.objects.all()
        user = self.request.user
        log_type = self.request.query_params.get('log_type', None)
        start_date = self.request.query_params.get('start_date', None)
        end_date = self.request.query_params.get('end_date', None)

        # 只返回当前用户的日志
        queryset = queryset.filter(user=user)

        if log_type:
            queryset = queryset.filter(log_type=log_type)
        if start_date:
            queryset = queryset.filter(created_at__gte=start_date)
        if end_date:
            queryset = queryset.filter(created_at__lte=end_date)

        return queryset.order_by('-created_at')

    @action(detail=False, methods=['get'])
    def statistics(self, request):
        """
        获取日志统计信息
        返回各类型日志的数量统计
        """
        queryset = self.get_queryset()
        stats = {}
        for log_type, _ in Log.LOG_TYPE_CHOICES:
            stats[log_type] = queryset.filter(log_type=log_type).count()
        return Response(stats)


class ChatStatViewSet(viewsets.ModelViewSet):
    """
    聊天会话统计视图集
    提供聊天会话统计的CRUD操作
    包含会话时长统计等功能
    """
    serializer_class = ChatStatSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        queryset = ChatStat.objects.all()
        user = self.request.user
        return queryset.filter(user=user).order_by('-created_at')

    @action(detail=False, methods=['get'])
    def daily_stats(self, request):
        """
        获取每日聊天统计
        返回最近7天的每日会话数量和总时长
        """
        queryset = self.get_queryset()
        end_date = timezone.now()
        start_date = end_date - timedelta(days=7)

        stats = {}
        for i in range(7):
            date = start_date + timedelta(days=i)
            date_str = date.strftime('%Y-%m-%d')
            day_stats = queryset.filter(
                created_at__year=date.year,
                created_at__month=date.month,
                created_at__day=date.day
            )
            stats[date_str] = {
                'session_count': day_stats.count(),
                'total_duration': sum(stat.duration for stat in day_stats)
            }
        return Response(stats)


class InteractionStatViewSet(viewsets.ModelViewSet):
    """
    交互频率统计视图集
    提供交互统计的CRUD操作
    包含按类型统计等功能
    """
    serializer_class = InteractionStatSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        queryset = InteractionStat.objects.all()
        user = self.request.user
        return queryset.filter(user=user).order_by('-date')

    @action(detail=False, methods=['get'])
    def type_summary(self, request):
        """
        获取交互类型汇总
        返回各类型交互的总次数
        """
        queryset = self.get_queryset()
        types = queryset.values_list('interaction_type', flat=True).distinct()
        summary = {}
        for type_name in types:
            summary[type_name] = queryset.filter(interaction_type=type_name).aggregate(
                total_count=models.Sum('count')
            )['total_count']
        return Response(summary)


class MessageStatViewSet(viewsets.ModelViewSet):
    """
    消息处理统计视图集
    提供消息统计的CRUD操作
    包含消息处理量统计等功能
    """
    serializer_class = MessageStatSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        queryset = MessageStat.objects.all()
        user = self.request.user
        return queryset.filter(user=user).order_by('-created_at')

    @action(detail=False, methods=['get'])
    def recent_stats(self, request):
        """
        获取最近消息统计
        返回最近24小时的消息处理量
        """
        queryset = self.get_queryset()
        recent_stats = queryset.filter(
            created_at__gte=timezone.now() - timedelta(hours=24)
        ).order_by('-created_at')
        return Response(MessageStatSerializer(recent_stats, many=True).data)


class LocationViewViewSet(viewsets.ModelViewSet):
    """
    位置查看记录视图集
    提供位置查看记录的CRUD操作
    """
    serializer_class = LocationViewSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        queryset = LocationView.objects.all()
        user = self.request.user
        return queryset.filter(user=user).order_by('-created_at')


class RechargeViewSet(viewsets.ModelViewSet):
    """
    账户充值记录视图集
    提供充值记录的CRUD操作
    包含充值金额统计等功能
    """
    serializer_class = RechargeSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        queryset = Recharge.objects.all()
        user = self.request.user
        return queryset.filter(user=user).order_by('-created_at')

    @action(detail=False, methods=['get'])
    def total_amount(self, request):
        """
        获取总充值金额
        返回用户的总充值金额
        """
        queryset = self.get_queryset()
        total = queryset.aggregate(total=models.Sum('amount'))['total'] or 0
        return Response({'total_amount': total})


class ConsumeViewSet(viewsets.ModelViewSet):
    """
    账户消费记录视图集
    提供消费记录的CRUD操作
    包含消费金额统计等功能
    """
    serializer_class = ConsumeSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        queryset = Consume.objects.all()
        user = self.request.user
        return queryset.filter(user=user).order_by('-created_at')

    @action(detail=False, methods=['get'])
    def total_amount(self, request):
        """
        获取总消费金额
        返回用户的总消费金额
        """
        queryset = self.get_queryset()
        total = queryset.aggregate(total=models.Sum('amount'))['total'] or 0
        return Response({'total_amount': total})


class ItemUseViewSet(viewsets.ModelViewSet):
    """
    道具使用记录视图集
    提供道具使用记录的CRUD操作
    包含使用频率统计等功能
    """
    serializer_class = ItemUseSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        queryset = ItemUse.objects.all()
        user = self.request.user
        return queryset.filter(user=user).order_by('-created_at')

    @action(detail=False, methods=['get'])
    def usage_stats(self, request):
        """
        获取道具使用统计
        返回各道具的使用次数
        """
        queryset = self.get_queryset()
        items = queryset.values_list('item_name', flat=True).distinct()
        stats = {}
        for item in items:
            stats[item] = queryset.filter(item_name=item).count()
        return Response(stats)


class LocationReportViewSet(viewsets.ModelViewSet):
    """
    地理位置上报视图集
    提供位置上报记录的CRUD操作
    """
    serializer_class = LocationReportSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        queryset = LocationReport.objects.all()
        user = self.request.user
        return queryset.filter(user=user).order_by('-created_at')


class FeedbackViewSet(viewsets.ModelViewSet):
    """
    评价记录视图集
    提供评价记录的CRUD操作
    包含评分统计等功能
    """
    serializer_class = FeedbackSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        queryset = Feedback.objects.all()
        user = self.request.user
        return queryset.filter(user=user).order_by('-created_at')

    @action(detail=False, methods=['get'])
    def rating_stats(self, request):
        """
        获取评分统计
        返回评分的分布情况
        """
        queryset = self.get_queryset()
        stats = {}
        for rating in range(1, 6):
            stats[rating] = queryset.filter(rating=rating).count()
        return Response(stats)


class PageStayViewSet(viewsets.ModelViewSet):
    """
    页面停留记录视图集
    提供页面停留记录的CRUD操作
    包含停留时长统计等功能
    """
    serializer_class = PageStaySerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        queryset = PageStay.objects.all()
        user = self.request.user
        return queryset.filter(user=user).order_by('-created_at')

    @action(detail=False, methods=['get'])
    def page_stats(self, request):
        """
        获取页面停留统计
        返回各页面的总停留时长
        """
        queryset = self.get_queryset()
        pages = queryset.values_list('page_url', flat=True).distinct()
        stats = {}
        for page in pages:
            stats[page] = queryset.filter(page_url=page).aggregate(
                total_duration=models.Sum('duration')
            )['total_duration']
        return Response(stats)
