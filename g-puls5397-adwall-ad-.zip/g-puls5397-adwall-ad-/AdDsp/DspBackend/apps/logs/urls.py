from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

# 创建路由器
router = DefaultRouter()

# 注册所有视图集
router.register(r'logs', views.LogViewSet, basename='log')
router.register(r'chat-stats', views.ChatStatViewSet, basename='chat-stat')
router.register(r'interaction-stats', views.InteractionStatViewSet, basename='interaction-stat')
router.register(r'message-stats', views.MessageStatViewSet, basename='message-stat')
router.register(r'location-views', views.LocationViewViewSet, basename='location-view')
router.register(r'recharges', views.RechargeViewSet, basename='recharge')
router.register(r'consumes', views.ConsumeViewSet, basename='consume')
router.register(r'item-uses', views.ItemUseViewSet, basename='item-use')
router.register(r'location-reports', views.LocationReportViewSet, basename='location-report')
router.register(r'feedbacks', views.FeedbackViewSet, basename='feedback')
router.register(r'page-stays', views.PageStayViewSet, basename='page-stay')

# API接口说明
"""
日志相关接口 (/logs/logs/):
- GET /logs/logs/ - 获取当前用户的所有日志记录
- POST /logs/logs/ - 创建新的日志记录
- GET /logs/logs/{id}/ - 获取特定日志记录详情
- PUT /logs/logs/{id}/ - 更新特定日志记录
- DELETE /logs/logs/{id}/ - 删除特定日志记录
- GET /logs/logs/statistics/ - 获取各类型日志的数量统计

聊天统计接口 (/logs/chat-stats/):
- GET /logs/chat-stats/ - 获取当前用户的所有聊天会话统计
- POST /logs/chat-stats/ - 创建新的聊天会话统计
- GET /logs/chat-stats/{id}/ - 获取特定聊天会话统计详情
- PUT /logs/chat-stats/{id}/ - 更新特定聊天会话统计
- DELETE /logs/chat-stats/{id}/ - 删除特定聊天会话统计
- GET /logs/chat-stats/daily_stats/ - 获取最近7天的每日会话数量和总时长

交互统计接口 (/logs/interaction-stats/):
- GET /logs/interaction-stats/ - 获取当前用户的所有交互统计
- POST /logs/interaction-stats/ - 创建新的交互统计
- GET /logs/interaction-stats/{id}/ - 获取特定交互统计详情
- PUT /logs/interaction-stats/{id}/ - 更新特定交互统计
- DELETE /logs/interaction-stats/{id}/ - 删除特定交互统计
- GET /logs/interaction-stats/type_summary/ - 获取各类型交互的总次数

消息统计接口 (/logs/message-stats/):
- GET /logs/message-stats/ - 获取当前用户的所有消息统计
- POST /logs/message-stats/ - 创建新的消息统计
- GET /logs/message-stats/{id}/ - 获取特定消息统计详情
- PUT /logs/message-stats/{id}/ - 更新特定消息统计
- DELETE /logs/message-stats/{id}/ - 删除特定消息统计
- GET /logs/message-stats/recent_stats/ - 获取最近24小时的消息处理量

位置查看接口 (/logs/location-views/):
- GET /logs/location-views/ - 获取当前用户的所有位置查看记录
- POST /logs/location-views/ - 创建新的位置查看记录
- GET /logs/location-views/{id}/ - 获取特定位置查看记录详情
- PUT /logs/location-views/{id}/ - 更新特定位置查看记录
- DELETE /logs/location-views/{id}/ - 删除特定位置查看记录

充值记录接口 (/logs/recharges/):
- GET /logs/recharges/ - 获取当前用户的所有充值记录
- POST /logs/recharges/ - 创建新的充值记录
- GET /logs/recharges/{id}/ - 获取特定充值记录详情
- PUT /logs/recharges/{id}/ - 更新特定充值记录
- DELETE /logs/recharges/{id}/ - 删除特定充值记录
- GET /logs/recharges/total_amount/ - 获取用户的总充值金额

消费记录接口 (/logs/consumes/):
- GET /logs/consumes/ - 获取当前用户的所有消费记录
- POST /logs/consumes/ - 创建新的消费记录
- GET /logs/consumes/{id}/ - 获取特定消费记录详情
- PUT /logs/consumes/{id}/ - 更新特定消费记录
- DELETE /logs/consumes/{id}/ - 删除特定消费记录
- GET /logs/consumes/total_amount/ - 获取用户的总消费金额

道具使用接口 (/logs/item-uses/):
- GET /logs/item-uses/ - 获取当前用户的所有道具使用记录
- POST /logs/item-uses/ - 创建新的道具使用记录
- GET /logs/item-uses/{id}/ - 获取特定道具使用记录详情
- PUT /logs/item-uses/{id}/ - 更新特定道具使用记录
- DELETE /logs/item-uses/{id}/ - 删除特定道具使用记录
- GET /logs/item-uses/usage_stats/ - 获取各道具的使用次数统计

位置上报接口 (/logs/location-reports/):
- GET /logs/location-reports/ - 获取当前用户的所有位置上报记录
- POST /logs/location-reports/ - 创建新的位置上报记录
- GET /logs/location-reports/{id}/ - 获取特定位置上报记录详情
- PUT /logs/location-reports/{id}/ - 更新特定位置上报记录
- DELETE /logs/location-reports/{id}/ - 删除特定位置上报记录

评价记录接口 (/logs/feedbacks/):
- GET /logs/feedbacks/ - 获取当前用户的所有评价记录
- POST /logs/feedbacks/ - 创建新的评价记录
- GET /logs/feedbacks/{id}/ - 获取特定评价记录详情
- PUT /logs/feedbacks/{id}/ - 更新特定评价记录
- DELETE /logs/feedbacks/{id}/ - 删除特定评价记录
- GET /logs/feedbacks/rating_stats/ - 获取评分的分布情况统计

页面停留接口 (/logs/page-stays/):
- GET /logs/page-stays/ - 获取当前用户的所有页面停留记录
- POST /logs/page-stays/ - 创建新的页面停留记录
- GET /logs/page-stays/{id}/ - 获取特定页面停留记录详情
- PUT /logs/page-stays/{id}/ - 更新特定页面停留记录
- DELETE /logs/page-stays/{id}/ - 删除特定页面停留记录
"""

urlpatterns = [
    path('', include(router.urls)),
] 