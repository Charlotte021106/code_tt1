from django.db import models

from user.models import User


# 日志记录
class Log(models.Model):
    LOG_TYPE_CHOICES = (
        ('CHAT', 'Chat'),
        ('INTERACTION', 'Interaction'),
        ('MESSAGE', 'Message'),
        ('LOCATION_VIEW', 'Location View'),
        ('RECHARGE', 'Recharge'),
        ('CONSUME', 'Consume'),
        ('ITEM_USE', 'Item Use'),
        ('LOCATION_REPORT', 'Location Report'),
        ('FEEDBACK', 'Feedback'),
        ('PAGE_STAY', 'Page Stay'),
    )
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='logs',
        help_text="关联的用户"
    )
    log_type = models.CharField(
        max_length=20,
        choices=LOG_TYPE_CHOICES,
        help_text="日志类型"
    )
    details = models.JSONField(
        help_text="日志详细信息，JSON 格式"
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        help_text="日志创建时间"
    )

    def __str__(self):
        return f"{self.user.username} - {self.log_type} ({self.created_at})"


# 聊天会话统计
class ChatStat(models.Model):
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='chat_stats',
        help_text="关联的用户"
    )
    session_id = models.CharField(
        max_length=255,
        help_text="聊天会话 ID"
    )
    start_time = models.DateTimeField(
        help_text="会话开始时间"
    )
    end_time = models.DateTimeField(
        help_text="会话结束时间"
    )
    duration = models.IntegerField(
        help_text="会话时长（秒）"
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        help_text="记录创建时间"
    )

    def __str__(self):
        return f"{self.user.username} - {self.session_id} ({self.duration}s)"


# 交互频率统计
class InteractionStat(models.Model):
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='interaction_stats',
        help_text="关联的用户"
    )
    interaction_type = models.CharField(
        max_length=50,
        help_text="交互类型"
    )
    count = models.IntegerField(
        help_text="交互次数"
    )
    date = models.DateField(
        help_text="统计日期"
    )

    def __str__(self):
        return f"{self.user.username} - {self.interaction_type} ({self.count})"


# 消息处理统计
class MessageStat(models.Model):
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='message_stats',
        help_text="关联的用户"
    )
    message_count = models.IntegerField(
        help_text="消息处理量"
    )
    time_window = models.CharField(
        max_length=50,
        help_text="时间窗口（如 1h、24h）"
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        help_text="记录创建时间"
    )

    def __str__(self):
        return f"{self.user.username} - {self.message_count} messages in {self.time_window}"


# 位置查看记录
class LocationView(models.Model):
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='location_views',
        help_text="关联的用户"
    )
    location = models.CharField(
        max_length=255,
        help_text="查看的位置"
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        help_text="记录创建时间"
    )

    def __str__(self):
        return f"{self.user.username} - {self.location} ({self.created_at})"


# 账户充值记录
class Recharge(models.Model):
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='recharges',
        help_text="关联的用户"
    )
    amount = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        help_text="充值金额"
    )
    invoice_number = models.CharField(
        max_length=50,
        unique=True,
        null=True,
        blank=True,
        help_text="发票号码"
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        help_text="充值时间"
    )

    def __str__(self):
        return f"{self.user.username} - {self.amount} ({self.created_at})"


# 账户消费记录
class Consume(models.Model):
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='consumes',
        help_text="关联的用户"
    )
    amount = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        help_text="消费金额"
    )
    invoice_number = models.CharField(
        max_length=50,
        unique=True,
        null=True,
        blank=True,
        help_text="发票号码"
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        help_text="消费时间"
    )

    def __str__(self):
        return f"{self.user.username} - {self.amount} ({self.created_at})"


# 道具使用记录
class ItemUse(models.Model):
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='item_uses',
        help_text="关联的用户"
    )
    item_name = models.CharField(
        max_length=255,
        help_text="道具名称"
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        help_text="使用时间"
    )

    def __str__(self):
        return f"{self.user.username} - {self.item_name} ({self.created_at})"


# 地理位置上报
class LocationReport(models.Model):
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='location_reports',
        help_text="关联的用户"
    )
    latitude = models.FloatField(
        help_text="纬度"
    )
    longitude = models.FloatField(
        help_text="经度"
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        help_text="上报时间"
    )

    def __str__(self):
        return f"{self.user.username} - ({self.latitude}, {self.longitude}) ({self.created_at})"


# 评价记录
class Feedback(models.Model):
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='feedbacks',
        help_text="关联的用户"
    )
    rating = models.IntegerField(
        help_text="评分"
    )
    comment = models.TextField(
        blank=True,
        null=True,
        help_text="评价内容"
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        help_text="评价时间"
    )

    def __str__(self):
        return f"{self.user.username} - {self.rating} ({self.created_at})"


# 页面停留与在线时长统计
class PageStay(models.Model):
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='page_stays',
        help_text="关联的用户"
    )
    page_url = models.URLField(
        help_text="页面 URL"
    )
    duration = models.IntegerField(
        help_text="停留时长（秒）"
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        help_text="记录创建时间"
    )

    def __str__(self):
        return f"{self.user.username} - {self.page_url} ({self.duration}s)"
