from rest_framework import serializers
from .models import (
    Log, ChatStat, InteractionStat, MessageStat,
    LocationView, Recharge, Consume, ItemUse,
    LocationReport, Feedback, PageStay
)
from user.serializers import UserSerializer


class LogSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)

    class Meta:
        model = Log
        fields = '__all__'


class ChatStatSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)

    class Meta:
        model = ChatStat
        fields = '__all__'


class InteractionStatSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)

    class Meta:
        model = InteractionStat
        fields = '__all__'


class MessageStatSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)

    class Meta:
        model = MessageStat
        fields = '__all__'


class LocationViewSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)

    class Meta:
        model = LocationView
        fields = '__all__'


class RechargeSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)

    class Meta:
        model = Recharge
        fields = '__all__'


class ConsumeSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)

    class Meta:
        model = Consume
        fields = '__all__'


class ItemUseSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)

    class Meta:
        model = ItemUse
        fields = '__all__'


class LocationReportSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)

    class Meta:
        model = LocationReport
        fields = '__all__'


class FeedbackSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)

    class Meta:
        model = Feedback
        fields = '__all__'


class PageStaySerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)

    class Meta:
        model = PageStay
        fields = '__all__'
