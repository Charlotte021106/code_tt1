# -*- coding: utf-8 -*-
"""
@Time ： 2025/3/29 17:07
@Auth ： 九问
@File ：signals.py
@IDE ：PyCharm
@Email : 2750826557@qq.com
"""
from django.db.models import Sum
from django.db.models.signals import post_save
from django.dispatch import receiver
from .models import AdStat, Billing


@receiver(post_save, sender=AdStat)
def update_billing_spent(sender, instance, **kwargs):
    """当 AdStat 更新时，自动更新对应 Billing 的 spent_amount"""
    campaign = instance.placement.campaign
    total_cost = AdStat.objects.filter(
        placement__campaign=campaign
    ).aggregate(total=Sum('cost'))['total'] or 0

    Billing.objects.filter(campaign=campaign).update(spent_amount=total_cost)