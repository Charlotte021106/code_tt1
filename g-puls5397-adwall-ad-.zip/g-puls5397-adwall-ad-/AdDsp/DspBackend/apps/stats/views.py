from decimal import Decimal
from django.db import transaction
from django.db.models import Sum, F, Q
from django.utils import timezone
from rest_framework import viewsets, serializers, status
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.reverse import reverse

from advertising.models import AdPlacement, Campaign
from stats.models import AdStat, Billing
from stats.serializers import AdStatSerializer, BillingSerializer
from utils.permissions import AdvertiserPermissions
from celery_tasks.billing.tasks import check_budget_status


class ManualStatViewSet(viewsets.ModelViewSet):
    serializer_class = AdStatSerializer
    permission_classes = [IsAuthenticated, AdvertiserPermissions]
    http_method_names = ['post']

    def get_queryset(self):
        return AdStat.objects.filter(
            placement__campaign__advertiser=self.request.user
        )

    def create(self, request, *args, **kwargs):
        # 重写create方法返回自定义响应
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    def perform_create(self, serializer):
        with transaction.atomic():
            placement = serializer.validated_data['placement']
            date = serializer.validated_data.get('date', timezone.now().date())
            instance, created = AdStat.objects.get_or_create(
                placement=placement,
                date=date,
                defaults=serializer.validated_data
            )

            if not created:
                # 计算旧的成本
                old_cost = instance.cost

                # 使用原子操作保证并发安全
                AdStat.objects.filter(pk=instance.pk).update(
                    impressions=F('impressions') + serializer.validated_data.get('impressions', 0),
                    clicks=F('clicks') + serializer.validated_data.get('clicks', 0),
                    conversions=F('conversions') + serializer.validated_data.get('conversions', 0)
                )
                instance.refresh_from_db()

                # 计算新的成本
                self._calculate_and_save_cost(instance)
                cost_delta = instance.cost - old_cost

                # 处理账单逻辑
                self._process_billing(instance.placement, cost_delta=cost_delta)
            else:
                # 计算新的成本
                self._calculate_and_save_cost(instance)
                cost_delta = instance.cost

                # 处理账单逻辑
                self._process_billing(instance.placement, cost_delta=cost_delta)

            # 手动构建响应数据
            serializer.instance = instance
            serializer._data = serializer.data  # 手动更新序列化数据

    def _calculate_and_save_cost(self, instance):
        """计算并保存费用到实例"""
        bid_type = instance.placement.bid_type
        bid_amount = instance.placement.bid_amount

        match bid_type:
            case 'CPM':
                instance.cost = (bid_amount * instance.impressions / 1000).quantize(Decimal('0.00'))
            case 'CPC':
                instance.cost = (bid_amount * instance.clicks).quantize(Decimal('0.00'))
            case 'CPA':
                instance.cost = (bid_amount * instance.conversions).quantize(Decimal('0.00'))
            case _:
                instance.cost = Decimal(0)

        instance.save(update_fields=['cost'])

    def _process_billing(self, placement, instance=None, cost_delta=None):
        """统一处理账单逻辑"""
        if isinstance(cost_delta, float):
            cost_delta = Decimal(str(cost_delta))  # 将 float 转为 Decimal
        elif cost_delta is None:
            cost_delta = Decimal(0)

        billing, _ = Billing.objects.get_or_create(
            campaign=placement.campaign,
            defaults={
                'advertiser': placement.campaign.advertiser,
                'total_budget': placement.campaign.budget,
                'spent_amount': Decimal(0),
                'invoice_number': Billing.generate_invoice_number()
            }
        )
        if billing.spent_amount + cost_delta > billing.total_budget:
            raise serializers.ValidationError("操作将导致预算超支")

        billing.spent_amount += cost_delta
        billing.save(update_fields=['spent_amount'])
        check_budget_status.delay(billing.id)


class AdStatViewSet(viewsets.GenericViewSet):
    serializer_class = AdStatSerializer
    permission_classes = [IsAuthenticated, AdvertiserPermissions]

    @action(detail=False, methods=['get'])
    def summary(self, request):
        """
        数据汇总接口
        参数：
        - placement: 必填，广告投放ID
        - start_date: 开始日期（YYYY-MM-DD）
        - end_date: 结束日期（YYYY-MM-DD）
        """
        placement_id = request.query_params.get('placement')
        if not placement_id:
            return Response({"error": "必须提供placement参数"}, status=400)

        try:
            placement = AdPlacement.objects.get(
                id=placement_id,
                campaign__advertiser=request.user
            )
        except AdPlacement.DoesNotExist:
            return Response({"error": "广告投放不存在"}, status=404)

        # 构建查询
        queryset = AdStat.objects.filter(placement=placement)

        # 日期过滤
        start_date = request.query_params.get('start_date')
        end_date = request.query_params.get('end_date')
        if start_date:
            queryset = queryset.filter(date__gte=start_date)
        if end_date:
            queryset = queryset.filter(date__lte=end_date)

        # 聚合计算
        aggregation = queryset.aggregate(
            total_impressions=Sum('impressions', default=0),
            total_clicks=Sum('clicks', default=0),
            total_conversions=Sum('conversions', default=0),
            total_cost=Sum('cost', default=0)
        )

        # 计算CTR
        total_impressions = aggregation['total_impressions']
        ctr = (aggregation['total_clicks'] / total_impressions) if total_impressions > 0 else 0

        # 获取明细数据
        details = queryset.values('date').annotate(
            impressions=Sum('impressions'),
            clicks=Sum('clicks'),
            conversions=Sum('conversions'),
            cost=Sum('cost')
        ).order_by('date')

        # 格式化明细数据
        formatted_details = [
            {
                "date": item["date"].strftime("%Y-%m-%d"),
                "impressions": item["impressions"] or 0,
                "clicks": item["clicks"] or 0,
                "conversions": item["conversions"] or 0,
                "cost": float(item["cost"] or 0)
            }
            for item in details
        ]
        return Response({
            "placement": placement_id,
            "start_date": start_date,
            "end_date": end_date,
            "impressions": aggregation['total_impressions'],
            "clicks": aggregation['total_clicks'],
            "conversions": aggregation['total_conversions'],
            "cost": aggregation['total_cost'],
            "ctr": round(ctr, 4),
            "details": formatted_details
        })

    @action(detail=False, methods=['post'])
    def notify_budget(self, request):
        """
        预算预警通知接口
        参数：
        - campaign_id: 广告活动ID
        """
        campaign_id = request.data.get('campaign_id')
        try:
            campaign = Campaign.objects.get(id=campaign_id, advertiser=request.user)
            billing = Billing.objects.get(campaign=campaign)
        except (Campaign.DoesNotExist, Billing.DoesNotExist):
            return Response({"error": "广告活动不存在"}, status=404)

        utilization = billing.spent_amount / billing.total_budget * 100
        return Response({
            "campaign": campaign.name,
            "spent_amount": billing.spent_amount,
            "total_budget": billing.total_budget,
            "utilization": round(utilization, 2)
        })


class BillingViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = BillingSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        queryset = Billing.objects.filter(
            advertiser=self.request.user
        ).select_related('campaign')

        # 日期过滤参数
        start_date = self.request.query_params.get('start_date')
        end_date = self.request.query_params.get('end_date')
        date_filter = Q()

        if start_date:
            date_filter &= Q(created_at__gte=start_date)
        if end_date:
            date_filter &= Q(created_at__lte=end_date)

        return queryset.filter(date_filter)

    @action(detail=True, methods=['get'])
    def download_invoice(self, request, pk=None):
        """下载链接生成逻辑，真实逻辑待补充"""
        billing = self.get_object()
        return Response({
            "invoice_number": billing.invoice_number,
            # 使用当前视图集自动生成的路由名称
            "download_link": reverse(
                'billing-download-invoice',
                kwargs={'pk': billing.id},
                request=request
            )
        })
