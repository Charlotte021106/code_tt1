import datetime
from decimal import Decimal

from django.db import models, transaction
from django.db.models import F, Max
from django.db.models.functions import Cast, Substr
from rest_framework.exceptions import ValidationError
from rest_framework.fields import IntegerField

from advertising.models import AdPlacement, Campaign
from user.models import User


# 数据统计
class AdStat(models.Model):
    placement = models.ForeignKey(
        AdPlacement,
        on_delete=models.CASCADE,
        related_name='stats',
        help_text="关联的广告投放"
    )
    impressions = models.IntegerField(
        default=0,
        help_text="展示次数"
    )
    clicks = models.IntegerField(
        default=0,
        help_text="点击次数"
    )
    conversions = models.IntegerField(
        default=0,
        help_text="转化次数"
    )
    cost = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=0.00,
        help_text="花费金额"
    )
    date = models.DateField(
        help_text="统计日期"
    )

    def __str__(self):
        return f"{self.placement} - {self.date}"


# 预算与计费
class Billing(models.Model):
    class Meta:
        verbose_name = "广告账单"
        verbose_name_plural = "广告账单"
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['campaign', 'advertiser']),
            models.Index(fields=['spent_amount'])
        ]

    advertiser = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='billing',
        verbose_name="广告主",
        help_text="关联的广告主账户"
    )
    campaign = models.ForeignKey(
        Campaign,
        on_delete=models.CASCADE,
        related_name='billing',
        verbose_name="广告活动",
        help_text="关联的广告活动"
    )
    total_budget = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        verbose_name="总预算",
        help_text="活动的总预算金额（单位：元）"
    )
    spent_amount = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=0.00,
        verbose_name="已消耗金额",
        help_text="已实际花费的金额"
    )
    alert_threshold = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=80.00,
        verbose_name="预警阈值",
        help_text="触发预警的预算百分比（例如80表示80%）"
    )
    is_alert_sent = models.BooleanField(
        default=False,
        verbose_name="已发送预警",
        help_text="是否已发送预算预警通知"
    )
    last_alert_time = models.DateTimeField(
        null=True,
        blank=True,
        verbose_name="最后预警时间",
        help_text="最后一次发送预警的时间"
    )
    invoice_number = models.CharField(
        max_length=50,
        unique=True,
        verbose_name="发票编号",
        help_text="财务系统的唯一发票编号",
        blank=True
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name="创建时间"
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        verbose_name="更新时间"
    )

    def __str__(self):
        return f"{self.campaign.name}账单（剩余：{self.remaining_budget}元）"

    @property
    def remaining_budget(self):
        """实时剩余预算"""
        return self.total_budget - self.spent_amount

    @property
    def utilization_rate(self):
        """预算使用率"""
        return (self.spent_amount / self.total_budget * 100).quantize(Decimal('0.00'))

    def clean(self):
        """数据验证"""
        if self.total_budget <= 0:
            raise ValidationError("总预算必须大于零")
        if self.alert_threshold < 0 or self.alert_threshold > 100:
            raise ValidationError("预警阈值必须在0-100之间")

    def check_budget_status(self):
        """
        预算状态检查（返回状态码和消息）
        返回格式: (status_code, message)
        """
        if self.spent_amount >= self.total_budget:
            return 'exhausted', f"预算已耗尽（总预算：{self.total_budget}元）"

        utilization = self.utilization_rate
        if utilization >= self.alert_threshold:
            return 'warning', f"预算使用已达{utilization}%（阈值：{self.alert_threshold}%）"

        return 'normal', f"预算使用正常（已用：{utilization}%）"

    def add_spending(self, amount):
        """
        安全增加花费金额（原子操作）
        :param amount: 要增加的正数金额
        """
        if amount <= 0:
            raise ValueError("增加金额必须大于零")

        with transaction.atomic():
            # 原子更新
            Billing.objects.filter(pk=self.pk).update(
                spent_amount=F('spent_amount') + amount
            )
            self.refresh_from_db()

    def reset_alert_status(self):
        """重置预警状态"""
        self.is_alert_sent = False
        self.last_alert_time = None
        self.save(update_fields=['is_alert_sent', 'last_alert_time'])

    @classmethod
    def get_campaign_billing(cls, campaign_id):
        """获取广告活动的关联账单"""
        try:
            return cls.objects.select_related('campaign').get(campaign_id=campaign_id)
        except cls.DoesNotExist:
            raise ValueError("未找到该广告活动的账单信息")

    @classmethod
    def get_user_billings(cls, user_id):
        """获取用户的所有账单（按时间倒序）"""
        return cls.objects.filter(advertiser_id=user_id).order_by('-created_at')

    @classmethod
    def generate_invoice_number(cls):
        """生成唯一发票编号（格式：INV+年月日+4位顺序号，如INV20240520-0001）"""
        today = datetime.date.today().strftime("%Y%m%d")

        # 获取当天最大编号（线程安全方式）
        with transaction.atomic():
            # 锁定表避免并发问题
            max_number = cls.objects.select_for_update().filter(
                invoice_number__startswith=f'INV{today}-'
            ).count()

            new_number = max_number + 1
            return f'INV{today}-{new_number:04d}'

    @classmethod
    def create_for_campaign(cls, campaign):
        """为广告活动创建账单（自动生成发票号）"""
        return cls.objects.create(
            campaign=campaign,
            advertiser=campaign.advertiser,
            total_budget=campaign.budget,
            invoice_number=cls.generate_invoice_number()
        )
