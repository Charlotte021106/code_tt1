# -*- coding: utf-8 -*-
"""
@Time ： 2025/3/16 18:53
@Auth ： 九问
@File ：serializers.py
@IDE ：PyCharm
@Email : 2750826557@qq.com
"""
from datetime import timedelta

from django.db.models import Sum
from django.utils import timezone
from rest_framework import serializers

from advertising.models import Campaign
from stats.models import AdStat, Billing


class AdStatSerializer(serializers.ModelSerializer):
    placement_name = serializers.CharField(source='placement.name', read_only=True)
    date = serializers.DateField(
        required=False,
        help_text="统计日期（自动生成）",
        default=timezone.now().date(),
    )

    def validate(self, data):
        # 从请求数据中获取字段值，未提供时使用默认值
        clicks = data.get('clicks', self.fields['clicks'].default)
        conversions = data.get('conversions', self.fields['conversions'].default)
        data = super().validate(data)
        placement = data.get('placement')
        date = data.get('date', timezone.now().date())
        if placement.status == 'PAUSED':
            raise serializers.ValidationError({
                'placement': '广告投放已暂停，无法添加统计数据'
            })

        campaign = placement.campaign
        start_date = campaign.start_date.date()
        end_date = campaign.end_date.date()

        if not (start_date <= date <= end_date):
            raise serializers.ValidationError({
                'date': f'统计日期需在广告活动时间段内 ({start_date} 至 {end_date})'
            })
        # 校验点击量 <= 展示量
        if (impressions := data.get('impressions')) is not None:
            if clicks > impressions:
                raise serializers.ValidationError({
                    'clicks': f'点击量不能超过展示量（当前值：clicks={clicks}, impressions={impressions}）'
                })

        # 新增转化量校验（仅需在创建时校验）
        if conversions > clicks:
            raise serializers.ValidationError({
                'conversions': f'转化量不能超过点击量（当前值：conversions={conversions}, clicks={clicks}）'
            })

        return data

    class Meta:
        model = AdStat
        fields = '__all__'


class BillingSerializer(serializers.ModelSerializer):
    daily_spending = serializers.SerializerMethodField()
    invoice_url = serializers.HyperlinkedIdentityField(
        view_name='billing-download-invoice',
        lookup_field='pk'
    )

    # 显式声明模型中的计算字段
    remaining_budget = serializers.DecimalField(
        max_digits=12,
        decimal_places=2,
        read_only=True
    )
    utilization_rate = serializers.DecimalField(
        max_digits=5,
        decimal_places=2,
        read_only=True
    )

    class Meta:
        model = Billing
        fields = [
            'id',
            'campaign',
            'total_budget',
            'spent_amount',
            'remaining_budget',
            'utilization_rate',
            'alert_threshold',
            'daily_spending',
            'invoice_number',
            'invoice_url'
        ]
        extra_kwargs = {
            'campaign': {'read_only': True},
            'invoice_number': {'read_only': True}
        }

    def get_daily_spending(self, obj):
        """7日消费数据查询"""
        end_date = timezone.now().date()
        start_date = end_date - timedelta(days=6)

        # 使用单个查询聚合数据
        return AdStat.objects.filter(
            placement__campaign=obj.campaign,
            date__range=[start_date, end_date]
        ).values('date').annotate(
            total_cost=Sum('cost')
        ).order_by('date').values('date', 'total_cost')
