# -*- coding: utf-8 -*-
"""
@Time ： 2025/3/16 18:58
@Auth ： 九问
@File ：urls.py
@IDE ：PyCharm
@Email : 2750826557@qq.com
"""
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from stats.views import AdStatViewSet, ManualStatViewSet, BillingViewSet

router = DefaultRouter()

# 注册手动管理接口
router.register(r'manual-stats', ManualStatViewSet, basename='manual-stat')
router.register(r'billings', BillingViewSet, basename='billing')
# 广告统计相关路由
ad_stat_urls = [
    path('summary/', AdStatViewSet.as_view({'get': 'summary'}), name='ad-stat-summary'),
    path('notify-budget/', AdStatViewSet.as_view({'post': 'notify_budget'}), name='budget-notify'),
]

urlpatterns = [
    # 包含基础CRUD路由
    path('', include(router.urls)),
    # 广告统计相关路径
    path('ad-stats/', include(ad_stat_urls)),
]

"""
API接口说明：

1. 广告统计
   - 统计汇总
     * 路径: /stats/ad-stats/summary/
     * 方法: GET
     * 权限: 广告主可查看自己的统计，代理商可查看代理的统计，管理员可查看所有统计
     * 功能: 获取广告效果统计汇总数据

   - 预算通知
     * 路径: /stats/ad-stats/notify-budget/
     * 方法: POST
     * 权限: 系统自动执行
     * 功能: 发送预算超支通知

2. 手动统计管理
   - 统计列表和创建
     * 路径: /stats/manual-stats/
     * 方法: GET, POST
     * 权限: 管理员
     * 功能: 获取手动统计数据列表和创建新统计

   - 统计详情、更新和删除
     * 路径: /stats/manual-stats/<id>/
     * 方法: GET, PUT, DELETE
     * 权限: 管理员
     * 功能: 获取、更新和删除手动统计数据

3. 账单管理
   - 账单列表
     * 路径: /stats/billings/
     * 方法: GET
     * 权限: 广告主可查看自己的账单，代理商可查看代理的账单，管理员可查看所有账单
     * 功能: 获取账单列表

   - 账单详情
     * 路径: /stats/billings/<id>/
     * 方法: GET
     * 权限: 同账单列表
     * 功能: 获取单个账单详情
"""
