from rest_framework import viewsets

from userInsights.models import Hobby, District
from userInsights.serializers import HobbySerializer, DistrictSerializer


class HobbyViewSet(viewsets.ModelViewSet):
    queryset = Hobby.objects.all()
    serializer_class = HobbySerializer


class DistrictViewSet(viewsets.ModelViewSet):
    queryset = District.objects.all()
    serializer_class = DistrictSerializer
