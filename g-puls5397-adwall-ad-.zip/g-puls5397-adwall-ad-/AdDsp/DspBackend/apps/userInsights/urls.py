# -*- coding: utf-8 -*-
"""
@Time ： 2025/3/9 19:46
@Auth ： 九问
@File ：urls.py
@IDE ：PyCharm
@Email : 2750826557@qq.com
"""
from rest_framework.routers import DefaultRouter
from .views import *

urlpatterns = [

]
router = DefaultRouter()
router.register('hobby', HobbyViewSet)
router.register('district', DistrictViewSet)
urlpatterns += router.urls

"""
API接口说明：

1. 兴趣爱好管理
   - 兴趣列表和创建
     * 路径: /insights/hobby/
     * 方法: GET, POST
     * 权限: 管理员
     * 功能: 获取兴趣列表和创建新兴趣

   - 兴趣详情、更新和删除
     * 路径: /insights/hobby/<id>/
     * 方法: GET, PUT, DELETE
     * 权限: 管理员
     * 功能: 获取、更新和删除兴趣信息

2. 地区管理
   - 地区列表和创建
     * 路径: /insights/district/
     * 方法: GET, POST
     * 权限: 管理员
     * 功能: 获取地区列表和创建新地区

   - 地区详情、更新和删除
     * 路径: /insights/district/<id>/
     * 方法: GET, PUT, DELETE
     * 权限: 管理员
     * 功能: 获取、更新和删除地区信息
"""
