# -*- coding: utf-8 -*-
"""
@Time ： 2025/3/9 19:43
@Auth ： 九问
@File ：serializers.py
@IDE ：PyCharm
@Email : 2750826557@qq.com
"""
from rest_framework import serializers

from userInsights.models import Hobby, District


class HobbySerializer(serializers.ModelSerializer):
    class Meta:
        model = Hobby
        fields = '__all__'


class DistrictSerializer(serializers.ModelSerializer):
    city = serializers.CharField(required=False, allow_blank=True)

    class Meta:
        model = District
        fields = '__all__'
