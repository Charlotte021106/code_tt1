from django.db import models


class Hobby(models.Model):
    hobby_tag = models.CharField(max_length=30)

    class Meta:
        verbose_name = '兴趣标签'
        verbose_name_plural = '兴趣标签'

    def __str__(self):
        return self.hobby_tag


class District(models.Model):
    province = models.CharField(max_length=30)
    city = models.CharField(max_length=30)

    class Meta:
        verbose_name = '地域标签'
        verbose_name_plural = '地域标签'

    def __str__(self):
        return f'{self.province} - {self.city}'