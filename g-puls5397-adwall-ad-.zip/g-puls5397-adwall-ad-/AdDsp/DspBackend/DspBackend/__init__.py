import pymysql

pymysql.install_as_MySQLdb()  # 两行代码的作用是在 Django 项目中使用 pymysql 作为 MySQL 数据库的后端驱动，而不是默认的 MySQLdb。
