# -*- coding: utf-8 -*-
"""
@Time ： 2024/7/8 23:08
@Auth ： 九问
@File ：celery_config.py
@IDE ：PyCharm
@Email : 2750826557@qq.com
"""
from config.dbs.redis.redis_dev import LOCATION

# 任务队列 ，保存要执行的任务
broker_url = LOCATION % 3

# 结果队列，保存执行的结果
result_backend = LOCATION % 4
