# -*- coding: utf-8 -*-
"""
@Time ： 2025/3/17 23:40
@Auth ： 九问
@File ：tasks.py
@IDE ：PyCharm
@Email : 2750826557@qq.com
"""
import logging
from django.core.mail import send_mail
from django.db import transaction
from django.core.exceptions import ObjectDoesNotExist
from django.conf import settings
from advertising.models import Campaign
from celery_tasks.celery_main import app
from stats.models import Billing

logger = logging.getLogger(__name__)


@app.task(name='check_budget_status')
def check_budget_status(billing_id):
    """
    预算状态检查任务
    :param billing_id: 账单ID
    """
    try:
        with transaction.atomic():
            billing = Billing.objects.select_for_update().select_related('campaign', 'advertiser').get(pk=billing_id)
            advertiser_email = billing.advertiser.email
            campaign_name = billing.campaign.name

            # 预算耗尽处理
            if billing.spent_amount >= billing.total_budget:
                Campaign.objects.filter(pk=billing.campaign_id).update(status='PAUSED')
                billing.campaign.placements.update(status='PAUSED')

                # 发送预算耗尽通知邮件
                send_notification_email.delay(
                    subject=f"活动【{campaign_name}】预算已耗尽通知",
                    html_content=f"""
                        <h3>您的广告活动已暂停</h3>
                        <p>活动名称：{campaign_name}</p>
                        <p>总预算：¥ {billing.total_budget:.2f}</p>
                        <p>实际消耗：¥ {billing.spent_amount:.2f}</p>
                        <p style="color: #ff4d4f;">该活动预算已耗尽，系统已自动暂停活动及相关广告位。</p>
                    """,
                    recipient=advertiser_email
                )
                logger.info(f"活动 {campaign_name} 因预算耗尽已暂停")

            # 阈值预警处理
            else:
                usage_percent = (billing.spent_amount / billing.total_budget) * 100
                if usage_percent >= 80 and not billing.is_alert_sent:
                    remaining = billing.total_budget - billing.spent_amount

                    # 发送预算预警通知邮件
                    send_notification_email.delay(
                        subject=f"活动【{campaign_name}】预算使用预警（{usage_percent:.0f}%）",
                        html_content=f"""
                            <h3>您的广告活动即将超支</h3>
                            <p>活动名称：{campaign_name}</p>
                            <p>总预算：¥ {billing.total_budget:.2f}</p>
                            <p>已使用：¥ {billing.spent_amount:.2f}（{usage_percent:.0f}%）</p>
                            <p style="color: #faad14;">剩余可用预算：¥ {remaining:.2f}</p>
                        """,
                        recipient=advertiser_email
                    )

                    Billing.objects.filter(pk=billing.pk).update(is_alert_sent=True)
                    logger.warning(f"活动 {campaign_name} 预算预警: 剩余 ¥{remaining:.2f}")

    except ObjectDoesNotExist:
        logger.error(f"账单不存在: billing_id={billing_id}")
    except Exception as e:
        logger.exception(f"预算检查任务异常: {str(e)}")


@app.task(name='send_notification_email')
def send_notification_email(subject, html_content, recipient):
    """
    用通邮件通知任务
    :param subject: 邮件主题
    :param html_content: HTML内容
    :param recipient: 收件人
    """
    try:
        # 发送带HTML内容的邮件
        send_mail(
            subject=subject,
            message='',  # 纯文本内容留空，使用html_message
            from_email=settings.EMAIL_HOST_USER,
            recipient_list=[recipient],
            html_message=html_content
        )
        logger.info(f"邮件发送成功: {recipient} | 主题: {subject}")
    except Exception as e:
        logger.error(f"邮件发送失败: {recipient} | 错误: {str(e)}")
