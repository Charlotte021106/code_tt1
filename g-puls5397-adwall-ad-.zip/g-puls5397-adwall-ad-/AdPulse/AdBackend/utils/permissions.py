# -*- coding: utf-8 -*-
"""
@Time ： 2024/7/7 17:03
@Auth ： 九问
@File ：permissions.py
@IDE ：PyCharm
@Email : 2750826557@qq.com
"""
from rest_framework.permissions import IsAuthenticated, BasePermission


# 用户登录权限
class UserLoginPermissions(IsAuthenticated):
    pass


# 管理员权限
class AdministratorsPermission(BasePermission):
    def has_permission(self, request, view):
        user = request.user
        return user.is_superuser  # 检测为superuser才能通过


class TeacherPermission(BasePermission):
    def has_permission(self, request, view):
        user = request.user
        return user.is_staff or user.is_superuser


class AutoUserPermission(BasePermission):
    def has_permission(self, request, view):
        print(view, request.user.id)
        try:
            data = view.get_queryset().get(id=view.kwargs['pk'], user_id=request.user.id)
        except:
            return False
        return True
