# -*- coding: utf-8 -*-
"""
@Time ： 2024/7/7 17:00
@Auth ： 九问
@File ：filters.py
@IDE ：PyCharm
@Email : 2750826557@qq.com
"""
from rest_framework.pagination import PageNumberPagination

from django_filters import rest_framework as filters  # https://blog.csdn.net/weixin_51715424/article/details/134710767

from adserver.models import AdPlan, AdUnit, AdCreative


class MyPageNumberPagination(PageNumberPagination):
    page_size = 10  # 默认每页多少条
    page_size_query_param = 'size'  # 规定哪个参数为分页大小参数 size = 10
    max_page_size = 100  # 最大每页多少条


class AdPlanFilter(filters.FilterSet):
    order_by = filters.CharFilter(method='filter_order_by')

    class Meta:
        model = AdPlan
        fields = ['name', 'status', 'create_time', 'budget']

    def filter_order_by(self, queryset, name, value):
        if value:
            if value == 'create_time':
                return queryset.order_by('-create_time')  # 按创建时间降序排列
            elif value == 'budget':
                return queryset.order_by('-budget')  # 按预算升序排列
            elif value == 'status':
                return queryset.order_by('status')  # 按状态升序排列
            else:
                return queryset.order_by('name')  # 默认按名称升序排列
        return queryset


class AdUnitFilter(filters.FilterSet):
    order_by = filters.CharFilter(method='filter_order_by')
    unit_name = filters.CharFilter(lookup_expr='icontains')  # 模糊查询广告单元名称
    unit_status = filters.ChoiceFilter(choices=AdUnit.UNIT_STATUS_CHOICES)  # 状态过滤
    position_type = filters.ChoiceFilter(choices=AdUnit.POSITION_TYPE_CHOICES)  # 广告位类型过滤

    class Meta:
        model = AdUnit
        fields = ['unit_name', 'unit_status', 'position_type']

    def filter_order_by(self, queryset, name, value):
        """
        根据传入的 `order_by` 参数进行排序
        """
        if value:
            if value == 'unit_name':
                return queryset.order_by('unit_name')  # 按广告单元名称升序排列
            elif value == 'unit_status':
                return queryset.order_by('unit_status')  # 按状态升序排列
            elif value == 'position_type':
                return queryset.order_by('position_type')  # 按广告位类型升序排列
            elif value == 'budget_fee':
                return queryset.order_by('-budget_fee')
            elif value == 'create_time':
                return queryset.order_by('-create_time')
            elif value == 'ad_plan_name':
                return queryset.order_by('plan__name')  # 使用关联表的字段排序
            else:
                return queryset.order_by('-budget_fee')
        return queryset


class AdCreativeFilter(filters.FilterSet):
    order_by = filters.CharFilter(method='filter_order_by')
    name = filters.CharFilter(lookup_expr='icontains')  # 模糊查询创意名称
    creative_type = filters.ChoiceFilter(choices=AdCreative.CREATIVE_TYPE_CHOICES)  # 创意类型过滤
    material_type = filters.ChoiceFilter(choices=AdCreative.MATERIAL_TYPE_CHOICES)  # 物料类型过滤
    audit_status = filters.NumberFilter()  # 审核状态过滤
    user = filters.NumberFilter(field_name='user__id')  # 创建者用户ID过滤

    class Meta:
        model = AdCreative
        fields = ['name', 'creative_type', 'material_type', 'audit_status', 'user']

    def filter_order_by(self, queryset, name, value):
        """
        根据传入的 `order_by` 参数进行排序
        """
        if value:
            if value == 'name':
                return queryset.order_by('name')  # 按创意名称升序排列
            elif value == 'creative_type':
                return queryset.order_by('creative_type')  # 按创意类型升序排列
            elif value == 'material_type':
                return queryset.order_by('material_type')  # 按物料类型升序排列
            elif value == 'audit_status':
                return queryset.order_by('audit_status')  # 按审核状态升序排列
            elif value == 'height':
                return queryset.order_by('height')  # 按高度升序排列
            elif value == 'width':
                return queryset.order_by('width')  # 按宽度升序排列
            elif value == 'size':
                return queryset.order_by('size')  # 按物料大小升序排列
            elif value == 'duration':
                return queryset.order_by('duration')  # 按持续时长升序排列
            elif value == 'create_time':
                return queryset.order_by('-create_time')  # 按创建时间降序排列
            elif value == 'update_time':
                return queryset.order_by('-update_time')  # 按修改时间降序排列
            else:
                return queryset.order_by('name')  # 默认按创意名称升序排列
        return queryset
