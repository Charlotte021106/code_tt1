# -*- coding: utf-8 -*-
"""
@Time ： 2025/1/24 11:00
@Auth ： 九问
@File ：__init__.py
@IDE ：PyCharm
@Email : 2750826557@qq.com
"""
from django.db import models


class DateTimeModelMixin(models.Model):
    """
    创建和修改时间模型扩展类
    """
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    update_time = models.DateTimeField(auto_now=True, verbose_name='修改时间')

    class Meta:
        # 指定该类是抽象模型类，迁移映射的时候不会创建对应的表，只是用于封装扩展
        abstract = True


class IsDeleteModelMixin(models.Model):
    """
    逻辑删除模型扩展类
    """
    is_delete = models.BooleanField(default=False, verbose_name='逻辑删除')

    def delete(self, using=None, keep_parents=False):
        self.is_delete = True
        self.save()

    class Meta:
        # 指定该类是抽象模型类，迁移映射的时候不会创建对应的表，只是用于封装扩展
        abstract = True


class ModelSetMixin(DateTimeModelMixin, IsDeleteModelMixin):
    """
      模型扩展整合类
    """

    class Meta:
        abstract = True
