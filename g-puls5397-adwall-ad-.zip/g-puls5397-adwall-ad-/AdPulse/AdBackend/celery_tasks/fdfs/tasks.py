# -*- coding: utf-8 -*-
"""
@Time ： 2024/7/8 23:17
@Auth ： 九问
@File ：tasks.py
@IDE ：PyCharm
@Email : 2750826557@qq.com
"""
import logging

from celery_tasks.celery_main import app

from AdBackend.settings import file

logger = logging.getLogger(__name__)

from fdfs_client.client import Fdfs_client, get_tracker_conf


@app.task(name='remove_fdfs_resources')
def remove_fdfs_resources(img_url):
    tracker_path = get_tracker_conf(file)
    client = Fdfs_client(tracker_path)
    byte_data = img_url.encode('utf-8')
    try:
        client.delete_file(remote_file_id=byte_data)
    except:
        logger.warning("文件不存在,请立即确认是否已清除!")
    else:
        logger.info('文件清除成功!')
