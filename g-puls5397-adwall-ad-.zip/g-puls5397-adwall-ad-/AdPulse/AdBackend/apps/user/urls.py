# -*- coding: utf-8 -*-
"""
@Time ： 2024/7/5 17:06
@Auth ： 九问
@File ：urls.py
@IDE ：PyCharm
@Email : 2750826557@qq.com
"""
from django.urls import path
from rest_framework.routers import DefaultRouter

from .views import *

urlpatterns = [
    path("register/", RegisterGenericViewSet.as_view({"post": "create"})),
    path('login/', LoginGenericViewSet.as_view()),
    path('api/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),  # jwtToken获取
]

router = DefaultRouter()
router.register('group',GroupViewSet)
urlpatterns += router.urls
