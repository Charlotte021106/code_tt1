# from django.contrib.auth.models import User
# from django.db import models

# from utils.ModelSetMixin import ModelSetMixin
#
#
# # Create your models here.
# class UserDetail(ModelSetMixin):
#     SEX_CHOICES = (
#         (0, '女'),
#         (1, '男'),
#     )
#
#     POSITION_CHOICES = (
#         (0, '校长'),
#         (1, '教导主任'),
#         (2, '普通老师'),
#         (3, '班主任'),
#     )
#     avatar = models.TextField(null=True, blank=True, verbose_name='头像', help_text='头像')
#     mobile = models.CharField(null=True, blank=True, verbose_name='手机号码', max_length=11, unique=True,
#                               help_text='手机号码')
#     position = models.IntegerField(null=True, blank=True, verbose_name='职位', choices=POSITION_CHOICES,
#                                    help_text='职位')
#     age = models.IntegerField(null=True, blank=True, verbose_name='年龄', help_text='年龄')
#     sex = models.IntegerField(null=True, blank=True, verbose_name='性别', choices=SEX_CHOICES, help_text='性别')
#     birthday = models.DateField(null=True, blank=True, verbose_name='生日', help_text='生日')
#     address = models.CharField(null=True, blank=True, verbose_name='联系地址', max_length=100, help_text='联系地址')
#     synopsis = models.TextField(null=True, blank=True, verbose_name='简介', help_text='简介')
#     user = models.OneToOneField(User, on_delete=models.DO_NOTHING, verbose_name='用户', help_text='用户')
#
#     class Meta:
#         db_table = 'userdetail'
#         verbose_name = '用户详情'
#         verbose_name_plural = verbose_name

