# -*- coding: utf-8 -*-
"""
@Time ： 2025/1/24 17:38
@Auth ： 九问
@File ：urls.py
@IDE ：PyCharm
@Email : 2750826557@qq.com
"""

from rest_framework.routers import DefaultRouter

from .views import *

urlpatterns = [

]

router = DefaultRouter()
router.register('plan', AdPlanViewSet)
router.register('unit',AdUnitViewSet)
router.register('creative',AdCreativeViewSet)
router.register('unitcreative',AdUnitCreativeViewSet)
urlpatterns += router.urls
