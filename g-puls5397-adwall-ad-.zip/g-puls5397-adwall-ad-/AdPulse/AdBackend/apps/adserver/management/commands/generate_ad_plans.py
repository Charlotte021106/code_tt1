# -*- coding: utf-8 -*-
"""
@Time ： 2025/1/26 10:39
@Auth ： 九问
@File ：generate_ad_plans.py
@IDE ：PyCharm
@Email : 2750826557@qq.com
"""
import time

from django.core.management.base import BaseCommand
from faker import Faker
from django.contrib.auth.models import User
from adserver.models import AdPlan
import random


class Command(BaseCommand):
    help = 'Generate test data for AdPlan'

    def handle(self, *args, **kwargs):
        fake = Faker('zh-CN')

        users = []
        for _ in range(10):  # 生成10个用户，可以根据需要调整数量
            user = User.objects.create_user(
                username=fake.user_name(),
                email=fake.email(),
                password='qwe123',
                first_name=fake.name()
            )
            users.append(user)
        plan_names = [
            "双11爆单冲刺计划",
            "暑期清凉季营销",
            "开学季促销活动",
            "春节团圆红包计划",
            "618年中大促",
            "年末感恩回馈",
            "新品上市推广",
            "会员专属福利",
            "品牌形象升级",
            "本地商家引流",
            "双12年终盛典",
            "99划算节流量收割",
            "超级品牌日全域曝光",
            "国庆黄金周抢客行动",
            "情人节甜蜜经济计划",
            "3.8女神节专属战役",
            "中秋团圆季品效合一",
            "Z世代破圈渗透计划",
            "宝妈社群唤醒行动",
            "银发族关怀营销计划",
            "新车主精准转化战役",
            "爆款单品打榜计划",
            "清库存闪电促销",
            "高端系列心智占领",
            "同城夜市狂欢节",
            "社区团购闪电战",
            "地标商圈打卡引流",
            "沉睡用户激活计划",
            "SVIP尊享裂变",
            "积分兑换促活行动",
            "品牌年轻化焕新行动",
            "ESG社会责任传播",
            "品牌跨界联名计划",
            "世界杯主题营销",
            "明星同款种草计划",
            "网红打卡地标联动",
            "AR试妆体验推广",
            "智能客服转化优化",
            "LBS周边辐射计划",
            "黑色星期五海购节",
            "直播带货巅峰战",
            "校园迎新特惠季",
            "企业采购节专项",
            "健康养生季推广",
            "宠物经济生态计划",
            "智能家居体验官",
            "跨境购物流量池",
            "老客复购唤醒计划",
            "新客首单裂变计划",
            "短视频挑战赛引爆"
        ]
        for _ in range(50):  # 生成50个广告计划
            user = random.choice(users)  # 随机选择一个用户
            name = random.choice(plan_names)
            budget = random.randint(10000, 100000)
            status = random.choice(['active', 'inactive'])  # 随机状态

            AdPlan.objects.create(
                user=user,
                name=name,
                budget=budget,
                status=status
            )
            time.sleep(0.5)
        self.stdout.write(self.style.SUCCESS('Successfully generated test data!'))
