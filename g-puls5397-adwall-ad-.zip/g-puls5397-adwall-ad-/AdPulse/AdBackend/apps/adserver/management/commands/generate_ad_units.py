# -*- coding: utf-8 -*-
"""
@Time ： 2025/1/26 13:26
@Auth ： 九问
@File ：generate_ad_units.py
@IDE ：PyCharm
@Email : 2750826557@qq.com
"""
import time

from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from adserver.models import AdPlan, AdUnit, AdUnitDistrict, AdUnitHobby
import random


class Command(BaseCommand):
    help = 'Generate test data for AdUnit, AdUnitDistrict, AdUnitHobby'

    def handle(self, *args, **kwargs):
        hobbies = [
            '健身运动', '科技数码', '母婴育儿', '美妆护肤', '股票投资',
            '在线教育', '出境旅游', '烘焙料理', '新能源汽车', '中医养生',
            '宠物饲养', '电竞游戏', '摄影摄像', '家居装修', '奢侈品',
            '短视频创作', '户外探险', '二手交易', '区块链', '动漫文化'
        ]
        for tag in hobbies:
            AdUnitHobby.objects.get_or_create(hobby_tag=tag)

        province_cities = {
            '北京': ['朝阳区', '海淀区', '东城区', '西城区', '丰台区'],
            '上海': ['浦东新区', '徐汇区', '静安区', '黄浦区', '长宁区'],
            '天津': ['和平区', '河西区', '南开区', '河北区', '滨海新区'],
            '重庆': ['渝中区', '江北区', '南岸区', '沙坪坝区', '九龙坡区'],
            '江苏': ['南京', '苏州', '无锡', '常州', '徐州', '扬州'],
            '浙江': ['杭州', '宁波', '温州', '绍兴', '嘉兴', '金华'],
            '广东': ['广州', '深圳', '佛山', '东莞', '中山', '珠海']
        }
        for province, areas in province_cities.items():
            for area in areas:
                AdUnitDistrict.objects.get_or_create(
                    province=province,
                    city=area if province in ['北京', '上海', '天津', '重庆'] else ''
                )

        users = User.objects.all()
        ad_plans = AdPlan.objects.all()
        all_hobbies = list(AdUnitHobby.objects.all())
        all_districts = list(AdUnitDistrict.objects.all())

        if not users:
            self.stdout.write(self.style.ERROR('No users found in the database. Please create users first.'))
            return

        if not ad_plans:
            self.stdout.write(self.style.ERROR('No AdPlans found in the database. Please generate AdPlans first.'))
            return
        unit_names = [
            "首页信息流广告位",
            "详情页底部通栏广告",
            "APP启动页全屏广告",
            "搜索结果列表广告位",
            "视频前贴片15秒广告",
            "个人中心悬浮按钮广告",
            "商品分类页轮播广告",
            "支付完成页弹窗广告",
            "消息中心信息流广告",
            "购物车推荐广告位",
            "会员专享横幅广告",
            "游戏试玩互动广告",
            "短视频信息流第三坑位",
            "直播间礼物挂件广告",
            "电子书翻页插页广告",
            "音乐播放器音视频广告",
            "地图导航POI标注广告",
            "天气页面底部横幅广告",
            "新闻详情页信息流广告",
            "相机AR特效植入广告",
            "输入法皮肤推荐广告",
            "WiFi连接成功页广告",
            "抽奖活动浮层广告位",
            "智能推荐信息流广告",
            "桌面小部件动态广告"
        ]
        for _ in range(50):  # 生成50个广告单元
            ad_plan = random.choice(ad_plans)
            unit_name = random.choice(unit_names)
            position_type = random.choice([0, 1, 2, 3, 4])
            unit_status = random.choice([0, 1])
            budget_fee = random.randint(100, 10000)

            ad_unit = AdUnit.objects.create(
                plan=ad_plan,
                unit_name=unit_name,
                unit_status=unit_status,
                position_type=position_type,
                budget_fee=budget_fee
            )
            ad_unit.hobbies.set(random.sample(all_hobbies, k=random.randint(1, 3)))
            selected_districts = []
            for _ in range(random.randint(2,5)):
                province = random.choice(list(province_cities.keys()))
                area = random.choice(province_cities[province])
                district = AdUnitDistrict.objects.get(
                    province=province,
                    city=area if province in ['北京','上海','天津','重庆'] else '',
                )
                selected_districts.append(district)
            ad_unit.districts.set(list(set(selected_districts)))
            time.sleep(0.5)
        self.stdout.write(
            self.style.SUCCESS('Successfully generated test data for AdUnit, AdUnitDistrict, AdUnitHobby!'))
