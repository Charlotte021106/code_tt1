# -*- coding: utf-8 -*-
"""
@Time ： 2025/2/10 19:48
@Auth ： 九问
@File ：serializers.py
@IDE ：PyCharm
@Email : 2750826557@qq.com
"""
from rest_framework import serializers
from .models import UserFeedback, AdClick
from adserver.models import AdUnitHobby, AdUnitDistrict


class AdUnitHobbySerializer(serializers.ModelSerializer):
    class Meta:
        model = AdUnitHobby
        fields = '__all__'


class AdUnitDistrictSerializer(serializers.ModelSerializer):
    city = serializers.CharField(required=False, allow_blank=True)

    class Meta:
        model = AdUnitDistrict
        fields = '__all__'


class UserFeedbackSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserFeedback
        fields = ['id', 'user', 'ad_unit', 'feedback', 'timestamp']


class AdClickSerializer(serializers.ModelSerializer):
    class Meta:
        model = AdClick
        fields = ['id', 'user', 'ad_unit', 'timestamp']
