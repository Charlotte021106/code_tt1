# -*- coding: utf-8 -*-
"""
@Time ： 2025/1/24 17:38
@Auth ： 九问
@File ：urls.py
@IDE ：PyCharm
@Email : 2750826557@qq.com
"""
from django.urls import path
from rest_framework.routers import DefaultRouter
from .views import *

urlpatterns = [
    path('adsearch/', AdSearchView.as_view(), name='adsearch'),  # 广告检索
    path('feedback/', UserFeedbackView.as_view(), name='user-feedback'),  # 用户反馈
    path('click/', AdClickView.as_view(), name='ad-click'),  # 广告点击
]
router = DefaultRouter()
router.register('hobby',HobbyViewSet)
router.register('district',DistrictViewSet)
urlpatterns += router.urls