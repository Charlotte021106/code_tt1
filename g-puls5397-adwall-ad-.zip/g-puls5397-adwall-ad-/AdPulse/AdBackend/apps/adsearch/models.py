from django.db import models
from django.contrib.auth.models import User

from adserver.models import AdUnit


class UserFeedback(models.Model):
    FEEDBACK_CHOICES = [
        ('like', 'Like'),
        ('dislike', 'Dislike'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE)  # 关联用户
    ad_unit = models.ForeignKey(AdUnit, on_delete=models.CASCADE)  # 关联广告单元
    feedback = models.CharField(max_length=10, choices=FEEDBACK_CHOICES)  # 用户反馈
    comment = models.TextField(blank=True, null=True)  # 用户评论，允许为空
    timestamp = models.DateTimeField(auto_now_add=True)  # 反馈时间

    class Meta:
        verbose_name = '用户反馈'
        verbose_name_plural = '用户反馈'
        app_label = 'adsearch'

    def __str__(self):
        return f'{self.user.username} - {self.ad_unit.unit_name} - {self.feedback}'


class AdClick(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)  # 关联用户
    ad_unit = models.ForeignKey(AdUnit, on_delete=models.CASCADE)  # 关联广告单元
    timestamp = models.DateTimeField(auto_now_add=True)  # 点击时间

    class Meta:
        verbose_name = '广告点击记录'
        verbose_name_plural = '广告点击记录'
        app_label = 'adsearch'

    def __str__(self):
        return f'{self.user.username} - {self.ad_unit.unit_name}'
