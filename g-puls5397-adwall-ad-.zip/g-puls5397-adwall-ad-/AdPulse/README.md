

# AdPulse

> CODING TEST：偏广告业务
> （以目前自己掌握的工程实践完成）
> 请用python或其他语言实现一个小型的广告投放检索系统（adserver+adsearch）其中adserver主要包括创建广告计划 ，广告单元,广告创意等
> Adsearch主要功能包括兴趣标签检索和自动排序，前端主要实现：展示广告，收集记录用户对广告的反馈（可以自定义一些动作行为：如喜欢/讨厌）
>
> 参考资源与DB：https://github.com/Isaac-Zhang/mscx-ad/blob/master/mscx-ad-db/src/main/resources/db/migration/V1__CREATE_NEW_DATABASE_AD.sql

|              |                                  |      |
| ------------ | -------------------------------- | ---- |
| 项目预览地址 | http://116.62.230.206:5000/      |      |
| 后端接口     | http://116.62.230.206:9001/      |      |
| 接口文档     | http://116.62.230.206:9001/docs/ |      |

##  1.相关技术

### 1.1 后端(Python DRF)


| 名称 | Python  | Django | djangorestframework | rest_framework_simplejwt | pymysql | coreapi | Faker  | celery | py3Fdfs |
| ---- | ------- | ------ | ------------------- | ------------------------ | ------- | ------- | ------ | ------ | ------- |
| 版本 | 3.10.12 | 5.1.5  | 3.15.2              | 5.4.0                    | 1.1.1   | 2.3.3   | 35.0.0 | 5.4.0  | 2.2.0   |

### 1.2 前端(Vue3)

#### 1.2.1 核心框架

| 名称 | Vue    | Element Plus | Pinia | Vue Router | Axios |
| ---- | ------ | ------------ | ----- | ---------- | ----- |
| 版本 | 3.5.13 | 2.9.3        | 2.3.1 | 4.5.0      | 1.7.9 |

#### 1.2.2 辅助工具

| 名称                        | 功能说明           | 版本  |
| --------------------------- | ------------------ | ----- |
| nprogress                   | 页面加载进度条     | 0.2.0 |
| pinia-plugin-persistedstate | 状态持久化插件     | 4.2.0 |
| @element-plus/icons-vue     | Element Plus图标库 | 2.3.1 |

#### 1.2.3 构建工具链

| 名称 | Vite  | @vitejs/plugin-vue | Less  |
| ---- | ----- | ------------------ | ----- |
| 版本 | 6.0.5 | 5.2.1              | 4.2.2 |

### 1.3 数据库

仅mysql

超级管理员账号

| 账号 | jiuwen |
| ---- | ------ |
| 密码 | qwe123 |

## 2.项目初始化

### 2.1 后端环境搭建

#### 2.1.1 数据库(mysql)配置

1. Mysql数据库配置文件

```cnf
[client]
database = Ad
user = root
password = admin.123
host = 116.62.230.206
port = 3307
default-character-set = utf8
```

2. 在主项目的 `__init__.py` 文件中加入 `import pymysql` 和 `pymysql.install_as_MySQLdb()` 在使用 Django 项目时，将 pymysql 作为 MySQL 数据库的后端驱动。

```python
import pymysql
pymysql.install_as_MySQLdb()  # 两行代码的作用是在 Django 项目中使用 pymysql 作为 MySQL 数据库的后端驱动，而不是默认的 MySQLdb。
```

#### 2.1.2 配置系统文件(settings.py)

1. 在根目录下创建apps目录,并在系统文件导入

```
import os
import sys
sys.path.insert(1,os.path.join(BASE_DIR,'apps'))
```

2. 中文显示、时区等：

```django
LANGUAGE_CODE = 'zh-hans'

TIME_ZONE = 'Asia/Shanghai'

USE_I18N = True

USE_L10N = True

USE_TZ = False
```

3. 导入rest_framework框架

`````python
INSTALLED_APPS = [
    "rest_framework",
]
`````

6. 配置日志系统

````django
# 日志系统
LOGGING = {
    # 版本
    'version': 1,
    # 是否禁用已存在的日志器
    'disable_existing_loggers': False,
    'formatters': {
        'verbose': {
            'format': '%(levelname)s %(asctime)s %(module)s %(lineno)d %(message)s'
        },
        'simple': {
            'format': '%(levelname)s %(module)s %(lineno)d %(message)s'
        },
    },
    'filters': {
        'require_debug_true': {
            '()': 'django.utils.log.RequireDebugTrue',
        },
    },
    'handlers': {
        'console': {
            'level': 'DEBUG',
            'filters': ['require_debug_true'],
            'class': 'logging.StreamHandler',
            'formatter': 'simple'
        },
        'file': {
            'level': 'INFO',
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': os.path.join(BASE_DIR, "config/logs/AdBackend.log"),  # 日志文件的位置
            'maxBytes': 300 * 1024 * 1024,
            'backupCount': 10,
            'formatter': 'verbose'
        },
    },
    'loggers': {
        'django': {  # 定义了一个名为django的日志器
            'handlers': ['console', 'file'],
            'propagate': True,
            'level': 'INFO',  # 日志器接收的最低日志级别
        },
    }
}

````

7. 配置DRF限流，以及用户认证，以及默认API文档

``````
# 修改DRF认证等
REST_FRAMEWORK = {
    # 限流
    'DEFAULT_THROTTLE_CLASSES': [
        'rest_framework.throttling.AnonRateThrottle',
        'rest_framework.throttling.UserRateThrottle'
    ],
    # 限流
    'DEFAULT_THROTTLE_RATES': {
        'anon': '3/second',
        'user': '10/second'
    },
    'DEFAULT_AUTHENTICATION_CLASSES': [
        'rest_framework_simplejwt.authentication.JWTAuthentication',  # 使用rest_framework_simplejwt(token)验证身份
        'rest_framework.authentication.SessionAuthentication',  # 基于用户名密码认证方式
        'rest_framework.authentication.BasicAuthentication'  # 基于Session认证方式
    ],
    'DEFAULT_PERMISSION_CLASSES': [
        # 'rest_framework.permissions.IsAuthenticated'  # 默认权限类的配置,不用这个，注释掉！！
    ],
    'DEFAULT_SCHEMA_CLASS': 'rest_framework.schemas.coreapi.AutoSchema',  # 使用AutoSchema自动生成API文档的模式。
}

``````

### 2.2 前端环境搭建

1. 使用vite创建项目及打包项目

   ```shell
    npm create vite@latest
   ```

2. vite.config.js配置后端接口及Fastdfs服务器及其他。

   ```js
   import { defineConfig } from 'vite'
   import vue from '@vitejs/plugin-vue'
   import path from 'path'
   export default defineConfig({
     // base:"/static",
     plugins: [vue()],
     resolve: {
       alias: {
         // 设置别名 这里的./指的是 vite.config.js 的所载目录（根目录）下面的 src
         '@': path.resolve(__dirname, './src')//__dirname用来表示当前执行脚本所在的目录的绝对路径
       },
       //extensions数组的意思是在import组件的时候自动补全.vue等文件后缀
       extensions: ['.mjs', '.js', '.ts', '.jsx', '.tsx', '.json', '.vue']
     },
     server: {
       // open: true,
       host: '127.0.0.1',
       port: 4000,
       proxy: {
         '/api': {
           target: 'http://116.62.230.206:8080',
           ws: true,
           changeOrigin: true,
           rewrite: path => path.replace(/^\/api/, '')
         },
         '/aps': {
           target: 'http://116.62.230.206:8888',
           ws: true,
           changeOrigin: true,
           rewrite: path => path.replace(/^\/aps/, '')
         },
       }
     },
   })
   ```

3. ```shell
   npm i 下载依赖包
   npm run dev   启动服务
   ```

## 3. 数据库模型

### 3.1 **adserver**

#### **AdPlan**（推广计划表）

- **作用**：表示广告投放计划。
- **字段**：
  - `user`: 外键，关联 `User` 模型，表示该广告计划属于哪个用户。用户被删除时，所有相关广告计划也会被删除。
  - `name`: 广告计划的名称，最大长度为 255 个字符。
  - `budget`: 广告计划的预算，使用 `DecimalField` 存储，最大位数为 10，小数位数为 2。
  - `status`: 广告计划的状态，可选值为 `active`（进行中）或 `inactive`（暂停）。
  - `create_time`: 广告计划的创建时间，自动记录。
  - `update_time`: 广告计划的最后修改时间，自动更新。

- **model**：
  
  ```python
  class AdPlan(models.Model):
      user = models.ForeignKey(User, related_name='ad_plans', on_delete=models.CASCADE)
      name = models.CharField(max_length=255)
      budget = models.DecimalField(max_digits=10, decimal_places=2)
      status = models.CharField(max_length=50, choices=[('active', 'Active'), ('inactive', 'Inactive')])
      create_time = models.DateTimeField(auto_now_add=True)
      update_time = models.DateTimeField(auto_now=True)
  
      def __str__(self):
          return self.name
  ```

---

#### **AdUnitHobby**（推广单元兴趣标签表）

- **作用**：表示广告单元的兴趣标签。
- **字段**：
  - `hobby_tag`: 兴趣标签，最大长度为 30 个字符。

- **model**：
  ```python
  class AdUnitHobby(models.Model):
      hobby_tag = models.CharField(max_length=30)
  
      class Meta:
          verbose_name = '推广单元兴趣标签'
          verbose_name_plural = '推广单元兴趣标签'
  
      def __str__(self):
          return self.hobby_tag
  ```

---

#### **AdUnitDistrict**（推广单元地域标签表）

- **作用**：表示广告单元的地域定向信息。
- **字段**：
  - `province`: 省份信息，最大长度为 30 个字符。
  - `city`: 城市信息，最大长度为 30 个字符。

- **model**：
  ```python
  class AdUnitDistrict(models.Model):
      province = models.CharField(max_length=30)
      city = models.CharField(max_length=30)
  
      class Meta:
          verbose_name = '推广单元地域标签'
          verbose_name_plural = '推广单元地域标签'
  
      def __str__(self):
          return f'{self.province} - {self.city}'
  ```

---

#### **AdUnit**（广告单元表）

- **作用**：表示广告计划中的具体广告单元。
- **字段**：
  - `unit_id`: 主键，广告单元的唯一标识符。
  - `plan`: 外键，关联 `AdPlan` 模型，表示该广告单元属于哪个广告计划。
  - `unit_name`: 广告单元的名称，最大长度为 48 个字符。
  - `unit_status`: 广告单元的状态，可选值为 `0`（未启用）或 `1`（启用）。
  - `position_type`: 广告位置类型，可选值为 `0`（开屏）、`1`（贴片）、`2`（中贴）、`3`（暂停贴）、`4`（后贴）。
  - `budget_fee`: 广告单元的预算费用，使用 `DecimalField` 存储，最大位数为 18，小数位数为 4。
  - `create_time`: 广告单元的创建时间，自动记录。
  - `update_time`: 广告单元的最后修改时间，自动更新。
  - `hobbies`: 多对多关系，关联 `AdUnitHobby` 模型，表示广告单元的兴趣标签。
  - `districts`: 多对多关系，关联 `AdUnitDistrict` 模型，表示广告单元的地域标签。

- **model**：
  ```python
  class AdUnit(models.Model):
      POSITION_TYPE_CHOICES = [
          (0, '开屏'),
          (1, '贴片'),
          (2, '中贴'),
          (3, '暂停贴'),
          (4, '后贴')
      ]
  
      UNIT_STATUS_CHOICES = [
          (0, '未启用'),
          (1, '启用')
      ]
  
      unit_id = models.BigAutoField(primary_key=True)
      plan = models.ForeignKey(AdPlan, related_name='ad_units', on_delete=models.CASCADE)
      unit_name = models.CharField(max_length=48)
      unit_status = models.SmallIntegerField(choices=UNIT_STATUS_CHOICES, default=0)
      position_type = models.SmallIntegerField(choices=POSITION_TYPE_CHOICES, default=0)
      budget_fee = models.DecimalField(max_digits=18, decimal_places=4)
      create_time = models.DateTimeField(auto_now_add=True)
      update_time = models.DateTimeField(auto_now=True)
  
      hobbies = models.ManyToManyField(AdUnitHobby, related_name='ad_units', blank=True)
      districts = models.ManyToManyField(AdUnitDistrict, related_name='ad_units', blank=True)
  
      def __str__(self):
          return self.unit_name
  ```

---

#### **AdCreative**（创意表）

- **作用**：表示广告的创意内容，可以是图片、视频等形式。
- **字段**：
  - `creative_id`: 主键，创意的唯一标识符。
  - `name`: 创意的名称，最大长度为 48 个字符。
  - `creative_type`: 创意的类型，可选值为 `0`（图片）或 `1`（视频）。
  - `material_type`: 物料类型，可选值为 `0`（BMP）、`1`（JPG）、`2`（PNG）、`3`（MP4）、`4`（AVI）。
  - `height`: 图片或视频的高度，默认值为 0。
  - `width`: 图片或视频的宽度，默认值为 0。
  - `size`: 物料大小，单位为字节，默认值为 0。
  - `duration`: 视频的时长，仅视频类型有效，默认值为 0。
  - `audit_status`: 审核状态，默认值为 0。
  - `user`: 外键，关联 `User` 模型，表示创意属于哪个用户。
  - `url`: 物料存储的 URL 地址，最大长度为 256 个字符。
  - `create_time`: 创意的创建时间，自动记录。
  - `update_time`: 创意的最后修改时间，自动更新。

- **model**：
  ```python
  class AdCreative(models.Model):
      CREATIVE_TYPE_CHOICES = [
          (0, '图片'),
          (1, '视频')
      ]
  
      MATERIAL_TYPE_CHOICES = [
          (0, 'BMP'),
          (1, 'JPG'),
          (2, 'PNG'),
          (3, 'MP4'),
          (4, 'AVI')
      ]
  
      creative_id = models.BigAutoField(primary_key=True)
      name = models.CharField(max_length=48)
      creative_type = models.SmallIntegerField(choices=CREATIVE_TYPE_CHOICES, default=0)
      material_type = models.SmallIntegerField(choices=MATERIAL_TYPE_CHOICES, default=0)
      height = models.IntegerField(default=0)
      width = models.IntegerField(default=0)
      size = models.BigIntegerField(default=0)
      duration = models.IntegerField(default=0)
      audit_status = models.SmallIntegerField(default=0)
      user = models.ForeignKey(User, related_name='ad_creatives', on_delete=models.CASCADE)
      url = models.URLField(max_length=256)
      create_time = models.DateTimeField(auto_now_add=True)
      update_time = models.DateTimeField(auto_now=True)
  
      def __str__(self):
          return self.name
  ```

---

#### **AdUnitCreative**（广告单元与创意关联表）

- **作用**：表示广告单元与创意之间的多对多关系。
- **字段**：
  - `ad_unit`: 外键，关联 `AdUnit` 模型，表示广告单元。
  - `ad_creative`: 外键，关联 `AdCreative` 模型，表示广告创意。
  - `create_time`: 关联的创建时间，自动记录。
  - `update_time`: 关联的最后修改时间，自动更新。

- **model**：
  ```python
  class AdUnitCreative(models.Model):
      ad_unit = models.ForeignKey(AdUnit, related_name='ad_creatives', on_delete=models.CASCADE)
      ad_creative = models.ForeignKey(AdCreative, related_name='ad_units', on_delete=models.CASCADE)
      create_time = models.DateTimeField(auto_now_add=True)
      update_time = models.DateTimeField(auto_now=True)
  
      class Meta:
          unique_together = ('ad_unit', 'ad_creative')
  
      def __str__(self):
          return f'{self.ad_unit.unit_name} - {self.ad_creative.name}'
  ```

---

### 3.2 **adsearch**

#### **UserFeedback**（用户反馈表）

- **作用**：记录用户对广告的反馈。
- **字段**：
  - `user`: 外键，关联 `User` 模型，表示反馈的用户。
  - `ad_unit`: 外键，关联 `AdUnit` 模型，表示反馈的广告单元。
  - `feedback`: 用户反馈，可选值为 `like`（喜欢）或 `dislike`（不喜欢）。
  - `comment`: 用户评论，允许为空。
  - `timestamp`: 反馈时间，自动记录。

- **model**：
  ```python
  class UserFeedback(models.Model):
      FEEDBACK_CHOICES = [
          ('like', 'Like'),
          ('dislike', 'Dislike'),
      ]
  
      user = models.ForeignKey(User, on_delete=models.CASCADE)
      ad_unit = models.ForeignKey(AdUnit, on_delete=models.CASCADE)
      feedback = models.CharField(max_length=10, choices=FEEDBACK_CHOICES)
      comment = models.TextField(blank=True, null=True)
      timestamp = models.DateTimeField(auto_now_add=True)
  
      class Meta:
          verbose_name = '用户反馈'
          verbose_name_plural = '用户反馈'
          app_label = 'adsearch'
  
      def __str__(self):
          return f'{self.user.username} - {self.ad_unit.unit_name} - {self.feedback}'
  ```

---

#### **AdClick**（广告点击记录表）

- **作用**：记录用户对广告的点击行为。
- **字段**：
  - `user`: 外键，关联 `User` 模型，表示点击广告的用户。
  - `ad_unit`: 外键，关联 `AdUnit` 模型，表示被点击的广告单元。
  - `timestamp`: 点击时间，自动记录。

- **model**：
  ```python
  class AdClick(models.Model):
      user = models.ForeignKey(User, on_delete=models.CASCADE)
      ad_unit = models.ForeignKey(AdUnit, on_delete=models.CASCADE)
      timestamp = models.DateTimeField(auto_now_add=True)
  
      class Meta:
          verbose_name = '广告点击记录'
          verbose_name_plural = '广告点击记录'
          app_label = 'adsearch'
  
      def __str__(self):
          return f'{self.user.username} - {self.ad_unit.unit_name}'
  ```

## 4. user

### 4.1 身份验证

1. 使用Django 内置的身份验证和权限管理系统的核心：django.contrib.auth.models
2. 使用rest_framework_simplejwt(token)验证身份
3. 分管理员组和普通用户组

### 4.2 前端

1. 注册页

   ![image-20250214223233610](https://typora5672.oss-cn-chengdu.aliyuncs.com/temp/image-20250214223233610.png)

2. 登录页

   ![image-20250214223255912](https://typora5672.oss-cn-chengdu.aliyuncs.com/temp/image-20250214223255912.png)

3. 本地存储token，管理员status标识1(非管理员标识0)

   ![image-20250214223353293](https://typora5672.oss-cn-chengdu.aliyuncs.com/temp/image-20250214223353293.png)

## 5. AdServer

### **5.1 广告计划管理**

- **功能**：创建、查看、更新、删除广告计划。

- 特点

  - 普通用户只能管理自己的广告计划，管理员可以查看所有广告计划。
  - 支持广告计划的激活和停用操作。

- 核心 API

  - `activate`：激活广告计划。
  - `deactivate`：停用广告计划。

- 前端

  ![image-20250214224721110](https://typora5672.oss-cn-chengdu.aliyuncs.com/temp/image-20250214224721110.png)

------

### **5. 2 广告单元管理**

- **功能**：创建、查看、更新、删除广告单元。

- 特点

  - 广告单元与广告计划绑定。
  - 支持广告单元的启用和禁用操作。
  - 支持根据广告计划 ID 查询广告单元。

- 核心 API

  - `enable`：启用广告单元。
  - `disable`：禁用广告单元。
  - `by_ad_plan`：根据广告计划 ID 查询广告单元。

- 前端

  ![image-20250214224749434](https://typora5672.oss-cn-chengdu.aliyuncs.com/temp/image-20250214224749434.png)

------

### **5. 3 广告创意管理**

- **功能**：创建、查看、更新、删除广告创意。

- 特点

  - 支持图片和视频类型的创意。
  - 支持文件上传和更新。
  - 支持根据广告单元 ID 查询创意。

- 核心 API

  - `by_ad_unit`：根据广告单元 ID 查询创意。
  - `update_ad_creative`：更新广告创意。
  - `create_ad_creative`：创建广告创意。

- 前端

  ![image-20250214224816547](https://typora5672.oss-cn-chengdu.aliyuncs.com/temp/image-20250214224816547.png)

------

### **5. 4 广告单元与创意绑定管理**

- **功能**：管理广告单元与创意之间的绑定关系。

- 特点

  - 支持为广告单元绑定或移除创意。
  - 支持查询广告单元绑定的所有创意。

- 核心 API

  - `add_creative`：为广告单元绑定创意。
  - `remove_creative`：移除广告单元绑定的创意。
  - `get_creatives`：获取广告单元绑定的所有创意。

- 前端

  ![image-20250214224841807](https://typora5672.oss-cn-chengdu.aliyuncs.com/temp/image-20250214224841807.png)

------

### **5.5 其他特性**

- **权限控制**：普通用户和管理员有不同的操作权限。
- **分页与过滤**：支持分页和条件过滤查询。
- **文件处理**：支持异步文件上传和删除，确保数据一致性。

## 6. AdSearch

### **6.1 广告检索**

- **功能**：根据兴趣标签和地域信息检索广告。

- 特点

  - 支持兴趣标签（`hobby_tag`）、省份（`province`）、城市（`city`）等多维度过滤。
  - 优先展示用户反馈好（喜欢次数多）和点击率高的广告。
  - 返回广告单元及其关联的创意信息。

- 核心 API

  - `GET /adsearch/`：检索广告单元。

- 前端

  ![image-20250214225001779](https://typora5672.oss-cn-chengdu.aliyuncs.com/temp/image-20250214225001779.png)

------

### **6.2 用户反馈**

- **功能**：记录用户对广告的喜欢或讨厌。

- 特点

  - 支持 `like` 和 `dislike` 两种反馈类型。
  - 可附加评论（`comment`）。
  - 基于用户和广告单元记录反馈。

- 核心 API

  - `POST /adsearch/feedback/`：提交用户反馈。

- 前端

  ![image-20250214225047251](https://typora5672.oss-cn-chengdu.aliyuncs.com/temp/image-20250214225047251.png)

------

### **6.3 广告点击（AdClickView）**

- **功能**：记录用户对广告的点击行为。
- 特点
  - 基于用户和广告单元记录点击。
  - 支持点击数据的统计和分析。
- 核心 API
  - `POST /adsearch/click/`：记录广告点击。

------

### **6.4 兴趣标签管理**

- **功能**：管理广告单元的兴趣标签。

- 特点

  - 支持兴趣标签的增删改查。
  - 使用 `AdUnitHobbySerializer` 序列化数据。

- 核心 API

  - `GET /adsearch/hobbies/`：获取兴趣标签列表。
  - `POST /adsearch/hobbies/`：创建兴趣标签。

- 前端

  ![image-20250214225122429](https://typora5672.oss-cn-chengdu.aliyuncs.com/temp/image-20250214225122429.png)

------

### 6.5 地域信息管理

- **功能**：管理广告单元的地域信息。

- 特点

  - 支持地域信息的增删改查。
  - 使用 `AdUnitDistrictSerializer` 序列化数据。

- 核心 API

  - `GET /adsearch/districts/`：获取地域信息列表。
  - `POST /adsearch/districts/`：创建地域信息。

- 前端

  ![image-20250214225141077](https://typora5672.oss-cn-chengdu.aliyuncs.com/temp/image-20250214225141077.png)

## 7.测试用例

### 7.1 广告计划

1. ```python
   import time
   
   from django.core.management.base import BaseCommand
   from faker import Faker
   from django.contrib.auth.models import User
   from adserver.models import AdPlan
   import random
   
   
   class Command(BaseCommand):
       help = 'Generate test data for AdPlan'
   
       def handle(self, *args, **kwargs):
           fake = Faker('zh-CN')
   
           users = []
           for _ in range(10):  # 生成10个用户，可以根据需要调整数量
               user = User.objects.create_user(
                   username=fake.user_name(),
                   email=fake.email(),
                   password='qwe123',
                   first_name=fake.name()
               )
               users.append(user)
           plan_names = [
               "双11爆单冲刺计划",
               "暑期清凉季营销",
               "开学季促销活动",
               "春节团圆红包计划",
               "618年中大促",
               "年末感恩回馈",
               "新品上市推广",
               "会员专属福利",
               "品牌形象升级",
               "本地商家引流",
               "双12年终盛典",
               "99划算节流量收割",
               "超级品牌日全域曝光",
               "国庆黄金周抢客行动",
               "情人节甜蜜经济计划",
               "3.8女神节专属战役",
               "中秋团圆季品效合一",
               "Z世代破圈渗透计划",
               "宝妈社群唤醒行动",
               "银发族关怀营销计划",
               "新车主精准转化战役",
               "爆款单品打榜计划",
               "清库存闪电促销",
               "高端系列心智占领",
               "同城夜市狂欢节",
               "社区团购闪电战",
               "地标商圈打卡引流",
               "沉睡用户激活计划",
               "SVIP尊享裂变",
               "积分兑换促活行动",
               "品牌年轻化焕新行动",
               "ESG社会责任传播",
               "品牌跨界联名计划",
               "世界杯主题营销",
               "明星同款种草计划",
               "网红打卡地标联动",
               "AR试妆体验推广",
               "智能客服转化优化",
               "LBS周边辐射计划",
               "黑色星期五海购节",
               "直播带货巅峰战",
               "校园迎新特惠季",
               "企业采购节专项",
               "健康养生季推广",
               "宠物经济生态计划",
               "智能家居体验官",
               "跨境购物流量池",
               "老客复购唤醒计划",
               "新客首单裂变计划",
               "短视频挑战赛引爆"
           ]
           for _ in range(50):  # 生成50个广告计划
               user = random.choice(users)  # 随机选择一个用户
               name = random.choice(plan_names)
               budget = random.randint(10000, 100000)
               status = random.choice(['active', 'inactive'])  # 随机状态
   
               AdPlan.objects.create(
                   user=user,
                   name=name,
                   budget=budget,
                   status=status
               )
               time.sleep(0.5)
           self.stdout.write(self.style.SUCCESS('Successfully generated test data!'))
   ```

2. 通过manage.py执行

   ```shell
   python manage.py generate_ad_plans
   ```

3. ![image-20250214225445233](https://typora5672.oss-cn-chengdu.aliyuncs.com/temp/image-20250214225445233.png)

### 7.3.2 广告单元

1. ```python
   import time
   
   from django.core.management.base import BaseCommand
   from django.contrib.auth.models import User
   from adserver.models import AdPlan, AdUnit, AdUnitDistrict, AdUnitHobby
   import random
   
   
   class Command(BaseCommand):
       help = 'Generate test data for AdUnit, AdUnitDistrict, AdUnitHobby'
   
       def handle(self, *args, **kwargs):
           hobbies = [
               '健身运动', '科技数码', '母婴育儿', '美妆护肤', '股票投资',
               '在线教育', '出境旅游', '烘焙料理', '新能源汽车', '中医养生',
               '宠物饲养', '电竞游戏', '摄影摄像', '家居装修', '奢侈品',
               '短视频创作', '户外探险', '二手交易', '区块链', '动漫文化'
           ]
           for tag in hobbies:
               AdUnitHobby.objects.get_or_create(hobby_tag=tag)
   
           province_cities = {
               '北京': ['朝阳区', '海淀区', '东城区', '西城区', '丰台区'],
               '上海': ['浦东新区', '徐汇区', '静安区', '黄浦区', '长宁区'],
               '天津': ['和平区', '河西区', '南开区', '河北区', '滨海新区'],
               '重庆': ['渝中区', '江北区', '南岸区', '沙坪坝区', '九龙坡区'],
               '江苏': ['南京', '苏州', '无锡', '常州', '徐州', '扬州'],
               '浙江': ['杭州', '宁波', '温州', '绍兴', '嘉兴', '金华'],
               '广东': ['广州', '深圳', '佛山', '东莞', '中山', '珠海']
           }
           for province, areas in province_cities.items():
               for area in areas:
                   AdUnitDistrict.objects.get_or_create(
                       province=province,
                       city=area if province in ['北京', '上海', '天津', '重庆'] else ''
                   )
   
           users = User.objects.all()
           ad_plans = AdPlan.objects.all()
           all_hobbies = list(AdUnitHobby.objects.all())
           all_districts = list(AdUnitDistrict.objects.all())
   
           if not users:
               self.stdout.write(self.style.ERROR('No users found in the database. Please create users first.'))
               return
   
           if not ad_plans:
               self.stdout.write(self.style.ERROR('No AdPlans found in the database. Please generate AdPlans first.'))
               return
           unit_names = [
               "首页信息流广告位",
               "详情页底部通栏广告",
               "APP启动页全屏广告",
               "搜索结果列表广告位",
               "视频前贴片15秒广告",
               "个人中心悬浮按钮广告",
               "商品分类页轮播广告",
               "支付完成页弹窗广告",
               "消息中心信息流广告",
               "购物车推荐广告位",
               "会员专享横幅广告",
               "游戏试玩互动广告",
               "短视频信息流第三坑位",
               "直播间礼物挂件广告",
               "电子书翻页插页广告",
               "音乐播放器音视频广告",
               "地图导航POI标注广告",
               "天气页面底部横幅广告",
               "新闻详情页信息流广告",
               "相机AR特效植入广告",
               "输入法皮肤推荐广告",
               "WiFi连接成功页广告",
               "抽奖活动浮层广告位",
               "智能推荐信息流广告",
               "桌面小部件动态广告"
           ]
           for _ in range(50):  # 生成50个广告单元
               ad_plan = random.choice(ad_plans)
               unit_name = random.choice(unit_names)
               position_type = random.choice([0, 1, 2, 3, 4])
               unit_status = random.choice([0, 1])
               budget_fee = random.randint(100, 10000)
   
               ad_unit = AdUnit.objects.create(
                   plan=ad_plan,
                   unit_name=unit_name,
                   unit_status=unit_status,
                   position_type=position_type,
                   budget_fee=budget_fee
               )
               ad_unit.hobbies.set(random.sample(all_hobbies, k=random.randint(1, 3)))
               selected_districts = []
               for _ in range(random.randint(2,5)):
                   province = random.choice(list(province_cities.keys()))
                   area = random.choice(province_cities[province])
                   district = AdUnitDistrict.objects.get(
                       province=province,
                       city=area if province in ['北京','上海','天津','重庆'] else '',
                   )
                   selected_districts.append(district)
               ad_unit.districts.set(list(set(selected_districts)))
               time.sleep(0.5)
           self.stdout.write(
               self.style.SUCCESS('Successfully generated test data for AdUnit, AdUnitDistrict, AdUnitHobby!'))
   ```

2. ```shell
   python manage.py generate_ad_units
   ```

3. ![image-20250214225232750](https://typora5672.oss-cn-chengdu.aliyuncs.com/temp/image-20250214225232750.png)

![image-20250214225515497](https://typora5672.oss-cn-chengdu.aliyuncs.com/temp/image-20250214225515497.png)

![image-20250214225537984](https://typora5672.oss-cn-chengdu.aliyuncs.com/temp/image-20250214225537984.png)

### 7.3.3 创意

1. 手动上传创建

2. 点击预览和下载按钮可进行预览和下载

   ![image-20250214225416375](https://typora5672.oss-cn-chengdu.aliyuncs.com/temp/image-20250214225416375.png)
