import service from './axiosService.js'
import base from './apiPaths.js'
import {id} from "element-plus/es/locale/index";
// 封装用户注册账号的请求函数
export const GetRegisterAccount = (params)=>{
    return service.post(base.getRegister,params)
}

// 封装用户登录平台的请求函数
export const login = (params)=>{
    return service.post(base.getLogin,params)
}

export const GetAdPlans = (params)=>{
    return service.get(base.getPlans,{ params:params })
}

export const RemovePlan = (id)=>{
    return service.delete(base.getPlans+`${id}/`)
}

export const ActivateAdPlan = (id)=>{
    const url = base.getPlans+`${id}/activate/`
    return service.post(url)
}

export const CreateAdPlan = (params)=>{
    return service.post(base.getPlans,params)
}

export const DeactivateAdPlan = (id)=>{
    return service.post(base.getPlans+`${id}/deactivate/`)
}

export const UpdateAdPlan = (id,data)=>{
    return service.put(base.getPlans+`${id}/`,data)
}

export const GetAdUnitsForPlan = (id) => {
    return service.get(base.getUnit + `by_ad_plan/${id}/`);
}

export const AddAdUnit = (data)=>{
    return service.post(base.getUnit,data)
}

export const GetAdUnits = (params)=>{
    return service.get(base.getUnit,{params:params})
}
export const RemoveUnit =(id)=>{
    return service.delete(base.getUnit+`${id}/`)
}

export const UpdateUnit = (id,data)=>{
    return service.put(base.getUnit+`${id}/`,data)
}

export const ActivateAdUnit = (id)=>{
    const url = base.getUnit+`${id}/enable/`
    return service.post(url)
}

export const DeactivateAdUnit = (id)=>{
    return service.post(base.getUnit+`${id}/disable/`)
}

export const GetAdCreatives = (params)=>{
    return service.get(base.getCreative,{params:params})
}
export const DeleteAdCreative =(id)=>{
    return service.delete(base.getCreative+`${id}/`)
}
export const AddAdCreative  = (data)=>{
    return service.post(base.getCreateCreative,data)
}

export const UpdateAdCreative = (id,data)=>{
    return service.put(base.getCreative+`${id}/`,data)
}
export const GetAdUnitCreatives = (adUnitId)=>{
    return service.get(base.getUnitCreative+`?ad_unit_id=${adUnitId}`)
}
export const AddCreativeToAdUnit = (data)=>{
    return service.post(base.getAddUnitCreative,data)
}
export const RemoveCreativeFromAdUnit = (data)=>{
    return service.post(base.getRemoveUnitCreative,data)
}

export const SearchAds = (params)=>{
    return service.get(base.getAdSearch,{params:params})
}
export const FeedBack = (data)=>{
    return service.post(base.getFeedBack,data)
}
export const Click = (data)=>{
    return service.post(base.getClick,data)
}
export const FetchInterests = ()=>{
    return service.get(base.getHobbies)
}
export const AddInterestTag = (data)=>{
    return service.post(base.getHobbies,data)
}
export const RemoveInterestTag = (id)=>{
    return service.delete(base.getHobbies+`${id}/`)
}
export const UpdateInterestTag =  (id,data)=>{
    return service.put(base.getHobbies+`${id}/`,data)
}

export const FetchDistricts = ()=>{
    return service.get(base.getDistrict)
}
export const AddDistrictTag = (data)=>{
    return service.post(base.getDistrict,data)
}

export const RemoveDistrictTag = (id)=>{
    return service.delete(base.getDistrict+`${id}/`)
}
export const UpdateDistrictTag =  (id,data)=>{
    return service.put(base.getDistrict+`${id}/`,data)
}
