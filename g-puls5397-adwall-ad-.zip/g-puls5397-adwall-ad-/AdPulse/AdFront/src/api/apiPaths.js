const base = {
    getRegister: "/user/register/",//获取注册账号的接口
    getLogin: "/user/login/",//获取账号登录的接口
    getGroup: "/user/group/",//获取操作用户组的接口,增删改查
    getPlans: "/adserver/plan/",//操作广告计划相关接口
    getUnit:"/adserver/unit/",
    getCreative: "/adserver/creative/",
    getCreateCreative: "/adserver/creative/create_ad_creative/",
    getUnitCreative:"/adserver/unitcreative/get_creatives/",
    getAddUnitCreative: "/adserver/unitcreative/add_creative/",
    getRemoveUnitCreative: "/adserver/unitcreative/remove_creative/",
    getAdSearch:"/adsearch/adsearch/", //广告检索
    getClick:"/adsearch/click/", //广告点击
    getFeedBack:"/adsearch/feedback/", //用户反馈
    getHobbies:"/adsearch/hobby/",
    getDistrict:"/adsearch/district/"
}
export default base