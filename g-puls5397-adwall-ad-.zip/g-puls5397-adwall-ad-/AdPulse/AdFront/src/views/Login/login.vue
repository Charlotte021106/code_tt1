<script setup>
import { ref, reactive } from "vue";
import { Lock, User } from "@element-plus/icons-vue";
import { ElMessage } from "element-plus";
import { login } from "@/api/index.js";
import useUserInfoStore from '@/store/user.js'
import { useRouter } from "vue-router";
const router = useRouter();
const store = useUserInfoStore();
const loginFormRef = ref();
const loginForm = reactive({
  username: "",
  password: "",
})
//对数据进行校验
const loginFormRules = reactive({
  username: [
    {
      required: true,
      message: "请输入用户名",
      trigger: "blur",//当用户在对应的输入框中输入完成并且焦点离开输入框时，相关的验证规则会生效，检查输入的合法性，并在必要时显示相应的错误消息
    },
  ],
  password: [
    {
      required: true,
      message: "请输入密码",
      trigger: "blur",
    },
    {
      min: 6,
      message: "密码长度不能少于6位",
      trigger: "blur",
    },
  ],
});
const submitForm = async (rulFormRef) => {
  if (!rulFormRef) return;
  await rulFormRef.validate(async (valid) => {
    if (valid) {
      await submitUserLogin();
    }
  })
}
const data_password = ref();
const submitUserLogin = async () => {
  if (!data_password.value) {
    data_password.value = loginForm.password
  }
  try {
    const res = await login(loginForm)
    if (res.status === 201) {
      // 通过pinia存储后端返回的用户数据以及token (存储token到localStorage)
      store.SetUserInfo(res.res_data)
      // 跳转页面到首页
      await router.push("/home")
      ElMessage.success('登录成功')
    } else {
      ElMessage.error(res.msg)
      if (res.status === 400) {
        loginForm.password = data_password.value
      } else if (res.status === 404) {
        for (let i in loginForm) {
          loginForm[i] = ''
        }
      }
    }
  } catch (error) {
    ElMessage.error('网络错误，请稍后尝试登录！')
    loginForm.password = data_password.value
  }
}

</script>

<template>
  <div class="login-container">
    <div class="title">AdPulse</div>
    <div class="form-container">
      <h2 class="welcome-text">欢迎登录</h2>
      <el-form ref="loginFormRef" :model="loginForm" status-icon :rules="loginFormRules" label-width="auto"
        class="demo-loginForm">
        <!-- 用户名 -->
        <el-form-item prop="username">
          <el-icon color="#409efc" :size="30">
            <User />
          </el-icon>
          <el-input type="text" v-model="loginForm.username" placeholder="请输入用户名" />
        </el-form-item>

        <!-- 密码 -->
        <el-form-item prop="password">
          <el-icon color="#409efc" :size="30">
            <Lock />
          </el-icon>
          <el-input type="password" v-model="loginForm.password" placeholder="请输入密码" />
        </el-form-item>

        <!-- 注册链接 -->
        <p class="register-link-box">
          <router-link to="/register" class="register-link">没有账号？点击注册</router-link>
        </p>

        <!-- 登录按钮 -->
        <el-form-item id="button">
          <el-button type="primary" @click="submitForm(loginFormRef)">登录</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>


<style lang="less" scoped>
.login-container {
  background-image: url("@/assets/img/background.png");
  background-size: cover;
  background-attachment: fixed; /* 背景图固定，不随页面滚动 */
  height: 100%;
}

.title {
  font-size: 35px;
  font-weight: bold;
  color: #ffffff;
  text-align: center;
}

.form-container {
  margin: auto;
  background: linear-gradient(135deg, #fff3e6, #f5f8fa);
  padding: 40px;
  border-radius: 8px;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15); /* 更柔和的阴影 */
  width: 100%;
  max-width: 400px; /* 最大宽度 */
  transition: box-shadow 0.3s ease-in-out; /* 添加动态阴影效果 */
}

.form-container:hover {
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2); /* 鼠标悬停时阴影效果增强 */
}

.welcome-text {
  text-align: center;
  font-size: 1.5rem;
  margin-bottom: 30px;
  color: #333333;
}

.demo-loginForm {
  .el-form-item {
    margin-bottom: 20px;
  }

  .el-input__inner {
    padding: 12px;
    font-size: 14px;
    border-radius: 4px;
    border: 1px solid #e0e0e0;
    transition: all 0.3s ease-in-out; /* 输入框过渡效果 */
  }

  .el-input__inner:focus {
    border-color: #409efc;
    box-shadow: 0 0 8px rgba(64, 158, 252, 0.3); /* 输入框聚焦时的光辉效果 */
    transform: scale(1.02); /* 聚焦时轻微放大 */
  }

  .el-icon {
    margin-right: 10px;
  }

  .register-link-box {
    text-align: center;
    margin-top: 10px;

    .register-link {
      color: #409efc;
      font-size: 14px;
      text-decoration: none;
      transition: color 0.3s ease; /* 过渡效果 */
    }

    .register-link:hover {
      text-decoration: underline;
      color: #2980b9; /* 鼠标悬停时颜色变更 */
    }
  }

  #button {
    text-align: center;
    .el-button {
      width: 100%;
      padding: 12px;
      font-size: 16px;
      border-radius: 4px;
      background: linear-gradient(45deg, #409efc, #1e74d8); /* 渐变背景 */
      border: none;
      transition: all 0.3s ease; /* 按钮过渡效果 */
    }

    .el-button:hover {
      background: linear-gradient(45deg, #1e74d8, #409efc);
      transform: scale(1.05); /* 鼠标悬停时按钮放大 */
      box-shadow: 0 4px 12px rgba(64, 158, 252, 0.3); /* 按钮悬停时阴影效果 */
    }
  }
}
</style>