import {createRouter, createWebHistory} from 'vue-router'
import {ElMessage} from "element-plus";

const Login = () => import('@/views/Login/login.vue')
const Register = () => import('@/views/Register/register.vue')
const Home = () => import('@/views/Home/home.vue')
const homepage = () => import('@/views/Home/homepage.vue')
const unit = () =>import('@/views/AdUnits/adunits.vue')
const creatives = ()=>import('@/views/AdCreatives/adcreatives.vue')
const districts = () =>import('@/views/Districts/districts.vue')
const hobbies = () =>import('@/views/Hobbies/hobbies.vue')
const feedback = () =>import('@/views/FeedBack/feedback.vue')

const routes = [
    {
        path: '/login',
        name: 'login',
        component: Login,
    },
    {
        path: '/register',
        name: 'register',
        component: Register
    },
    {
        path: '/',
        component: Home,
        redirect: '/login',//首页默认重定向到登录页
        children: [
            {
                path: 'home',
                name: 'home',
                component: homepage,
                meta: {
                    isLoggedIn: true,
                }
            },
            {
              path: 'unit',
              name: 'unit',
              component: unit,
            },
            {
                path: 'creatives',
                name: 'creatives',
                component: creatives
            },
            {
                path: 'districts',
                name: 'districts',
                component: districts
            },
            {
                path: 'hobbies',
                name: 'hobbies',
                component: hobbies
            },
            {
                path: 'feedback',
                name: 'feedback',
                component: feedback
            }
        ]
    },
]
const router = createRouter({
    history: createWebHistory(),
    routes
})
router.beforeEach((to, from, next) => {
    if (to.meta.isLoggedIn) {
        try {
            let token = JSON.parse(localStorage.getItem('userInfo')).userInfo.token
            if (!token) {
                ElMessage.warning("请先登录！")
                next('/login')
            } else {
                next()
            }
        } catch (error) {
            ElMessage.warning("请先登录！")
            next('/login')
        }
    } else {
        next()
    }
})
export default router